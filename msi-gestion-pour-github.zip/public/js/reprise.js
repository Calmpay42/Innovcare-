'use strict';
/* Reprise des données d'OphtaSuite : l'ophtalmologue choisit le fichier de sauvegarde, voit ce qui sera repris, puis importe. */
let SAUVEGARDE_OPHTA = null;
const LIB_COLLECTIONS = {
  patients: 'Patients', consultations: 'Consultations', ordonnancesMed: 'Ordonnances', ordonnancesLunettes: 'Ordonnances de lunettes', certificats: 'Arrêts de travail',
  certificatsMedicaux: 'Certificats médicaux', interpretations: 'Interprétations d’examens', comptesRendusOp: 'Comptes rendus opératoires', explorations: 'Demandes d’exploration',
  bilansBiologiques: 'Bilans biologiques', bulletinsRadio: 'Bulletins de radiologie', bulletinsOphtalmo: 'Lettres d’orientation', photosDossier: 'Photos du dossier',
  fondOeilSchemas: 'Schémas du fond d’œil', rdv: 'Rendez-vous'
};
Object.assign(ACTIONS, {
  repriseOuvrir: () => {
    SAUVEGARDE_OPHTA = null;
    openModal(`<div class="modal-head"><h2>Reprise des données d’OphtaSuite</h2>${closeBtn()}</div>
      <p>Dans OphtaSuite, exportez la sauvegarde (fichier <strong>ophtasuite-sauvegarde-AAAA-MM-JJ.json</strong>), puis choisissez-la ici.</p>
      ${champ('Fichier de sauvegarde OphtaSuite', '<input type="file" id="rep-fichier" accept=".json,application/json">')}
      <div id="rep-res"></div>
      <p class="hint">Rien n’est importé avant votre confirmation. Les patients déjà connus sont rapprochés de leur dossier MSI ; relancer la reprise ne crée aucun doublon ; aucun bon de caisse n’est créé.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button><button class="btn" data-action="repriseAnalyser">Analyser le fichier</button></div>`, { large: true });
  },
  repriseAnalyser: async () => {
    const f = ($('#rep-fichier').files || [])[0];
    if (!f) { toast('Choisissez le fichier de sauvegarde.', 'bad'); return; }
    try { SAUVEGARDE_OPHTA = JSON.parse(await f.text()); } catch (e) { toast('Ce fichier n’est pas une sauvegarde lisible.', 'bad'); return; }
    try {
      const a = await api('POST', '/api/reprise/ophtasuite/analyse', SAUVEGARDE_OPHTA);
      $('#rep-res').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Fiches OphtaSuite</th><th class="num">Dans le fichier</th><th class="num">À reprendre</th></tr></thead><tbody>
        ${Object.entries(a.collections).filter(([, v]) => v.total).map(([k, v]) => `<tr><td>${esc(LIB_COLLECTIONS[k] || k)}</td><td class="num">${v.total}</td><td class="num">${v.a_reprendre}</td></tr>`).join('')}</tbody></table></div>
        <p>${a.patients.rapproches} patient(s) déjà connu(s) de MSI, rapproché(s) de leur dossier ; ${a.patients.nouveaux} nouveau(x) dossier(s)${a.patients.deja_repris ? ` ; ${a.patients.deja_repris} déjà repris` : ''}.
        ${a.rdv_passes ? `${a.rdv_passes} rendez-vous passé(s) ne seront pas repris.` : ''}</p>
        <button class="btn btn-block" data-action="repriseImporter">Importer dans MSI Gestion</button>`;
    } catch (e) { toast(e.message, 'bad'); }
  },
  repriseImporter: async () => {
    const r = await agir(() => api('POST', '/api/reprise/ophtasuite/import', SAUVEGARDE_OPHTA));
    if (!r) return;
    $('#rep-res').innerHTML = `<div class="notice ok">Reprise terminée : ${r.patients_crees} dossier(s) créé(s), ${r.patients_rapproches} rapproché(s), ${r.consultations} consultation(s),
      ${r.documents} document(s), ${r.photos} photo(s), ${r.rdv} rendez-vous.</div>${r.ignores.length ? `<div class="notice warn">Non repris : <ul>${r.ignores.slice(0, 30).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}`;
  }
});
