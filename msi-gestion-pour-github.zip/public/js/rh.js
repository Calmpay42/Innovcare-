'use strict';
/* Ressources humaines (v1.8) : personnel, planning des gardes et des consultations, paie, avances, paramètres de paie.
   Les montants des salaires ne sont transmis qu'aux profils chargés de la paie. */
const rhUI = () => (UI.rh = UI.rh || { sub: 'personnel', data: null, lundi: '', periode: '', charge_le: 0, chargement: false });
const SUBS_RH = [['personnel', 'Personnel'], ['planning', 'Planning'], ['paie', 'Paie'], ['avances', 'Avances'], ['parametres', 'Paramètres de paie']];
const COULEUR_CRENEAU = { garde: 'cr-garde', consultation: 'cr-consult', permanence: 'cr-perm', astreinte: 'cr-astr', conge: 'cr-conge', absence: 'cr-conge' };
const LIB_CRENEAU = { garde: 'Garde', consultation: 'Consultation', permanence: 'Permanence', astreinte: 'Astreinte', conge: 'Congé', absence: 'Absence' };
const STATUT_PAIE = { prepare: ['b-warn', 'À valider'], valide: ['b-due', 'Validé, à payer'], paye: ['b-ok', 'Payé'], annule: ['b-muted', 'Annulé'] };
const PRESETS_CRENEAU = [['Garde de nuit', '18:00', '08:00'], ['Garde de 24 h', '08:00', '08:00'], ['Matinée', '08:00', '13:00'], ['Après-midi', '14:00', '18:00']];
const nomEmp = e => `${e.nom}${e.prenoms ? ' ' + e.prenoms : ''}`;
const decalerJour = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const decalerMois = (p, n) => { const [y, m] = p.split('-').map(Number), d = new Date(Date.UTC(y, m - 1 + n, 1)); return d.toISOString().slice(0, 7); };
const nomJour = iso => ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'][new Date(iso + 'T00:00:00Z').getUTCDay()];
const moisLong = p => { const [y, m] = p.split('-').map(Number); return new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' }); };
const jourAbsolu = iso => (iso ? new Date(iso).toLocaleDateString('fr-FR') : '—');

async function chargerRH() {
  const ui = rhUI();
  if (ui.chargement) return;
  ui.chargement = true;
  try {
    ui.data = await api('GET', `/api/rh?lundi=${encodeURIComponent(ui.lundi || '')}&periode=${encodeURIComponent(ui.periode || '')}`);
    ui.lundi = ui.data.lundi; ui.periode = ui.data.periode; ui.erreur = null;
  } catch (e) { ui.erreur = e.message || 'Chargement impossible.'; }
  ui.charge_le = Date.now(); ui.chargement = false;
  render();
}

function vRH() {
  const ui = rhUI(), D = ui.data;
  if (!ui.chargement && (!D || Date.now() - ui.charge_le > 20000)) setTimeout(chargerRH, 0);
  const subs = SUBS_RH.filter(([k]) => !['paie', 'avances', 'parametres'].includes(k) || (D && D.voir_salaires));
  if (!subs.some(([k]) => k === ui.sub)) ui.sub = 'personnel';
  const vues = { personnel: vPersonnel, planning: vPlanningRH, paie: vPaie, avances: vAvances, parametres: vParamsPaie };
  return `<div class="page-head"><div><h1>Ressources humaines</h1><p class="lead">Personnel, planning des gardes et des consultations, paie et avances.</p></div></div>
    <div class="seg" role="group" aria-label="Rubriques des ressources humaines">${subs.map(([k, l]) => `<button data-action="rhSub" data-sub="${k}" aria-pressed="${ui.sub === k}">${l}</button>`).join('')}</div>
    ${ui.erreur && !D ? `<div class="notice bad">${esc(ui.erreur)}</div>` : !D ? '<div class="panel"><p class="muted">Chargement…</p></div>' : vues[ui.sub](D)}`;
}

/* ---------- Personnel ---------- */
function vPersonnel(D) {
  const sal = D.voir_salaires, actifs = D.employes.filter(e => e.actif), archives = D.employes.filter(e => !e.actif), dans30 = decalerJour(todayISO(), 30);
  return `<div class="panel"><div class="panel-head"><h2>Personnel <span class="muted">${actifs.length} actif${actifs.length > 1 ? 's' : ''}</span></h2>
      <div class="row-actions">${peut('rh_gerer') ? `${D.comptes_libres.length ? `<button class="btn btn-ghost btn-sm" data-action="rhReprise">Reprendre ${D.comptes_libres.length} compte${D.comptes_libres.length > 1 ? 's' : ''} sans fiche</button>` : ''}<button class="btn btn-sm" data-action="rhEmploye">Nouvel employé</button>` : ''}</div></div>
    ${actifs.length ? `<div class="table-wrap"><table><thead><tr><th>Matricule</th><th>Nom et prénoms</th><th>Fonction</th><th>Contrat</th><th>Embauche</th><th>Téléphone</th><th>Compte</th>${sal ? '<th class="num">Salaire de base</th>' : ''}<th></th></tr></thead><tbody>
      ${actifs.map(e => `<tr><td>${esc(e.matricule)}</td><td><strong>${esc(nomEmp(e))}</strong>${e.service ? `<br><small class="muted">${esc(e.service)}</small>` : ''}</td><td>${esc(e.fonction)}</td>
        <td>${esc(e.contrat)}${e.fin_contrat ? `<br><small class="${e.fin_contrat <= dans30 ? 'alerte-file' : 'muted'}">jusqu’au ${fmtDate(e.fin_contrat)}</small>` : ''}</td><td>${fmtDate(e.embauche_le)}</td>
        <td>${esc(e.telephone || '')}</td><td>${esc(e.compte || '—')}</td>${sal ? `<td class="num">${e.salaire_base ? money(e.salaire_base) : '—'}</td>` : ''}
        <td class="actions">${peut('rh_gerer') ? `<button class="btn btn-sm btn-ghost" data-action="rhEmploye" data-id="${e.id}">Modifier</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div>` : '<p class="muted">Aucun employé enregistré. Commencez par reprendre les comptes existants ou par « Nouvel employé ».</p>'}
    ${archives.length ? `<details class="rh-archives"><summary>${archives.length} employé${archives.length > 1 ? 's' : ''} archivé${archives.length > 1 ? 's' : ''}</summary><ul>${archives.map(e => `<li>${esc(e.matricule)} ${esc(nomEmp(e))}, ${esc(e.fonction)} : sortie le ${fmtDate(e.sortie_le)}${e.motif_sortie ? ', ' + esc(e.motif_sortie) : ''}</li>`).join('')}</ul></details>` : ''}
  </div>`;
}
function formEmploye(e, D) {
  const c = D.constantes, v = (k, d = '') => esc(e && e[k] != null ? e[k] : d);
  const liste = (id, items, val) => `<select id="${id}">${items.map(x => `<option${x === val ? ' selected' : ''}>${esc(x)}</option>`).join('')}</select>`;
  const comptes = [...(e && e.utilisateur_id ? [{ id: e.utilisateur_id, nom: e.compte }] : []), ...D.comptes_libres];
  openModal(`<div class="modal-head"><h2>${e ? 'Modifier ' + esc(nomEmp(e)) : 'Nouvel employé'}</h2>${closeBtn()}</div>
    <div class="form-grid">
      ${champ('Nom', `<input id="em-nom" value="${v('nom')}" maxlength="80" autocomplete="off">`)}
      ${champ('Prénoms', `<input id="em-prenoms" value="${v('prenoms')}" maxlength="120" autocomplete="off">`)}
      ${champ('Sexe', `<select id="em-sexe"><option value="">Non précisé</option><option value="F"${e && e.sexe === 'F' ? ' selected' : ''}>Féminin</option><option value="M"${e && e.sexe === 'M' ? ' selected' : ''}>Masculin</option></select>`)}
      ${champ('Téléphone', `<input id="em-tel" value="${v('telephone')}" inputmode="tel" placeholder="07 00 00 00 00" autocomplete="off">`)}
      ${champ('Fonction', liste('em-fonction', c.FONCTIONS, e ? e.fonction : 'Infirmier'))}
      ${champ('Service', `<input id="em-service" value="${v('service')}" maxlength="80" placeholder="Ex. Médecine générale">`)}
      ${champ('Contrat', liste('em-contrat', c.CONTRATS, e ? e.contrat : 'CDI'))}
      ${champ('Date d’embauche', `<input type="date" id="em-embauche" value="${v('embauche_le', todayISO())}">`)}
      ${champ('Fin de contrat (CDD)', `<input type="date" id="em-fin" value="${v('fin_contrat')}">`)}
      ${champ('N° CNPS', `<input id="em-cnps" value="${v('numero_cnps')}" maxlength="30" autocomplete="off">`)}
      ${D.voir_salaires ? `${champ('Salaire de base (FCFA)', `<input type="number" min="0" id="em-salaire" value="${v('salaire_base', 0)}">`)}
      ${champ('Prime par garde (FCFA)', `<input type="number" min="0" id="em-garde" value="${v('taux_garde', 0)}">`)}
      ${champ('Montant par vacation (FCFA)', `<input type="number" min="0" id="em-vacation" value="${v('taux_vacation', 0)}">`)}` : ''}
      ${champ('Mode de paiement', liste('em-mode', c.MODES_PAIEMENT, e ? e.mode_paiement : 'Virement'))}
      ${champ('Compte MSI Gestion', `<select id="em-compte"><option value="">Aucun</option>${comptes.map(x => `<option value="${x.id}"${e && e.utilisateur_id === x.id ? ' selected' : ''}>${esc(x.nom)}</option>`).join('')}</select>`, 'Relie la fiche au compte de connexion : « Mon planning » et notifications.')}
    </div>
    <p class="hint">Gardes et vacations sont comptées sur le planning du mois : prime par garde pour les gardes, montant par vacation pour les consultations des vacataires.</p>
    <div class="modal-actions">${e && e.actif ? `<button class="btn btn-ghost" data-action="rhArchiver" data-id="${e.id}">Archiver (départ)</button>` : ''}<button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhEnregistrerEmploye" data-id="${e ? e.id : ''}">Enregistrer</button></div>`);
}

/* ---------- Planning ---------- */
function vPlanningRH(D) {
  const jours = [...Array(7)].map((_, i) => decalerJour(D.lundi, i)), auj = todayISO();
  return `${D.en_poste.length ? `<div class="notice ok"><strong>En poste en ce moment :</strong> ${D.en_poste.map(c => `${esc(nomEmp(c))} (${esc(LIB_CRENEAU[c.type].toLowerCase())} jusqu’à ${c.fin})`).join(', ')}.</div>` : ''}
  <div class="panel"><div class="panel-head"><h2>Semaine du ${fmtDate(D.lundi)}</h2><div class="row-actions">
      <button class="btn btn-ghost btn-sm" data-action="rhSemaine" data-d="-7">‹ Précédente</button><button class="btn btn-ghost btn-sm" data-action="rhSemaine" data-d="0">Cette semaine</button><button class="btn btn-ghost btn-sm" data-action="rhSemaine" data-d="7">Suivante ›</button>
      ${peut('rh_gerer') ? '<button class="btn btn-ghost btn-sm" data-action="rhRecopie">Recopier la semaine précédente</button><button class="btn btn-sm" data-action="rhCreneau">Ajouter un créneau</button>' : ''}
      <button class="btn btn-ghost btn-sm" data-action="rhImprimerPlanning">Imprimer</button></div></div>
    <div class="rh-semaine">${jours.map(j => `<div class="rh-jour${j === auj ? ' aujourdhui' : ''}"><h3>${nomJour(j)} <span>${fmtDate(j).slice(0, 5)}</span></h3>
      ${D.planning.filter(c => c.jour === j).map(c => `<button type="button" class="creneau ${COULEUR_CRENEAU[c.type] || ''}" data-action="rhCreneauVoir" data-id="${c.id}"><strong>${c.debut}–${c.fin}</strong><span>${esc(nomEmp(c))}</span><small>${esc(LIB_CRENEAU[c.type])}${c.observation ? ', ' + esc(c.observation) : ''}</small></button>`).join('') || '<p class="muted vide">Aucun créneau</p>'}</div>`).join('')}</div>
  </div>`;
}
function planningHTML(D) {
  const jours = [...Array(7)].map((_, i) => decalerJour(D.lundi, i));
  const corps = `<table class="bp-lignes plan-print"><thead><tr>${jours.map(j => `<th>${nomJour(j)} ${fmtDate(j).slice(0, 5)}</th>`).join('')}</tr></thead><tbody><tr>
    ${jours.map(j => `<td>${D.planning.filter(c => c.jour === j).map(c => `<div><strong>${c.debut}–${c.fin}</strong> ${esc(nomEmp(c))}<br><small>${esc(LIB_CRENEAU[c.type])}</small></div>`).join('') || '—'}</td>`).join('')}</tr></tbody></table>`;
  return pieceA4({ titre: 'Planning de la semaine', numero: `Semaine du ${fmtDate(D.lundi)}`, sous: `Du ${fmtDate(D.lundi)} au ${fmtDate(jours[6])}`, corps, paysage: true });
}

/* ---------- Paie ---------- */
function vPaie(D) {
  const P = D.paies, actives = P.filter(p => p.statut !== 'annule'), somme = k => actives.reduce((s, p) => s + p[k], 0);
  const contrat = p => (D.employes.find(e => e.id === p.employe_id) || {}).contrat;
  const stat = (l, v) => `<div class="hosp-stat"><small>${l}</small><strong>${v}</strong></div>`;
  return `<div class="panel"><div class="panel-head"><h2>Paie de ${moisLong(D.periode)}</h2><div class="row-actions">
      <button class="btn btn-ghost btn-sm" data-action="rhMois" data-d="-1">‹ Mois précédent</button><button class="btn btn-ghost btn-sm" data-action="rhMois" data-d="1">Mois suivant ›</button>
      ${peut('paie_preparer') ? '<button class="btn btn-sm" data-action="rhPreparer">Préparer les bulletins du mois</button>' : ''}
      ${peut('paie_valider') && P.some(p => p.statut === 'prepare') ? '<button class="btn btn-sm" data-action="rhValiderTout">Valider la paie du mois</button>' : ''}
      ${actives.length ? '<button class="btn btn-ghost btn-sm" data-action="rhJournal">Journal de paie</button>' : ''}</div></div>
    ${actives.length ? `<div class="hosp-stats">${stat('Bulletins', actives.length)}${stat('Masse salariale brute', money(somme('brut')))}${stat('Retenues', money(somme('retenues')))}${stat('Net à payer', money(somme('net')))}</div>` : ''}
    <p class="hint">L’ITS est calculé par l’expert-comptable et saisi sur chaque bulletin de salarié (0 s’il est nul) : la direction ne peut pas valider un bulletin de salarié sans ITS. La cotisation retraite est recalculée à chaque modification, sur tous les gains sauf ceux marqués « hors cotisations ».</p>
    ${P.length ? `<div class="table-wrap"><table><thead><tr><th>Bulletin</th><th>Employé</th><th class="num">Brut</th><th class="num">ITS</th><th class="num">Retenues</th><th class="num">Net à payer</th><th>Statut</th><th></th></tr></thead><tbody>
      ${P.map(p => {
        const [cls, lib] = STATUT_PAIE[p.statut] || ['b-muted', p.statut], its = p.lignes.find(l => l.code === 'ITS'), salarie = ['CDI', 'CDD'].includes(contrat(p));
        return `<tr class="${p.statut === 'annule' ? 'annule' : ''}"><td>${esc(p.numero)}</td><td><strong>${esc(nomEmp(p))}</strong><br><small class="muted">${esc(p.matricule)}, ${esc(p.fonction)}</small></td>
          <td class="num">${money(p.brut)}</td><td class="num">${its ? money(its.montant) : salarie && p.statut === 'prepare' ? '<span class="alerte-file">à saisir</span>' : '—'}</td>
          <td class="num">${money(p.retenues)}</td><td class="num"><strong>${money(p.net)}</strong></td>
          <td><span class="badge ${cls}">${lib}</span>${p.paye_le ? `<br><small class="muted">${esc(p.mode_paiement || '')}${p.reference ? ', ' + esc(p.reference) : ''}</small>` : ''}</td>
          <td class="actions"><button class="btn btn-sm btn-ghost" data-action="rhBulletin" data-id="${p.id}">Voir</button>
            ${p.statut === 'prepare' && peut('paie_preparer') ? `<button class="btn btn-sm btn-ghost" data-action="rhModifierBulletin" data-id="${p.id}">ITS et lignes</button>` : ''}
            ${p.statut === 'prepare' && peut('paie_valider') ? `<button class="btn btn-sm" data-action="rhValider" data-id="${p.id}">Valider</button>` : ''}
            ${p.statut === 'valide' && peut('paie_payer') ? `<button class="btn btn-sm" data-action="rhPayer" data-id="${p.id}">Payer</button>` : ''}
            ${(p.statut === 'prepare' && peut('paie_preparer')) || (p.statut === 'valide' && peut('paie_valider')) ? `<button class="btn btn-sm btn-ghost" data-action="rhAnnulerBulletin" data-id="${p.id}">Annuler</button>` : ''}</td></tr>`;
      }).join('')}
    </tbody></table></div>` : `<p class="muted">Aucun bulletin pour ${moisLong(D.periode)}.${peut('paie_preparer') ? ' « Préparer les bulletins du mois » les crée pour chaque employé actif, avec gardes, vacations et avances.' : ''}</p>`}
  </div>`;
}
function formBulletin(p) {
  const its = p.lignes.find(l => l.code === 'ITS'), auto = p.lignes.filter(l => !['MANUEL', 'ITS'].includes(l.code)), manuelles = p.lignes.filter(l => l.code === 'MANUEL');
  openModal(`<div class="modal-head"><h2>${esc(p.numero)} : ${esc(nomEmp(p))}</h2>${closeBtn()}</div>
    <table class="bp-lignes"><thead><tr><th>Lignes calculées</th><th class="num">Gain</th><th class="num">Retenue</th></tr></thead><tbody>
      ${auto.map(l => `<tr><td>${esc(l.libelle)}</td><td class="num">${l.type === 'gain' ? money(l.montant) : ''}</td><td class="num">${l.type === 'retenue' ? money(l.montant) : ''}</td></tr>`).join('')}</tbody></table>
    ${champ('ITS du mois (FCFA)', `<input type="number" min="0" id="bp-its" value="${its ? its.montant : ''}" placeholder="Montant calculé par l’expert-comptable">`, 'Saisissez 0 si le salaire n’est pas imposable.')}
    <h3 class="inf-titre">Primes, indemnités et retenues</h3>
    <div id="bp-lignes">${manuelles.map(ligneBulletinHTML).join('')}</div>
    <button class="btn btn-ghost btn-sm" data-action="rhAjouterLigne">Ajouter une ligne</button>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhEnregistrerBulletin" data-id="${p.id}">Enregistrer</button></div>`, { large: true });
}
const ligneBulletinHTML = l => `<div class="bp-ligne form-grid"><select class="bp-type"><option value="gain"${l && l.type === 'gain' ? ' selected' : ''}>Gain</option><option value="retenue"${l && l.type === 'retenue' ? ' selected' : ''}>Retenue</option></select>
  <input class="bp-libelle" maxlength="120" placeholder="Libellé (ex. prime de rendement)" value="${esc(l ? l.libelle : '')}"><input class="bp-montant" type="number" min="1" placeholder="Montant" value="${l ? l.montant : ''}">
  <label class="bp-hors"><input type="checkbox" class="bp-non-soumis"${l && l.non_soumis ? ' checked' : ''}> Hors cotisations</label>
  <button type="button" class="btn btn-ghost btn-sm" data-action="rhRetirerLigne">Retirer</button></div>`;
function bulletinHTML(p, D) {
  const e = D.employes.find(x => x.id === p.employe_id) || {}, gains = p.lignes.filter(l => l.type === 'gain'), ret = p.lignes.filter(l => l.type === 'retenue');
  const etat = p.statut === 'paye' ? `Payé le ${jourAbsolu(p.paye_le)} par ${esc((p.mode_paiement || '').toLowerCase())}${p.reference ? ', référence ' + esc(p.reference) : ''}.`
    : p.statut === 'valide' ? `Validé le ${jourAbsolu(p.valide_le)}, en attente de paiement.` : p.statut === 'annule' ? 'Bulletin annulé.' : 'Bulletin en préparation, non validé par la direction.';
  const corps = `<table class="doc-identite"><tbody>
      <tr><th>Employé</th><td>${esc(nomEmp(p))}</td><th>Matricule</th><td>${esc(p.matricule)}</td></tr>
      <tr><th>Fonction</th><td>${esc(e.fonction || p.fonction)}${e.service ? ', ' + esc(e.service) : ''}</td><th>Contrat</th><td>${esc(e.contrat || '')}${e.fin_contrat ? ' jusqu’au ' + fmtDate(e.fin_contrat) : ''}</td></tr>
      <tr><th>Date d’embauche</th><td>${e.embauche_le ? fmtDate(e.embauche_le) : '—'}</td><th>N° CNPS</th><td>${esc(e.numero_cnps || '—')}</td></tr>
      <tr><th>Période</th><td>${moisLong(p.periode)}</td><th>N° employeur CNPS</th><td>${esc((D.parametres && D.parametres.cnps_employeur) || '—')}</td></tr>
    </tbody></table>
    <table class="bp-lignes"><thead><tr><th>Désignation</th><th class="num">Gains</th><th class="num">Retenues</th></tr></thead><tbody>
      ${gains.map(l => `<tr><td>${esc(l.libelle)}${l.non_soumis ? ' <small>(hors cotisations)</small>' : ''}</td><td class="num">${money(l.montant)}</td><td></td></tr>`).join('')}
      ${ret.map(l => `<tr><td>${esc(l.libelle)}</td><td></td><td class="num">${money(l.montant)}</td></tr>`).join('')}
    </tbody><tfoot><tr><th>Totaux</th><th class="num">${money(p.brut)}</th><th class="num">${money(p.retenues)}</th></tr>
      <tr class="bp-net"><th>Net à payer</th><th class="num" colspan="2">${money(p.net)}</th></tr></tfoot></table>
    <p>${etat}</p>
    <div class="bs-signatures"><div>L’employeur</div><div>L’employé, pour acquit</div><div></div></div>`;
  return pieceA4({ titre: 'Bulletin de paie', numero: p.numero, sous: moisLong(p.periode), corps });
}
function journalPaieHTML(D) {
  const P = D.paies.filter(p => p.statut !== 'annule'), m = (p, code) => p.lignes.filter(l => l.code === code).reduce((s, l) => s + l.montant, 0);
  const autres = p => p.lignes.filter(l => l.type === 'retenue' && !['CNPS', 'CMU', 'ITS', 'AVANCE'].includes(l.code)).reduce((s, l) => s + l.montant, 0);
  const cols = [['Brut', p => p.brut], ['CNPS', p => m(p, 'CNPS')], ['CMU', p => m(p, 'CMU')], ['ITS', p => m(p, 'ITS')], ['Avances', p => m(p, 'AVANCE')], ['Autres retenues', autres], ['Net', p => p.net]];
  const corps = `<table class="bp-lignes"><thead><tr><th>Bulletin</th><th>Employé</th><th>Fonction</th>${cols.map(([l]) => `<th class="num">${l}</th>`).join('')}<th>Statut</th></tr></thead><tbody>
      ${P.map(p => `<tr><td>${esc(p.numero)}</td><td>${esc(nomEmp(p))}</td><td>${esc(p.fonction)}</td>${cols.map(([, f]) => `<td class="num">${money(f(p))}</td>`).join('')}<td>${esc((STATUT_PAIE[p.statut] || ['', p.statut])[1])}</td></tr>`).join('')}
    </tbody><tfoot><tr><th colspan="3">Total : ${P.length} bulletin${P.length > 1 ? 's' : ''}</th>${cols.map(([, f]) => `<th class="num">${money(P.reduce((s, p) => s + f(p), 0))}</th>`).join('')}<th></th></tr></tfoot></table>
    <p class="hint">Base des déclarations CNPS et ITS du mois. Les charges patronales (CNPS employeur, FDFP) sont établies par l’expert-comptable.</p>`;
  return pieceA4({ titre: 'Journal de paie', numero: D.periode, sous: moisLong(D.periode), corps, paysage: true });
}

/* ---------- Avances et paramètres ---------- */
function vAvances(D) {
  return `<div class="panel"><div class="panel-head"><h2>Avances sur salaire à déduire</h2>${peut('paie_preparer') ? '<button class="btn btn-sm" data-action="rhAvance">Accorder une avance</button>' : ''}</div>
    ${D.avances.length ? `<div class="table-wrap"><table><thead><tr><th>Employé</th><th class="num">Montant</th><th>Accordée le</th><th>Motif</th></tr></thead><tbody>
      ${D.avances.map(a => `<tr><td><strong>${esc(nomEmp(a))}</strong><br><small class="muted">${esc(a.matricule)}</small></td><td class="num">${money(a.montant)}</td><td>${jourAbsolu(a.accorde_le)}</td><td>${esc(a.motif || '')}</td></tr>`).join('')}
    </tbody></table></div>` : '<p class="muted">Aucune avance en attente : chaque avance accordée est déduite automatiquement de la paie suivante.</p>'}</div>`;
}
function vParamsPaie(D) {
  const P = D.parametres || {}, off = peut('paie_valider') ? '' : ' disabled';
  return `<div class="panel"><h2>Paramètres de paie</h2>
    <div class="notice">Valeurs indicatives : faites-les confirmer par votre expert-comptable avant la première paie réelle. L’ITS, les charges patronales et la CMU des ayants droit sont établis par le comptable.</div>
    <div class="form-grid">
      ${champ('Cotisation retraite CNPS, part salariale (%)', `<input id="pp-taux" inputmode="decimal" value="${esc(String(P.taux_cnps || '').replace('.', ','))}"${off}>`)}
      ${champ('Plafond mensuel de la cotisation retraite (FCFA)', `<input id="pp-plafond" type="number" min="0" value="${esc(P.plafond_cnps || '')}"${off}>`)}
      ${champ('CMU, part salariale (FCFA par mois)', `<input id="pp-cmu" type="number" min="0" value="${esc(P.cmu || '')}"${off}>`)}
      ${champ('N° employeur CNPS', `<input id="pp-employeur" maxlength="30" value="${esc(P.cnps_employeur || '')}"${off}>`, 'Imprimé sur les bulletins de paie.')}
    </div>
    ${peut('paie_valider') ? '<div class="row-actions"><button class="btn" data-action="rhEnregistrerParametres">Enregistrer les paramètres</button></div>' : '<p class="hint">Seule la direction modifie ces paramètres.</p>'}</div>`;
}

/* ---------- Actions ---------- */
const rhTrouve = (liste, id) => (liste || []).find(x => String(x.id) === String(id));
async function rhAgir(appel, message, apres) {
  const r = await agir(appel, message);
  if (r) { if (apres) apres(r); await chargerRH(); }
  return r;
}
Object.assign(ACTIONS, {
  rhSub: el => { rhUI().sub = el.dataset.sub; render(); },
  rhEmploye: el => { const D = rhUI().data; formEmploye(el.dataset.id ? rhTrouve(D.employes, el.dataset.id) : null, D); },
  rhEnregistrerEmploye: async el => {
    const g = id => { const x = $('#' + id); return x ? x.value : ''; }, id = el.dataset.id, D = rhUI().data;
    const corps = { nom: g('em-nom'), prenoms: g('em-prenoms'), sexe: g('em-sexe'), telephone: g('em-tel'), fonction: g('em-fonction'), service: g('em-service'), contrat: g('em-contrat'),
      embauche_le: g('em-embauche'), fin_contrat: g('em-fin') || null, numero_cnps: g('em-cnps'), mode_paiement: g('em-mode'), utilisateur_id: g('em-compte') || null };
    if (D.voir_salaires) Object.assign(corps, { salaire_base: Number(g('em-salaire') || 0), taux_garde: Number(g('em-garde') || 0), taux_vacation: Number(g('em-vacation') || 0) });
    await rhAgir(() => api(id ? 'PUT' : 'POST', '/api/rh/employes' + (id ? '/' + id : ''), corps), id ? 'Fiche mise à jour.' : 'Employé enregistré.', () => closeModal());
  },
  rhArchiver: el => {
    openModal(`<div class="modal-head"><h2>Départ de l’employé</h2>${closeBtn()}</div>
      ${champ('Date de sortie', `<input type="date" id="ar-date" value="${todayISO()}">`)}${champ('Motif', '<input id="ar-motif" maxlength="200" placeholder="Ex. fin de CDD, démission">')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhConfirmerArchivage" data-id="${el.dataset.id}">Archiver</button></div>`);
  },
  rhConfirmerArchivage: async el => rhAgir(() => api('POST', `/api/rh/employes/${el.dataset.id}/archivage`, { sortie_le: $('#ar-date').value, motif: $('#ar-motif').value }), 'Employé archivé.', () => closeModal()),
  rhReprise: async () => rhAgir(() => api('POST', '/api/rh/reprise-comptes'), r => `${r.crees} fiche${r.crees > 1 ? 's' : ''} créée${r.crees > 1 ? 's' : ''} depuis les comptes : complétez contrats et salaires.`),
  rhSemaine: el => { const ui = rhUI(), d = Number(el.dataset.d); ui.lundi = d ? decalerJour(ui.data.lundi, d) : ''; chargerRH(); },
  rhRecopie: async () => rhAgir(() => api('POST', '/api/rh/planning/recopie', { lundi: rhUI().data.lundi }), r => `${r.copies} créneau${r.copies > 1 ? 'x' : ''} recopié${r.copies > 1 ? 's' : ''}${r.ignores ? `, ${r.ignores} ignoré${r.ignores > 1 ? 's' : ''} (déjà occupé)` : ''}.`),
  rhCreneau: () => {
    const D = rhUI().data, defaut = D.lundi <= todayISO() && todayISO() <= decalerJour(D.lundi, 6) ? todayISO() : D.lundi;
    openModal(`<div class="modal-head"><h2>Ajouter un créneau</h2>${closeBtn()}</div>
      <div class="form-grid">
        ${champ('Employé', `<select id="cr-employe"><option value="">Choisir</option>${D.employes.filter(e => e.actif).map(e => `<option value="${e.id}">${esc(nomEmp(e))}, ${esc(e.fonction.toLowerCase())}</option>`).join('')}</select>`)}
        ${champ('Type', `<select id="cr-type">${Object.entries(LIB_CRENEAU).map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select>`)}
        ${champ('Date', `<input type="date" id="cr-jour" value="${defaut}">`)}
        ${champ('Début', '<input type="time" id="cr-debut" value="18:00">')}${champ('Fin', '<input type="time" id="cr-fin" value="08:00">', 'Une fin plus tôt que le début franchit minuit ; début égal à la fin : 24 heures.')}
      </div>
      <div class="row-actions">${PRESETS_CRENEAU.map(([l, a, b]) => `<button type="button" class="btn btn-ghost btn-sm" data-action="rhPreset" data-a="${a}" data-b="${b}">${l}</button>`).join('')}</div>
      ${champ('Observation', '<input id="cr-obs" maxlength="200" placeholder="Facultatif">')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhEnregistrerCreneau">Enregistrer</button></div>`);
  },
  rhPreset: el => { $('#cr-debut').value = el.dataset.a; $('#cr-fin').value = el.dataset.b; },
  rhEnregistrerCreneau: async () => rhAgir(() => api('POST', '/api/rh/planning', { employe_id: Number($('#cr-employe').value) || null, type: $('#cr-type').value, jour: $('#cr-jour').value, debut: $('#cr-debut').value, fin: $('#cr-fin').value, observation: $('#cr-obs').value }),
    'Créneau ajouté au planning.', () => closeModal()),
  rhCreneauVoir: el => {
    const c = rhTrouve(rhUI().data.planning, el.dataset.id);
    if (!c) return;
    openModal(`<div class="modal-head"><h2>${esc(LIB_CRENEAU[c.type])} : ${esc(nomEmp(c))}</h2>${closeBtn()}</div>
      <p>${nomJour(c.jour)} ${fmtDate(c.jour)}, de ${c.debut} à ${c.fin}${c.observation ? `. ${esc(c.observation)}` : ''}.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button>${peut('rh_gerer') ? `<button class="btn" data-action="rhAnnulerCreneau" data-id="${c.id}">${peut('supprimer') ? 'Annuler ce créneau' : 'Demander l’annulation'}</button>` : ''}</div>`);
  },
  rhAnnulerCreneau: async el => !peut('supprimer') ? demanderSuppression({ objet: 'creneau', id: el.dataset.id, titre: 'Demander l’annulation du créneau',
    description: 'L’administrateur annulera ce créneau de planning : il ne comptera plus (gardes et vacations de la paie).' }) : rhAgir(() => api('POST', `/api/rh/planning/${el.dataset.id}/annulation`), 'Créneau annulé.', () => closeModal()),
  rhImprimerPlanning: () => apercuA4('Planning de la semaine', planningHTML(rhUI().data)),
  rhMois: el => { const ui = rhUI(); ui.periode = decalerMois(ui.data.periode, Number(el.dataset.d)); chargerRH(); },
  rhPreparer: async () => rhAgir(() => api('POST', '/api/rh/paies/preparation', { periode: rhUI().data.periode }),
    r => `${r.prepares.length} bulletin${r.prepares.length > 1 ? 's' : ''} préparé${r.prepares.length > 1 ? 's' : ''}${r.erreurs.length ? `, ${r.erreurs.length} non préparé${r.erreurs.length > 1 ? 's' : ''}` : ''}.`,
    r => { if (r.erreurs.length) openModal(`<div class="modal-head"><h2>Bulletins non préparés</h2>${closeBtn()}</div><ul class="list">${r.erreurs.map(x => `<li><strong>${esc(x.employe)}</strong> (${esc(x.matricule)}) : ${esc(x.message)}</li>`).join('')}</ul>
      <div class="modal-actions"><button class="btn" data-action="closeModal">Fermer</button></div>`); }),
  rhValiderTout: async () => rhAgir(() => api('POST', '/api/rh/paies/validation', { periode: rhUI().data.periode }), r => `${r.valides} bulletin${r.valides > 1 ? 's' : ''} validé${r.valides > 1 ? 's' : ''}.`),
  rhValider: async el => rhAgir(() => api('POST', '/api/rh/paies/validation', { id: Number(el.dataset.id) }), 'Bulletin validé.'),
  rhBulletin: el => { const D = rhUI().data, p = rhTrouve(D.paies, el.dataset.id); if (p) apercuA4('Bulletin de paie', bulletinHTML(p, D)); },
  rhJournal: () => apercuA4('Journal de paie', journalPaieHTML(rhUI().data)),
  rhModifierBulletin: el => { const p = rhTrouve(rhUI().data.paies, el.dataset.id); if (p) formBulletin(p); },
  rhAjouterLigne: () => { const z = $('#bp-lignes'); if (z) z.insertAdjacentHTML('beforeend', ligneBulletinHTML(null)); },
  rhRetirerLigne: el => { const l = el.closest('.bp-ligne'); if (l) l.remove(); },
  rhEnregistrerBulletin: async el => {
    const its = $('#bp-its').value;
    const lignes = [...document.querySelectorAll('#bp-lignes .bp-ligne')].map(l => ({ type: l.querySelector('.bp-type').value, libelle: l.querySelector('.bp-libelle').value, montant: Number(l.querySelector('.bp-montant').value || 0), non_soumis: l.querySelector('.bp-non-soumis').checked }))
      .filter(l => l.libelle.trim() || l.montant);
    await rhAgir(() => api('PUT', `/api/rh/paies/${el.dataset.id}/lignes`, { its: its === '' ? null : Number(its), lignes }), r => `Bulletin enregistré : net ${money(r.net)}.`, () => closeModal());
  },
  rhPayer: el => {
    const D = rhUI().data, p = rhTrouve(D.paies, el.dataset.id), e = p && rhTrouve(D.employes, p.employe_id);
    if (!p) return;
    openModal(`<div class="modal-head"><h2>Paiement de ${esc(nomEmp(p))}</h2>${closeBtn()}</div><p>Net à payer : <strong>${money(p.net)}</strong> (${esc(p.numero)}).</p>
      <div class="form-grid">${champ('Mode de paiement', `<select id="py-mode">${D.constantes.MODES_PAIEMENT.map(m => `<option${e && e.mode_paiement === m ? ' selected' : ''}>${esc(m)}</option>`).join('')}</select>`)}
      ${champ('Référence', '<input id="py-ref" maxlength="60" placeholder="N° de virement, de transaction…">')}</div>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhConfirmerPaiement" data-id="${p.id}">Enregistrer le paiement</button></div>`);
  },
  rhConfirmerPaiement: async el => rhAgir(() => api('POST', `/api/rh/paies/${el.dataset.id}/paiement`, { mode: $('#py-mode').value, reference: $('#py-ref').value }), 'Paiement enregistré.', () => closeModal()),
  rhAnnulerBulletin: el => {
    if (!peut('supprimer')) return demanderSuppression({ objet: 'bulletin', id: el.dataset.id, titre: 'Demander l’annulation du bulletin',
      description: 'L’administrateur annulera ce bulletin de paie ; les avances qu’il déduisait seront reprises sur la paie suivante.' });
    openModal(`<div class="modal-head"><h2>Annuler le bulletin</h2>${closeBtn()}</div>${champ('Motif', '<input id="an-motif" maxlength="200" placeholder="Ex. erreur sur le salaire de base">', 'Les avances déduites redeviennent à déduire.')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Retour</button><button class="btn" data-action="rhConfirmerAnnulation" data-id="${el.dataset.id}">Annuler le bulletin</button></div>`);
  },
  rhConfirmerAnnulation: async el => rhAgir(() => api('POST', `/api/rh/paies/${el.dataset.id}/annulation`, { motif: $('#an-motif').value }), 'Bulletin annulé.', () => closeModal()),
  rhAvance: () => {
    const D = rhUI().data;
    openModal(`<div class="modal-head"><h2>Accorder une avance sur salaire</h2>${closeBtn()}</div>
      <div class="form-grid">${champ('Employé', `<select id="av-employe"><option value="">Choisir</option>${D.employes.filter(e => e.actif).map(e => `<option value="${e.id}">${esc(nomEmp(e))}</option>`).join('')}</select>`)}
      ${champ('Montant (FCFA)', '<input id="av-montant" type="number" min="1">')}</div>${champ('Motif', '<input id="av-motif" maxlength="200" placeholder="Facultatif">')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="rhConfirmerAvance">Accorder</button></div>`);
  },
  rhConfirmerAvance: async () => rhAgir(() => api('POST', '/api/rh/avances', { employe_id: Number($('#av-employe').value) || null, montant: Number($('#av-montant').value || 0), motif: $('#av-motif').value }),
    'Avance accordée : elle sera déduite de la prochaine paie.', () => closeModal()),
  rhEnregistrerParametres: async () => rhAgir(() => api('PUT', '/api/rh/parametres', { taux_cnps: $('#pp-taux').value, plafond_cnps: Number($('#pp-plafond').value || 0), cmu: Number($('#pp-cmu').value || 0), cnps_employeur: $('#pp-employeur').value }),
    'Paramètres de paie enregistrés.'),
  /* « Mon planning » : ouvert à chaque utilisateur depuis son menu de compte. */
  monPlanning: async () => {
    let r;
    try { r = await api('GET', '/api/rh/mon-planning'); } catch (e) { toast(e.message || 'Planning indisponible.', 'bad'); return; }
    openModal(`<div class="modal-head"><h2>Mon planning</h2>${closeBtn()}</div>
      ${!r.lie ? '<p class="muted">Votre compte n’est pas encore relié à une fiche du personnel : adressez-vous aux ressources humaines.</p>'
        : r.creneaux.length ? `<ul class="list mon-planning">${r.creneaux.map(c => `<li><strong>${nomJour(c.jour)} ${fmtDate(c.jour)}</strong> : ${esc(LIB_CRENEAU[c.type] || c.type)}, de ${c.debut} à ${c.fin}${c.observation ? ` (${esc(c.observation)})` : ''}</li>`).join('')}</ul>`
        : '<p class="muted">Aucun créneau prévu dans les 30 prochains jours.</p>'}
      <div class="modal-actions"><button class="btn" data-action="closeModal">Fermer</button></div>`);
  }
});
ONGLETS.push({ id: 'rh', libelle: 'Ressources humaines', icone: 'rh', visible: () => peut('rh_lire'), compteur: () => 0, vue: vRH });
