'use strict';
/* Poste Paramétrage : référentiels et tarifs (RAF, direction), paramètres sensibles (direction), comptes et sauvegardes (administrateur). */
const oui = [['1', 'Oui'], ['0', 'Non']];
const REF = {
  chambres: {
    titre: 'Chambres d’hospitalisation', etiquette: 'chambre', liste: () => E.chambres || [],
    champs: [{ k: 'code', l: 'Numéro' }, { k: 'nom', l: 'Libellé' }, { k: 'categorie', l: 'Catégorie', t: 'select', o: [['standard', 'Standard'], ['vip', 'VIP']] },
      { k: 'lits', l: 'Nombre de lits', t: 'number' }, { k: 'actif', l: 'Chambre ouverte', t: 'check' }],
    ligne: c => `<td><strong>${esc(c.code)}</strong></td><td>${esc(c.nom)}</td><td>${c.categorie === 'vip' ? 'VIP' : 'Standard'}</td><td class="num">${c.lits}</td>`,
    entetes: '<th>Numéro</th><th>Libellé</th><th>Catégorie</th><th class="num">Lits</th>'
  },
  actes: {
    titre: 'Actes et tarifs', etiquette: 'acte', liste: () => E.actes,
    champs: [{ k: 'code', l: 'Code' }, { k: 'libelle', l: 'Libellé' }, { k: 'famille', l: 'Famille' }, { k: 'specialite', l: 'Spécialité (consultations)' },
      { k: 'prix_non', l: 'Prix non assurés', t: 'number' }, { k: 'prix_maj', l: 'Prix assurances majeures', t: 'number' }, { k: 'prix_aut', l: 'Prix autres assurances', t: 'number' }, { k: 'actif', l: 'Actif', t: 'check' }],
    ligne: a => `<td><strong>${esc(a.code)}</strong></td><td>${esc(a.libelle)}<div class="muted">${esc(a.famille)}${a.specialite ? ', ' + esc(a.specialite) : ''}</div></td><td class="num">${money(a.prix_non)}</td><td class="num">${money(a.prix_maj)}</td><td class="num">${money(a.prix_aut)}</td>`,
    entetes: '<th>Code</th><th>Libellé</th><th class="num">Non assurés</th><th class="num">Assur. majeures</th><th class="num">Autres assur.</th>'
  },
  produits: {
    titre: 'Produits de la pharmacie', etiquette: 'produit', liste: () => E.produits,
    champs: [{ k: 'code', l: 'Code' }, { k: 'nom', l: 'Nom commercial' }, { k: 'dci', l: 'DCI' }, { k: 'forme', l: 'Forme et dosage' }, { k: 'famille', l: 'Famille' }, { k: 'seuil', l: 'Seuil minimal', t: 'number' },
      { k: 'prix_non', l: 'Prix non assurés', t: 'number' }, { k: 'prix_maj', l: 'Prix assurances majeures', t: 'number' }, { k: 'prix_aut', l: 'Prix autres assurances', t: 'number' },
      { k: 'psychotrope', l: 'Psychotrope ou stupéfiant (registre)', t: 'check' }, { k: 'actif', l: 'Actif', t: 'check' }],
    ligne: p => `<td><strong>${esc(p.code)}</strong></td><td>${esc(p.nom)}<div class="muted">${esc(p.dci || '')}${p.psychotrope ? ', psychotrope' : ''}</div></td><td class="num">${money(p.prix_non)}</td><td class="num">${money(p.prix_maj)}</td><td class="num">${money(p.prix_aut)}</td>`,
    entetes: '<th>Code</th><th>Produit</th><th class="num">Non assurés</th><th class="num">Assur. majeures</th><th class="num">Autres assur.</th>'
  },
  assureurs: {
    titre: 'Assureurs et gestionnaires', etiquette: 'assureur', liste: () => E.assureurs,
    champs: [{ k: 'code', l: 'Code' }, { k: 'nom', l: 'Nom' }, { k: 'niveau', l: 'Niveau de prix pharmacie', t: 'select', o: [['maj', 'Assurances majeures'], ['aut', 'Autres assurances']] }, { k: 'actif', l: 'Convention active', t: 'check' }],
    ligne: a => `<td><strong>${esc(a.code)}</strong></td><td>${esc(a.nom)}</td><td>${a.niveau === 'maj' ? 'Assurances majeures' : 'Autres assurances'}</td>`,
    entetes: '<th>Code</th><th>Nom</th><th>Niveau de prix</th>'
  }
};
const MODELES = {
  produits: 'code;nom;dci;forme;famille;seuil;prix_non;prix_maj;prix_aut;psychotrope;lot;peremption;quantite;prix_achat;fournisseur\nPARA500;Paracétamol 500 mg;Paracétamol;Comprimé;Antalgique;30;1000;1500;1300;non;PAR-2604;2027-04-30;200;600;Laborex\n',
  actes: 'code;libelle;famille;specialite;prix_non;prix_maj;prix_aut;actif\nB-NFS;NFS (hémogramme);Laboratoire;;6000;6000;6000;1\n'
};

function formulaire(champs, v) {
  return `<div class="form-grid two">${champs.map(c => {
    const id = 'fm-' + c.k, val = v[c.k];
    if (c.t === 'select') return champ(c.l, `<select id="${id}">${c.o.map(([k, l]) => `<option value="${esc(k)}"${String(val) === String(k) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`);
    if (c.t === 'check') return `<label class="case"><input type="checkbox" id="${id}"${val ? ' checked' : ''}> ${esc(c.l)}</label>`;
    return champ(c.l, `<input id="${id}" type="${c.t || 'text'}" value="${esc(val == null ? '' : val)}" autocomplete="off"${c.t === 'number' ? ' min="0" inputmode="numeric"' : ''}>`);
  }).join('')}</div>`;
}
function lireFormulaire(champs) {
  const o = {};
  for (const c of champs) { const el = $('#fm-' + c.k); o[c.k] = c.t === 'check' ? el.checked : c.t === 'number' ? (el.value === '' ? '' : Number(el.value)) : el.value; }
  return o;
}

function vParametrage() {
  const subs = [
    ['actes', 'Tarifs des actes', 'referentiels'], ['produits', 'Produits', 'referentiels'], ['assureurs', 'Assureurs', 'referentiels'], ['chambres', 'Chambres', 'referentiels'], ['imports', 'Imports', 'referentiels'],
    ['parametres', 'Paramètres', 'parametres'], ['comptes', 'Comptes', 'utilisateurs'], ['sauvegardes', 'Sauvegardes', 'sauvegardes'], ['journal', 'Journal', 'audit']
  ].filter(s => peut(s[2]));
  if (!subs.some(s => s[0] === UI.adm.sub)) UI.adm.sub = subs[0][0];
  const s = UI.adm.sub;
  const corps = REF[s] ? vReferentiel(s) : s === 'imports' ? vImports() : s === 'parametres' ? vParametres() : s === 'comptes' ? vComptes() : s === 'sauvegardes' ? vSauvegardes() : vJournal();
  return `<div class="view-head"><div><h1>Paramétrage</h1><p class="lead">Référentiels, tarifs, comptes et sécurité. Chaque modification est journalisée avec l’avant et l’après.</p></div></div>
    <div class="seg" role="group" aria-label="Rubriques du paramétrage">${subs.map(([k, l]) => `<button data-action="admSub" data-sub="${k}" aria-pressed="${s === k}">${l}</button>`).join('')}</div>${corps}`;
}
function vReferentiel(t) {
  const R = REF[t], f = UI.adm.filtre.toLowerCase();
  const liste = R.liste().filter(x => !f || JSON.stringify(x).toLowerCase().includes(f));
  const aValider = R.liste().filter(x => x.a_valider && x.actif).length;
  return `<div class="panel"><div class="panel-head"><h2>${R.titre}</h2><button class="btn btn-sm" data-action="refNouveau" data-t="${t}">${icon('plus', 16)}Ajouter</button></div>
    ${aValider ? `<div class="notice bad">${aValider} tarif(s) à vérifier : aucune facturation n’est possible sur ces lignes tant qu’elles ne sont pas validées. Ouvrez chaque ligne, contrôlez les prix, puis enregistrez.</div>` : ''}
    ${champ('Filtrer', `<input type="search" value="${esc(UI.adm.filtre)}" data-input="admFiltre" placeholder="Code, libellé, famille" autocomplete="off">`)}
    <div class="table-wrap"><table><thead><tr>${R.entetes}<th>Statut</th><th></th></tr></thead><tbody>${liste.map(x => `<tr>${R.ligne(x)}
      <td>${!x.actif ? '<span class="badge b-muted">Inactif</span>' : x.a_valider ? '<span class="badge b-bad">À valider</span>' : '<span class="badge b-ok">Actif</span>'}</td>
      <td class="actions"><button class="btn btn-sm btn-ghost" data-action="refModifier" data-t="${t}" data-id="${x.id}">${x.a_valider ? 'Vérifier' : 'Modifier'}</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function vImports() {
  return `<div class="grid-2 wide-right">${['produits', 'actes'].map(t => `<section class="panel"><h2>Importer ${t === 'produits' ? 'le catalogue de la pharmacie' : 'les actes et tarifs'}</h2>
    <p class="muted">${t === 'produits' ? 'Un produit par ligne, mis à jour par son code. Les colonnes lot, peremption, quantite, prix_achat et fournisseur créent le stock initial.' : 'Un acte par ligne, mis à jour par son code. Les tarifs importés sont considérés comme validés.'}</p>
    <div class="row-actions"><button class="btn btn-sm btn-ghost" data-action="modele" data-t="${t}">Télécharger le modèle</button></div>
    ${champ('Fichier CSV (séparateur point-virgule, dates AAAA-MM-JJ)', `<input type="file" accept=".csv,text/csv" id="imp-${t}">`)}
    <button class="btn btn-block" data-action="importer" data-t="${t}">Importer</button><div id="imp-res-${t}"></div>
    <p class="hint">L’import est tout ou rien : une seule ligne en erreur annule l’ensemble, avec la liste des lignes à corriger.</p></section>`).join('')}</div>`;
}
function vParametres() {
  const p = E.parametres;
  const champs = [
    { k: 'plafond_remise', l: 'Plafond de remise sans validation (%)', t: 'number' }, { k: 'delai_controle', l: 'Délai du contrôle gratuit (jours)', t: 'number' },
    { k: 'seuil_ajustement', l: 'Seuil de validation des ajustements de stock (FCFA)', t: 'number' }, { k: 'inactivite_min', l: 'Déconnexion après inactivité (minutes)', t: 'number' },
    { k: 'vacation_debut', l: 'Début de la permanence de jour (heure)', t: 'number' }, { k: 'vacation_fin', l: 'Début de la garde (heure)', t: 'number' },
    { k: 'acte_urgence', l: 'Code de l’acte d’urgence' }, { k: 'raison', l: 'Raison sociale' }, { k: 'forme', l: 'Forme et capital' }, { k: 'adresse', l: 'Adresse' },
    { k: 'rccm', l: 'RCCM' }, { k: 'ncc', l: 'N° de compte contribuable' }, { k: 'telephone', l: 'Téléphone' }, { k: 'slogan', l: 'Slogan des reçus' }
  ];
  UI.adm.champsParam = champs;
  return `<div class="panel"><h2>Paramètres de la clinique</h2>${formulaire(champs, p)}
    <p class="hint">Paramètres sensibles : chaque changement est journalisé avec l’ancienne et la nouvelle valeur.</p>
    <button class="btn" data-action="paramEnregistrer">Enregistrer les paramètres</button></div>`;
}
function vComptes() {
  if (UI.adm.users === null) { UI.adm.users = []; chargerComptes(); }
  return `<div class="panel"><div class="panel-head"><h2>Comptes du personnel</h2><button class="btn btn-sm" data-action="compteNouveau">${icon('plus', 16)}Créer un compte</button></div>
    <p class="muted">Un compte par personne, jamais partagé. Un même compte ne peut pas encaisser et délivrer.</p>
    <div class="table-wrap"><table><thead><tr><th>Nom</th><th>Identifiant</th><th>Profils</th><th>Dernière connexion</th><th>Statut</th><th></th></tr></thead><tbody>${UI.adm.users.map(u => `<tr>
      <td><strong>${esc(u.nom)}</strong></td><td>${esc(u.login)}</td><td>${u.roles.split(',').map(r => esc(MOI.roles_libelles[r] || r)).join(', ')}</td>
      <td>${u.derniere_connexion ? fmtDateTime(u.derniere_connexion) : 'Jamais'}</td>
      <td>${!u.actif ? '<span class="badge b-muted">Désactivé</span>' : u.bloque_jusqua && u.bloque_jusqua > new Date().toISOString() ? '<span class="badge b-bad">Bloqué</span>' : u.changer_mdp ? '<span class="badge b-warn">Mot de passe provisoire</span>' : '<span class="badge b-ok">Actif</span>'}</td>
      <td class="actions"><button class="btn btn-sm btn-ghost" data-action="compteModifier" data-id="${u.id}">Modifier</button><button class="btn btn-sm btn-ghost" data-action="compteReinit" data-id="${u.id}">Réinitialiser</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
async function chargerComptes() {
  try { UI.adm.users = await api('GET', '/api/utilisateurs'); if (UI.tab === 'parametrage' && UI.adm.sub === 'comptes' && !modalOuverte()) render(); } catch (e) { toast(e.message, 'bad'); }
}
function formCompte(u) {
  const roles = (u && u.roles ? u.roles.split(',') : []);
  return `${u ? '' : champ('Identifiant', '<input id="cp-login" placeholder="prenom.nom" autocomplete="off" autocapitalize="none">')}
    ${champ('Nom complet', `<input id="cp-nom" value="${esc(u ? u.nom : '')}" autocomplete="off">`)}
    <fieldset class="cases"><legend>Profils</legend>${Object.entries(MOI.roles_libelles).map(([k, l]) => `<label><input type="checkbox" name="cp-role" value="${k}"${roles.includes(k) ? ' checked' : ''}> ${esc(l)}</label>`).join('')}</fieldset>
    <fieldset class="cases"><legend>Spécialités (profil médecin)</legend>${MSI_SPECIALITES.noms().map(n => `<label><input type="checkbox" name="cp-sp" value="${esc(n)}"${u && String(u.specialites || '').split(',').includes(n) ? ' checked' : ''}> ${esc(n)}</label>`).join('')}</fieldset>
    ${champ('N° d’inscription à l’Ordre (médecin)', `<input id="cp-ordre" value="${esc(u ? u.ordre || '' : '')}" autocomplete="off">`)}
    ${champ('Téléphone (SMS et WhatsApp)', `<input id="cp-tel" value="${esc(u ? u.telephone || '' : '')}" inputmode="tel" autocomplete="off" placeholder="07 00 00 00 00">`)}
    ${u ? `<label class="case"><input type="checkbox" id="cp-actif"${u.actif ? ' checked' : ''}> Compte actif</label>` : ''}`;
}
const rolesCoches = () => [...document.querySelectorAll('input[name="cp-role"]:checked')].map(x => x.value);
const specialitesCochees = () => [...document.querySelectorAll('input[name="cp-sp"]:checked')].map(x => x.value);
function afficherMdp(r) {
  openModal(`<div class="modal-head"><h2>Mot de passe provisoire</h2>${closeBtn()}</div>
    <p>Remettez ce mot de passe en main propre à la personne. Il ne sera plus affiché ; il devra être changé à la première connexion.</p>
    <div class="notice ok"><div>Identifiant : <strong>${esc(r.login)}</strong></div><div>Mot de passe : <strong class="mdp">${esc(r.mdp)}</strong></div></div>
    <div class="modal-actions"><button class="btn" data-action="closeModal">C’est noté</button></div>`, { noFocus: true });
}
function vSauvegardes() {
  if (UI.adm.sauv === null) { UI.adm.sauv = {}; chargerSauvegardes(); }
  const s = UI.adm.sauv, d = s.derniere;
  return `<div class="panel"><h2>Sauvegardes</h2>
    <p class="muted">Copie chiffrée de la base toutes les 15 minutes, sur ce serveur et dans le dossier synchronisé avec le cloud. Perte maximale en cas de sinistre : 15 minutes.</p>
    ${d ? `<div class="notice ${s.erreur ? 'bad' : 'ok'}">Dernière sauvegarde ${fmtDateTime(d.le)} : ${esc(d.fichier)}, ${NF.format(Math.round(d.taille / 1024))} Ko, copie cloud ${esc(d.cloud)}.</div>` : '<div class="notice warn">Aucune sauvegarde depuis le démarrage du serveur (la première a lieu une minute après).</div>'}
    ${s.erreur ? `<div class="notice bad">Erreur : ${esc(s.erreur)}</div>` : ''}
    <button class="btn" data-action="sauvegarder">Sauvegarder maintenant</button>
    <p class="hint">La clé de chiffrement (donnees/cle-sauvegarde.key) doit être copiée sur une clé USB rangée au coffre : sans elle, les sauvegardes sont illisibles.</p></div>`;
}
async function chargerSauvegardes() {
  try { UI.adm.sauv = await api('GET', '/api/sauvegardes'); if (UI.tab === 'parametrage' && UI.adm.sub === 'sauvegardes' && !modalOuverte()) render(); } catch (e) { toast(e.message, 'bad'); }
}
function vJournal() {
  const v = UI.adm.integrite;
  return `<div class="panel"><h2>Intégrité du journal d’audit</h2>
    <p class="muted">Chaque opération est scellée par une empreinte qui dépend de la précédente : toute retouche de l’historique rompt la chaîne et devient visible.</p>
    ${v ? `<div class="notice ${v.ok ? 'ok' : 'bad'}">${v.ok ? `Journal intègre : ${NF.format(v.lignes)} opérations vérifiées.` : `Chaîne rompue à l’opération n° ${v.rupture} : alertez immédiatement la direction.`}</div>` : ''}
    <button class="btn" data-action="verifierJournal">Vérifier maintenant</button></div>`;
}

Object.assign(ACTIONS, {
  admSub: el => { UI.adm.sub = el.dataset.sub; UI.adm.filtre = ''; if (el.dataset.sub === 'comptes') UI.adm.users = null; if (el.dataset.sub === 'sauvegardes') UI.adm.sauv = null; render(); },
  refNouveau: el => ACTIONS.refModifier(el),
  refModifier: el => {
    const t = el.dataset.t, R = REF[t], x = el.dataset.id ? R.liste().find(y => y.id === Number(el.dataset.id)) : { actif: 1, niveau: 'aut' };
    UI.adm.ref = { t, id: x.id || null };
    openModal(`<div class="modal-head"><h2>${x.id ? (x.a_valider ? 'Vérifier' : 'Modifier') : 'Ajouter'} : ${R.etiquette}</h2>${closeBtn()}</div>${formulaire(R.champs, x)}
      ${x.a_valider ? '<div class="notice warn">Tarif de démonstration : contrôlez chaque prix avant d’enregistrer. L’enregistrement vaut validation.</div>' : ''}
      <p class="hint">Les factures passées ne changent pas : chaque bon garde le prix de sa date.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="refEnregistrer">${x.a_valider ? 'Valider ce tarif' : 'Enregistrer'}</button></div>`, { large: true });
  },
  refEnregistrer: async () => {
    const { t, id } = UI.adm.ref, d = lireFormulaire(REF[t].champs);
    if (await agir(() => (id ? api('PUT', `/api/referentiels/${t}/${id}`, d) : api('POST', `/api/referentiels/${t}`, d)), 'Enregistré et journalisé.')) closeModal();
  },
  modele: el => telecharger(`modele-${el.dataset.t}.csv`, '\ufeff' + MODELES[el.dataset.t]),
  importer: el => {
    const t = el.dataset.t, f = $('#imp-' + t).files[0];
    if (!f) { toast('Choisissez un fichier CSV.', 'bad'); return; }
    const lecteur = new FileReader();
    lecteur.onload = () => agir(() => api('POST', '/api/imports/' + t, { csv: lecteur.result }), r => `Import réussi : ${r.crees} créé(s), ${r.modifies} mis à jour${r.lots ? ', ' + r.lots + ' lot(s) de stock initial' : ''}.`, e => {
      if (e.data && e.data.erreurs) { $('#imp-res-' + t).innerHTML = `<div class="notice bad">${esc(e.message)}<ul>${e.data.erreurs.slice(0, 20).map(x => `<li>Ligne ${x.ligne} : ${esc(x.message)}</li>`).join('')}</ul></div>`; return true; }
      return false;
    });
    lecteur.readAsText(f, 'utf-8');
  },
  paramEnregistrer: () => agir(() => api('PUT', '/api/parametres', lireFormulaire(UI.adm.champsParam)), r => (r.modifies ? `${r.modifies} paramètre(s) modifié(s) et journalisé(s).` : 'Aucun changement.')),
  compteNouveau: () => openModal(`<div class="modal-head"><h2>Créer un compte</h2>${closeBtn()}</div>${formCompte(null)}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="compteCreer">Créer le compte</button></div>`),
  compteCreer: async () => {
    const r = await agir(() => api('POST', '/api/utilisateurs', { login: $('#cp-login').value, nom: $('#cp-nom').value, roles: rolesCoches(), specialites: specialitesCochees(), ordre: $('#cp-ordre').value, telephone: $('#cp-tel').value }));
    if (r) { UI.adm.users = null; render(); afficherMdp(r); }
  },
  compteModifier: el => {
    const u = UI.adm.users.find(x => x.id === Number(el.dataset.id));
    UI.adm.compte = u.id;
    openModal(`<div class="modal-head"><h2>Modifier le compte ${esc(u.login)}</h2>${closeBtn()}</div>${formCompte(u)}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="compteEnregistrer">Enregistrer</button></div>`);
  },
  compteEnregistrer: async () => {
    if (await agir(() => api('PUT', '/api/utilisateurs/' + UI.adm.compte, { nom: $('#cp-nom').value, roles: rolesCoches(), actif: $('#cp-actif').checked, specialites: specialitesCochees(), ordre: $('#cp-ordre').value, telephone: $('#cp-tel').value }), 'Compte mis à jour.')) { closeModal(); UI.adm.users = null; render(); }
  },
  compteReinit: async el => {
    const r = await agir(() => api('POST', `/api/utilisateurs/${el.dataset.id}/reinitialisation`));
    if (r) { UI.adm.users = null; render(); afficherMdp(r); }
  },
  sauvegarder: async () => {
    const r = await agir(() => api('POST', '/api/sauvegardes'));
    if (r) { UI.adm.sauv = r; render(); toast(r.erreur ? 'Sauvegarde en erreur : ' + r.erreur : 'Sauvegarde effectuée.', r.erreur ? 'bad' : null); }
  },
  verifierJournal: async () => { try { UI.adm.integrite = await api('GET', '/api/audit/verification'); render(); } catch (e) { toast(e.message, 'bad'); } }
});
Object.assign(INPUTS, {
  admFiltre: el => {
    UI.adm.filtre = el.value;
    const pos = el.selectionStart;
    render();
    const n = $('input[data-input="admFiltre"]');
    if (n) { n.focus(); n.setSelectionRange(pos, pos); }
  }
});
ONGLETS.push({
  id: 'parametrage', libelle: 'Paramétrage', icone: 'parametrage', visible: () => ['referentiels', 'parametres', 'utilisateurs', 'sauvegardes', 'audit'].some(peut),
  compteur: () => (peut('referentiels') ? E.actes.filter(a => a.a_valider && a.actif).length + E.produits.filter(p => p.a_valider && p.actif).length : 0), vue: vParametrage
});
