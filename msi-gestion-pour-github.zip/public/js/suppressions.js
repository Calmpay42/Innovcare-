'use strict';
/* Suppressions (v2.2) : l'administrateur décide des demandes de suppression et d'annulation de reçus, chacune avec son motif.
   Rien n'est effacé : l'élément accepté est annulé, il cesse de compter et reste dans l'historique avec la demande et la décision. */
function vSuppressions() {
  const l = E.suppressions || [], att = l.filter(d => d.statut === 'en_attente'), faites = l.filter(d => d.statut !== 'en_attente');
  return `<div class="view-head"><div><h1>Suppressions</h1><p class="lead">Seul l’administrateur supprime. Chaque demande arrive avec son motif ; l’élément accepté est annulé, il cesse de compter et reste dans l’historique.</p></div></div>
    <div class="panel"><h2>Demandes en attente${att.length ? ` <span class="badge b-warn">${att.length}</span>` : ''}</h2>
      ${att.length ? `<ul class="list sup-liste">${att.map(d => `<li><div><strong>${esc(d.libelle)}</strong><div>${esc(d.description)}</div>
        <div class="sup-motif">Motif : ${esc(d.motif || '')}</div><small class="muted">Demandé par ${esc(d.demandeur || '')}, ${fmtDateTime(d.cree_le)}</small></div>
        <div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="supRefuser" data-id="${d.id}">Refuser</button><button class="btn btn-danger btn-sm" data-action="supAccepter" data-id="${d.id}">Accepter et supprimer</button></div></li>`).join('')}</ul>`
        : '<p class="muted">Aucune demande en attente.</p>'}</div>
    <div class="panel"><h2>Décisions des 30 derniers jours</h2>
      ${faites.length ? `<ul class="list">${faites.map(d => `<li><div><strong>${esc(d.libelle)}</strong> <span class="badge ${d.statut === 'validee' ? 'b-ok' : 'b-bad'}">${d.statut === 'validee' ? 'Acceptée' : 'Refusée'}</span>
        <div>${esc(d.description)}</div><small class="muted">Motif : ${esc(d.motif || '')} ; demandé par ${esc(d.demandeur || '')} ; décidé par ${esc(d.decideur || '')} ${fmtDateTime(d.decide_le)}${d.reponse ? ` ; réponse : ${esc(d.reponse)}` : ''}</small></div></li>`).join('')}</ul>`
        : '<p class="muted">Aucune décision récente.</p>'}</div>`;
}
const supDemande = id => (E.suppressions || []).find(x => String(x.id) === String(id));
Object.assign(ACTIONS, {
  supAccepter: el => {
    const d = supDemande(el.dataset.id);
    if (!d) return;
    openModal(`<div class="modal-head"><h2>Accepter : ${esc(d.libelle)}</h2>${closeBtn()}</div><p><strong>${esc(d.description)}</strong></p><p>Motif du demandeur : ${esc(d.motif || '')}</p>
      <div class="notice">L’élément sera annulé : il cessera de compter (caisse, statistiques, comptabilité, paie) et restera dans l’historique avec cette décision.</div>
      ${champ('Commentaire (facultatif)', '<textarea id="sup-reponse" rows="2" maxlength="300"></textarea>')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Retour</button><button class="btn btn-danger" data-action="supDecider" data-id="${d.id}" data-accepte="1">Accepter et supprimer</button></div>`);
  },
  supRefuser: el => {
    const d = supDemande(el.dataset.id);
    if (!d) return;
    openModal(`<div class="modal-head"><h2>Refuser : ${esc(d.libelle)}</h2>${closeBtn()}</div><p><strong>${esc(d.description)}</strong></p>
      ${champ('Raison du refus (obligatoire, transmise au demandeur)', '<textarea id="sup-reponse" rows="2" maxlength="300" placeholder="Ex. ce passage a bien eu lieu : à encaisser normalement"></textarea>')}
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Retour</button><button class="btn" data-action="supDecider" data-id="${d.id}" data-accepte="0">Refuser la demande</button></div>`);
  },
  supDecider: async el => {
    const accepte = el.dataset.accepte === '1', reponse = (($('#sup-reponse') || {}).value || '').trim();
    if (!accepte && reponse.length < 5) { toast('Indiquez la raison du refus : le demandeur la recevra.', 'bad'); return; }
    const r = await agir(() => api('POST', `/api/demandes/${el.dataset.id}/decision`, { accepte, reponse }), accepte ? 'Suppression effectuée : l’élément ne compte plus.' : 'Demande refusée : le demandeur est prévenu.');
    if (r) closeModal();
  }
});
ONGLETS.push({ id: 'suppressions', libelle: 'Suppressions', icone: 'corbeille', visible: () => peut('supprimer'),
  compteur: () => (E.suppressions || []).filter(d => d.statut === 'en_attente').length, vue: vSuppressions });
