'use strict';
/* Initialise la base : npm run initialiser (production) ou npm run formation (base de formation). */
const fs = require('fs');
const { lireConfig } = require('../serveur/config');

const conf = lireConfig();
process.env.TZ = conf.fuseau || 'Africa/Abidjan';
const { ouvrir } = require('../serveur/db');
const init = require('../serveur/donnees-initiales');
const { cle } = require('../serveur/sauvegarde');

const existe = fs.existsSync(conf.fichier);
const db = ouvrir(conf.fichier);
if (existe && db.prepare('SELECT COUNT(*) n FROM utilisateurs').get().n) {
  console.log(`\nBase déjà initialisée : ${conf.fichier}\nAucune modification effectuée.\n`);
  process.exit(0);
}
init.referentiels(db, { formation: conf.formation });
const comptes = init.comptes(db, { formation: conf.formation });
if (conf.formation) init.donneesFormation(db);
cle(conf.dossier_donnees);
db.close();

console.log(`\nBase ${conf.formation ? 'de FORMATION' : 'de production'} créée : ${conf.fichier}`);
console.log('\nComptes créés (notez ces mots de passe, ils ne seront plus affichés) :');
for (const c of comptes) console.log(`  ${c.login.padEnd(12)} ${c.mdp}   ${c.roles}`);
if (!conf.formation) {
  console.log('\nÀ la première connexion, le mot de passe devra être changé.');
  console.log('Étapes suivantes : vérifier les tarifs (Paramétrage), importer le catalogue pharmacie, créer les comptes du personnel.');
  console.log(`\nIMPORTANT : copiez la clé ${conf.dossier_donnees}/cle-sauvegarde.key sur une clé USB rangée au coffre.`);
  console.log('Sans elle, les sauvegardes chiffrées sont illisibles.');
}
console.log(`\nDémarrage : ${conf.formation ? 'npm start -- --formation' : 'npm start'}\n`);
