'use strict';
/* Sauvegardes à chaud (API de sauvegarde SQLite), chiffrées AES-256-GCM, copiées vers un dossier synchronisé
   (Google Drive, OneDrive…) pour la copie hors site. Objectif : perte maximale de 15 minutes (RPO). */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pad } = require('./outils');

const ENTETE = Buffer.from('MSIBAK1');

function cle(dossierDonnees) {
  const f = path.join(dossierDonnees, 'cle-sauvegarde.key');
  if (!fs.existsSync(f)) {
    fs.mkdirSync(dossierDonnees, { recursive: true });
    fs.writeFileSync(f, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  }
  const k = Buffer.from(fs.readFileSync(f, 'utf8').trim(), 'hex');
  if (k.length !== 32) throw new Error('Clé de sauvegarde invalide : ' + f);
  return k;
}
function chiffrer(buf, k) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', k, iv);
  const data = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([ENTETE, iv, c.getAuthTag(), data]);
}
function dechiffrer(buf, k) {
  if (!buf.subarray(0, ENTETE.length).equals(ENTETE)) throw new Error('Fichier de sauvegarde MSI non reconnu.');
  const o = ENTETE.length, d = crypto.createDecipheriv('aes-256-gcm', k, buf.subarray(o, o + 12));
  d.setAuthTag(buf.subarray(o + 12, o + 28));
  return Buffer.concat([d.update(buf.subarray(o + 28)), d.final()]);
}
const horodatage = (t = new Date()) => `${t.getFullYear()}${pad(t.getMonth() + 1, 2)}${pad(t.getDate(), 2)}-${pad(t.getHours(), 2)}${pad(t.getMinutes(), 2)}${pad(t.getSeconds(), 2)}`;

/* Rétention : les 96 dernières (24 h à 15 min), puis une par jour pendant 90 jours. */
function retention(dossier) {
  const f = fs.readdirSync(dossier).filter(x => /^msi-\d{8}-\d{6}\.msibak$/.test(x)).sort().reverse();
  const jours = new Set(), limite = horodatage(new Date(Date.now() - 90 * 864e5)).slice(0, 8);
  f.forEach((nom, i) => {
    if (i < 96) return;
    const j = nom.slice(4, 12);
    if (j >= limite && !jours.has(j)) { jours.add(j); return; }
    try { fs.unlinkSync(path.join(dossier, nom)); } catch (e) { /* fichier déjà retiré */ }
  });
}

function creerSauvegardeur(db, conf) {
  const etat = { derniere: null, erreur: null, en_cours: false };
  const k = cle(conf.dossier_donnees);
  async function sauvegarder() {
    if (etat.en_cours) return etat;
    etat.en_cours = true;
    const tmp = path.join(conf.dossier, '.sauvegarde-en-cours.db');
    try {
      fs.mkdirSync(conf.dossier, { recursive: true });
      await db.backup(tmp);
      const enc = chiffrer(fs.readFileSync(tmp), k);
      const nom = `msi-${horodatage()}.msibak`;
      fs.writeFileSync(path.join(conf.dossier, nom), enc);
      retention(conf.dossier);
      let cloud = 'non configuré';
      if (conf.dossier_cloud) {
        try { fs.mkdirSync(conf.dossier_cloud, { recursive: true }); fs.writeFileSync(path.join(conf.dossier_cloud, nom), enc); retention(conf.dossier_cloud); cloud = 'copiée'; }
        catch (e) { cloud = 'échec : ' + e.message; }
      }
      etat.derniere = { le: new Date().toISOString(), fichier: nom, taille: enc.length, cloud };
      etat.erreur = cloud.startsWith('échec') ? cloud : null;
    } catch (e) {
      etat.erreur = e.message;
    } finally {
      try { fs.unlinkSync(tmp); } catch (e) { /* rien à nettoyer */ }
      etat.en_cours = false;
    }
    return etat;
  }
  let minuterie = null;
  return {
    etat, sauvegarder,
    demarrer() {
      setTimeout(sauvegarder, 60 * 1000).unref();
      minuterie = setInterval(sauvegarder, Math.max(5, conf.intervalle_min || 15) * 60 * 1000);
      minuterie.unref();
    },
    arreter() { if (minuterie) clearInterval(minuterie); }
  };
}

module.exports = { cle, chiffrer, dechiffrer, creerSauvegardeur, retention, horodatage };
