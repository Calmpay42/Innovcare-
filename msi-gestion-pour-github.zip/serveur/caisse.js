'use strict';
/* Caisse : encaissement acte par acte, reçus numérotés, avoirs, sorties et clôture par vacation. */
const crypto = require('crypto');
const { pad, maintenant, fmt, err, texte, entier, ids } = require('./outils');
const R = require('./regles');

const sessionOuverte = (db, uid) => db.prepare('SELECT * FROM caisse_sessions WHERE caissier_id = ? AND fermee_le IS NULL').get(uid) || null;

function ouvrirCaisse(db, u, d) {
  if (sessionOuverte(db, u.id)) throw err(409, 'Votre caisse est déjà ouverte.');
  const fonds = entier(d.fonds, { label: 'Fonds de caisse', min: 0, max: 50000000 });
  const vac = R.vacation(R.params(db));
  const id = db.prepare('INSERT INTO caisse_sessions(caissier_id, vacation, ouverte_le, fonds) VALUES (?,?,?,?)').run(u.id, vac, maintenant(), fonds).lastInsertRowid;
  R.journal(db, u, 'Caisse', 'Ouverture de caisse', `${vac}, fonds ${fmt(fonds)}`);
  return id;
}

/* Espèces attendues = fonds + espèces encaissées − remboursements en espèces − sorties. */
function especes(db, s) {
  const q = sql => db.prepare(sql).get(s.id).m;
  const encaisse = q("SELECT COALESCE(SUM(p.montant),0) m FROM paiements p JOIN recus r ON r.id = p.recu_id WHERE r.session_id = ? AND p.mode = 'Espèces'");
  const rembourse = q("SELECT COALESCE(SUM(p.montant),0) m FROM paiements p JOIN recus r ON r.id = p.recu_id WHERE r.rembourse_session_id = ? AND p.mode = 'Espèces'");
  const depenses = q('SELECT COALESCE(SUM(montant),0) m FROM depenses WHERE session_id = ?');
  const avances_recues = q("SELECT COALESCE(SUM(montant),0) m FROM avances WHERE session_id = ? AND type = 'depot' AND mode = 'Espèces'");
  const avances_rendues = q("SELECT COALESCE(SUM(montant),0) m FROM avances WHERE session_id = ? AND type = 'remboursement' AND mode = 'Espèces'");
  return { encaisse, rembourse, depenses, avances_recues, avances_rendues, theorique: s.fonds + encaisse + avances_recues - rembourse - avances_rendues - depenses };
}

const codeControle = (db, numero, net, t) => crypto.createHmac('sha256', R.params(db).secret_recus || 'msi')
  .update(`${numero}|${net}|${t}`).digest('hex').slice(0, 8).toUpperCase();

/* CAI-03, CAI-04 : paiement total, partiel par mode ou mixte ; référence obligatoire hors espèces, jamais réutilisée. */
function lirePaiements(db, liste, net) {
  const l = Array.isArray(liste) ? liste : [];
  if (net === 0) { if (l.length) throw err(400, 'Rien à payer : aucun paiement attendu.'); return []; }
  if (!l.length || l.length > 5) throw err(400, 'Indiquez le ou les modes de paiement.');
  const out = l.map(x => {
    const mode = String(x.mode || '');
    if (!R.MODES.includes(mode)) throw err(400, 'Mode de paiement inconnu.');
    const montant = entier(x.montant, { label: 'Montant ' + mode, min: 1, max: 100000000 });
    const reference = mode === 'Espèces' || mode === R.AVANCE ? null : texte(x.reference, { label: 'Référence ' + mode, max: 60, requis: true });
    const remis = mode !== 'Espèces' ? null : (x.remis === '' || x.remis == null ? montant : entier(x.remis, { label: 'Montant remis', min: 0, max: 100000000 }));
    if (remis !== null && remis < montant) throw err(400, 'Le montant remis en espèces est inférieur au montant dû.');
    if (reference) {
      const deja = db.prepare('SELECT r.numero FROM paiements p JOIN recus r ON r.id = p.recu_id WHERE p.mode = ? AND p.reference = ? COLLATE NOCASE').get(mode, reference);
      if (deja) throw err(409, `Référence ${reference} déjà utilisée sur le reçu ${deja.numero}.`);
    }
    return { mode, montant, reference, remis };
  });
  if (out.filter(x => x.mode === 'Espèces').length > 1) throw err(400, 'Regroupez les espèces sur une seule ligne.');
  if (out.filter(x => x.mode === R.AVANCE).length > 1) throw err(400, 'Une seule ligne d’avance par reçu.');
  const somme = out.reduce((s, x) => s + x.montant, 0);
  if (somme !== net) throw err(400, `La somme des paiements (${fmt(somme)}) doit être égale au net à payer (${fmt(net)}).`);
  return out;
}
function lireBonsPayables(db, bonIds) {
  const bons = bonIds.map(id => db.prepare('SELECT * FROM bons WHERE id = ?').get(id));
  if (bons.some(b => !b)) throw err(404, 'Bon introuvable.');
  if (bons.some(b => b.paye || b.annule)) throw err(409, 'Un bon a déjà été réglé ou annulé : actualisez l’écran.');
  if (bons.some(b => b.demande_id)) throw err(409, 'Un bon attend une décision de la direction.');
  if (new Set(bons.map(b => b.patient_id || 'v' + b.passage_id)).size > 1) throw err(400, 'Un reçu ne concerne qu’un seul patient.');
  return bons;
}

function encaisser(db, u, d) {
  const s = sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Ouvrez votre caisse avant d’encaisser.');
  const bonIds = ids(d.bon_ids, 'Bons à encaisser');
  /* v2.2 : un passage dont l'annulation est demandée à l'administrateur ne s'encaisse pas avant sa décision. */
  const supEnAttente = new Set(db.prepare("SELECT donnees FROM demandes WHERE type = 'suppression' AND statut = 'en_attente'").all().map(r => JSON.parse(r.donnees)).filter(x => x.objet === 'passage').map(x => x.id));
  if (supEnAttente.size) for (const bid of bonIds) {
    const b = db.prepare('SELECT passage_id FROM bons WHERE id = ?').get(bid);
    if (b && supEnAttente.has(b.passage_id)) throw err(409, 'Annulation de ce passage demandée à l’administrateur : encaissement suspendu jusqu’à sa décision.');
  }
  const remise = entier(d.remise == null ? 0 : d.remise, { label: 'Remise', min: 0, max: 100 });
  const pm = R.params(db);
  if (remise > pm.plafond_remise) throw err(403, `Remise de ${remise} % au-delà du plafond de ${pm.plafond_remise} % : demandez la validation de la direction.`);
  return db.transaction(() => {
    const bons = lireBonsPayables(db, bonIds);
    let total = 0, pa = 0, rem = 0, net = 0;
    for (const b of bons) {
      const a = R.montants(b), rr = b.remise_pct ? a.remise : Math.round(a.pp * remise / 100);
      total += a.total; pa += a.pa; rem += rr; net += a.pp - rr;
    }
    const paiements = lirePaiements(db, d.paiements, net);
    const av = paiements.find(p => p.mode === R.AVANCE);
    if (av) {
      if (!bons[0].patient_id) throw err(400, 'Avance impossible pour une vente au comptoir.');
      const solde = R.soldeAvance(db, bons[0].patient_id);
      if (av.montant > solde) throw err(409, `Avance insuffisante : solde disponible ${fmt(solde)}.`);
    }
    const t = maintenant(), annee = new Date().getFullYear();
    const numero = `R-${annee}-${pad(R.suivant(db, 'recu:' + annee), 6)}`;
    const recuId = db.prepare(`INSERT INTO recus (numero, patient_id, session_id, caissier_id, total, part_assureur, remise, net, code_controle, cree_le)
      VALUES (?,?,?,?,?,?,?,?,?,?)`).run(numero, bons[0].patient_id, s.id, u.id, total, pa, rem, net, codeControle(db, numero, net, t), t).lastInsertRowid;
    const insP = db.prepare('INSERT INTO paiements(recu_id, mode, montant, reference, remis) VALUES (?,?,?,?,?)');
    for (const p of paiements) insP.run(recuId, p.mode, p.montant, p.reference, p.remis);
    if (av) db.prepare("INSERT INTO avances(numero, patient_id, type, montant, mode, session_id, recu_id, motif, cree_le, cree_par) VALUES (?,?,'utilisation',?,?,?,?,?,?,?)")
      .run(`UTI-${annee}-${pad(R.suivant(db, 'avance:UTI:' + annee), 5)}`, bons[0].patient_id, av.montant, R.AVANCE, s.id, recuId, numero, t, u.id);
    for (const b of bons) {
      if (remise && !b.remise_pct) db.prepare('UPDATE bons SET remise_pct = ? WHERE id = ? AND paye = 0').run(remise, b.id);
      if (db.prepare('UPDATE bons SET paye = 1, recu_id = ? WHERE id = ? AND paye = 0 AND annule = 0').run(recuId, b.id).changes !== 1) throw err(409, 'Bon modifié entre-temps : actualisez l’écran.');
    }
    const regul = bons.filter(b => b.urgent).length;
    R.journal(db, u, 'Caisse', 'Encaissement', `${numero} : ${fmt(net)} pour ${R.nomPatient(R.patient(db, bons[0].patient_id))}${paiements.length ? ' (' + paiements.map(p => p.mode).join(', ') + ')' : ', sans paiement du patient'}${rem ? ', remise ' + fmt(rem) : ''}${regul ? `, ${regul} bon(s) d’urgence régularisé(s)` : ''}`);
    return { id: recuId, numero };
  })();
}

/* CAI-08 : au-delà du plafond, la remise part en validation à la direction. */
function demanderRemise(db, u, d) {
  const bonIds = ids(d.bon_ids, 'Bons');
  const pct = entier(d.pct, { label: 'Remise', min: 1, max: 100 });
  const motif = texte(d.motif, { label: 'Motif de la remise', max: 300, requis: true });
  const pm = R.params(db);
  if (pct <= pm.plafond_remise) throw err(400, 'Remise dans le plafond : appliquez-la directement à l’encaissement.');
  return db.transaction(() => {
    const bons = lireBonsPayables(db, bonIds);
    if (bons.some(b => b.remise_pct)) throw err(409, 'Un bon porte déjà une remise.');
    const montant = bons.reduce((s, b) => s + Math.round(R.montants(b).pp * pct / 100), 0);
    const patient = R.nomPatient(R.patient(db, bons[0].patient_id));
    const id = db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)')
      .run('remise', JSON.stringify({ bon_ids: bonIds, pct, montant, patient }), motif, u.id, maintenant()).lastInsertRowid;
    for (const b of bons) db.prepare('UPDATE bons SET demande_id = ? WHERE id = ?').run(id, b.id);
    R.journal(db, u, 'Caisse', 'Demande de remise', `${pct} % (${fmt(montant)}) pour ${patient}, motif : ${motif}`, { niveau: 'alerte' });
    return id;
  })();
}

/* CAI-09 : annulation par avoir motivé et validé, jamais par suppression. */
function demanderAnnulation(db, u, recuId, motifSaisi) {
  const motif = texte(motifSaisi, { label: 'Motif de l’annulation', max: 300, requis: true });
  const r = db.prepare('SELECT * FROM recus WHERE id = ?').get(recuId);
  if (!r) throw err(404, 'Reçu introuvable.');
  if (r.annule) throw err(409, 'Reçu déjà annulé.');
  if (db.prepare('SELECT 1 FROM bons WHERE recu_id = ? AND delivre = 1').get(r.id)) throw err(409, 'Produits déjà délivrés : un retour en pharmacie est nécessaire avant toute annulation.');
  const deja = db.prepare("SELECT donnees FROM demandes WHERE type = 'annulation' AND statut = 'en_attente'").all().some(x => JSON.parse(x.donnees).recu_id === r.id);
  if (deja) throw err(409, 'Une demande d’annulation est déjà en attente pour ce reçu.');
  const patient = R.nomPatient(R.patient(db, r.patient_id));
  db.transaction(() => {
    db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)')
      .run('annulation', JSON.stringify({ recu_id: r.id, numero: r.numero, net: r.net, patient }), motif, u.id, maintenant());
    R.journal(db, u, 'Caisse', 'Demande d’annulation', `${r.numero} (${fmt(r.net)}), motif : ${motif}`, { niveau: 'alerte' });
  })();
}
/* Avoir validé sur une caisse déjà clôturée : le remboursement sort de la caisse ouverte de l'agent. */
function rembourser(db, u, recuId) {
  const s = sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Ouvrez votre caisse pour rembourser.');
  const r = db.prepare('SELECT * FROM recus WHERE id = ?').get(recuId);
  if (!r || !r.annule || r.rembourse_session_id) throw err(409, 'Aucun remboursement en attente pour ce reçu.');
  db.transaction(() => {
    db.prepare('UPDATE recus SET rembourse_session_id = ?, rembourse_le = ? WHERE id = ?').run(s.id, maintenant(), r.id);
    R.journal(db, u, 'Caisse', 'Remboursement d’avoir', `${r.avoir} (reçu ${r.numero}) : ${fmt(r.net)} remboursés`);
  })();
}

/* CAI-11 : sorties classées SYSCOHADA, justificatif obligatoire. */
function ajouterDepense(db, u, d) {
  const s = sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Ouvrez votre caisse avant une sortie.');
  const categorie = String(d.categorie || '');
  if (!R.CATEGORIES_DEPENSES.some(c => c.code === categorie)) throw err(400, 'Catégorie SYSCOHADA inconnue.');
  const libelle = texte(d.libelle, { label: 'Libellé', max: 160, requis: true });
  const montant = entier(d.montant, { label: 'Montant', min: 1, max: 50000000 });
  const justificatif = texte(d.justificatif, { label: 'N° du justificatif', max: 60, requis: true });
  const dispo = especes(db, s).theorique;
  if (montant > dispo) throw err(409, `Montant supérieur aux espèces disponibles (${fmt(dispo)}).`);
  db.transaction(() => {
    db.prepare('INSERT INTO depenses(session_id, categorie, libelle, montant, justificatif, cree_le, utilisateur_id) VALUES (?,?,?,?,?,?,?)')
      .run(s.id, categorie, libelle, montant, justificatif, maintenant(), u.id);
    R.journal(db, u, 'Caisse', 'Sortie de caisse', `${libelle} (compte ${categorie}), ${fmt(montant)}, justificatif ${justificatif}`);
  })();
}

/* CAI-06, RG-CAI-3 : clôture avec billetage ; écart justifié par l'agent, validé par la direction. */
function cloturer(db, u, d) {
  const s = sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Aucune caisse ouverte.');
  const bill = {};
  let compte = 0;
  for (const c of R.COUPURES) {
    const n = entier((d.billetage || {})[c.k] || 0, { label: c.l, min: 0, max: 1000000 });
    bill[c.k] = n; compte += n * c.v;
  }
  const theorique = especes(db, s).theorique, ecart = compte - theorique;
  const justification = texte(d.justification, { label: 'Justification de l’écart', max: 500 });
  if (ecart !== 0 && !justification) throw err(400, `Écart de ${fmt(ecart)} : justifiez-le avant de clôturer.`, { ecart });
  db.transaction(() => {
    db.prepare('UPDATE caisse_sessions SET fermee_le = ?, theorique = ?, compte = ?, ecart = ?, justification = ?, billetage = ? WHERE id = ?')
      .run(maintenant(), theorique, compte, ecart, justification || null, JSON.stringify(bill), s.id);
    if (ecart !== 0) {
      db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)')
        .run('ecart', JSON.stringify({ session_id: s.id, ecart, theorique, compte, caissier: u.nom, vacation: s.vacation }), justification, u.id, maintenant());
    }
    R.journal(db, u, 'Caisse', 'Clôture de caisse', `Attendu ${fmt(theorique)}, compté ${fmt(compte)}, écart ${fmt(ecart)}${justification ? ', justification : ' + justification : ''}`, { niveau: ecart ? 'alerte' : null });
  })();
  return { theorique, compte, ecart };
}

function detailRecu(db, id) {
  const r = db.prepare('SELECT * FROM recus WHERE id = ?').get(id);
  if (!r) throw err(404, 'Reçu introuvable.');
  const bons = db.prepare('SELECT * FROM bons WHERE recu_id = ? ORDER BY id').all(r.id).map(b => ({ ...b, ...R.montants(b) }));
  const passages = [...new Set(bons.map(b => b.passage_id))].map(pid => R.passage(db, pid)).filter(Boolean);
  const assureurs = [...new Set(bons.filter(b => b.assureur_id).map(b => {
    const a = db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(b.assureur_id);
    return `${a ? a.nom : '?'} ${b.taux} %`;
  }))];
  const p = R.params(db);
  return {
    ...r, bons, paiements: db.prepare('SELECT * FROM paiements WHERE recu_id = ? ORDER BY id').all(r.id),
    patient: R.patient(db, r.patient_id), passages: passages.map(v => v.numero), accords: passages.filter(v => v.accord).map(v => v.accord), couverture: assureurs,
    caissier: (db.prepare('SELECT nom FROM utilisateurs WHERE id = ?').get(r.caissier_id) || {}).nom,
    vacation: (db.prepare('SELECT vacation FROM caisse_sessions WHERE id = ?').get(r.session_id) || {}).vacation,
    etablissement: { raison: p.raison, forme: p.forme, adresse: p.adresse, rccm: p.rccm, ncc: p.ncc, telephone: p.telephone, slogan: p.slogan },
    formation: !!p.formation, qr: `MSI|${r.numero}|${r.net}|${r.cree_le}|${r.code_controle}`
  };
}

module.exports = { sessionOuverte, ouvrirCaisse, especes, encaisser, demanderRemise, demanderAnnulation, rembourser, ajouterDepense, cloturer, detailRecu, codeControle };
