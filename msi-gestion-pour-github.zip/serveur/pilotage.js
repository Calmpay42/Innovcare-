'use strict';
/* Pilotage de la clinique (direction, RAF), en lecture seule.
   Activité, recettes, services, modes de paiement, créances des assureurs, fréquentation et caisse,
   sur une période choisie et comparée à la période précédente. Les montants reprennent exactement
   les règles de la caisse (montants() de chaque bon) ; les reçus, bons et passages annulés sont exclus. */
const { montants } = require('./regles');
const TP = require('./tiers-payant');

const PERIODES = ['mois', '12m', 'annee', 'anneePrec', 'tout'];
const jour = () => new Date().toISOString().slice(0, 10);
const decale = (m, n) => { const [a, mm] = m.split('-').map(Number); return new Date(Date.UTC(a, mm - 1 + n, 1)).toISOString().slice(0, 7); };
const listeMois = (fin, n) => Array.from({ length: n }, (_, i) => decale(fin, i - n + 1));
const dernierJour = m => { const [a, mm] = m.split('-').map(Number); return new Date(Date.UTC(a, mm, 0)).toISOString().slice(0, 10); };

function periode(code, auj = jour()) {
  const mois = auj.slice(0, 7), annee = Number(auj.slice(0, 4)), j = auj.slice(8);
  if (code === 'mois') {
    const prec = decale(mois, -1), finPrec = `${prec}-${j}` > dernierJour(prec) ? dernierJour(prec) : `${prec}-${j}`;
    const jours = Array.from({ length: Number(j) }, (_, i) => `${mois}-${String(i + 1).padStart(2, '0')}`);
    return { code, du: `${mois}-01`, au: auj, lib: 'mois en cours', cases: jours, parJour: true, prec: { du: `${prec}-01`, au: finPrec, lib: 'le mois précédent à la même date' } };
  }
  if (code === 'annee') return { code, du: `${annee}-01-01`, au: auj, lib: `année ${annee}`, cases: listeMois(mois, Number(mois.slice(5))), prec: { du: `${annee - 1}-01-01`, au: `${annee - 1}-${auj.slice(5)}`, lib: `la même période de ${annee - 1}` } };
  if (code === 'anneePrec') return { code, du: `${annee - 1}-01-01`, au: `${annee - 1}-12-31`, lib: `année ${annee - 1}`, cases: listeMois(`${annee - 1}-12`, 12), prec: { du: `${annee - 2}-01-01`, au: `${annee - 2}-12-31`, lib: `l’année ${annee - 2}` } };
  if (code === 'tout') return { code, du: '0000-01-01', au: auj, lib: 'depuis le début', cases: null, prec: null };
  const debut = decale(mois, -11);
  return { code: '12m', du: `${debut}-01`, au: auj, lib: '12 derniers mois', cases: listeMois(mois, 12), prec: { du: `${decale(debut, -12)}-01`, au: `${decale(mois, -12)}-${j}`, lib: 'les 12 mois précédents' } };
}

/* Passage comptant dans l'activité : pas un solde repris, et pas annulé (tous ses bons annulés). */
const ACTIF = `p.type <> 'reprise' AND NOT (EXISTS (SELECT 1 FROM bons b WHERE b.passage_id = p.id)
  AND NOT EXISTS (SELECT 1 FROM bons b WHERE b.passage_id = p.id AND b.annule = 0))`;

function agregats(db, du, au) {
  return {
    recus: db.prepare('SELECT id, net, part_assureur, remise, total, cree_le FROM recus WHERE annule = 0 AND substr(cree_le, 1, 10) BETWEEN ? AND ?').all(du, au),
    passages: db.prepare(`SELECT p.id, p.type, p.cree_le FROM passages p WHERE substr(p.cree_le, 1, 10) BETWEEN ? AND ? AND ${ACTIF}`).all(du, au),
    nouveaux: db.prepare('SELECT cree_le FROM patients WHERE substr(cree_le, 1, 10) BETWEEN ? AND ?').all(du, au)
  };
}
const somme = (liste, f) => liste.reduce((s, x) => s + f(x), 0);

function tableau(db, code) {
  const P = periode(PERIODES.includes(code) ? code : '12m');
  const auj = jour();
  if (P.code === 'tout') {
    const premier = db.prepare("SELECT MIN(d) AS d FROM (SELECT MIN(cree_le) AS d FROM recus UNION ALL SELECT MIN(cree_le) FROM passages WHERE type <> 'reprise')").get().d;
    const m0 = (premier || auj).slice(0, 7), mois = auj.slice(0, 7);
    let n = 1;
    while (decale(m0, n - 1) < mois && n < 120) n++;
    P.cases = listeMois(mois, n);
  }
  const A = agregats(db, P.du, P.au), B = P.prec ? agregats(db, P.prec.du, P.prec.au) : null;
  const cle = d => (P.parJour ? d.slice(0, 10) : d.slice(0, 7));
  const serie = (liste, val, champ = 'cree_le') => {
    const m = new Map(P.cases.map(c => [c, 0]));
    for (const x of liste) { const k = cle(x[champ] || ''); if (m.has(k)) m.set(k, m.get(k) + val(x)); }
    return [...m.values()];
  };

  /* Bons payés sur la période (reçus non annulés) : services, actes et produits, au même montant que la caisse. */
  const bons = db.prepare(`SELECT b.*, a.famille AS famille_acte FROM bons b JOIN recus r ON r.id = b.recu_id
    LEFT JOIN actes a ON a.id = b.acte_id OR (b.acte_id IS NULL AND b.nature = 'acte' AND a.code = b.code)
    WHERE r.annule = 0 AND b.annule = 0 AND substr(r.cree_le, 1, 10) BETWEEN ? AND ?`).all(P.du, P.au);
  const services = new Map(), actes = new Map(), produits = new Map(), assureurs = new Map(), passagesFactures = new Set();
  for (const b of bons) {
    const m = montants(b), ca = m.total - m.remise;
    passagesFactures.add(b.passage_id);
    const service = b.nature === 'produit' ? 'Pharmacie' : b.nature === 'reprise' ? 'Soldes repris' : (b.famille_acte || 'Autres actes');
    services.set(service, (services.get(service) || 0) + ca);
    const t = b.nature === 'produit' ? produits : b.nature === 'acte' ? actes : null;
    if (t) { const x = t.get(b.libelle) || { libelle: b.libelle, quantite: 0, montant: 0 }; x.quantite += b.quantite; x.montant += ca; t.set(b.libelle, x); }
    if (b.assureur_id && m.pa) assureurs.set(b.assureur_id, (assureurs.get(b.assureur_id) || 0) + m.pa);
  }
  const nomAssureur = id => (db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(id) || { nom: 'Assureur supprimé' }).nom;
  const regles = db.prepare(`SELECT a.nom AS assureur, SUM(g.montant) AS montant FROM reglements_assureurs g JOIN bordereaux b ON b.id = g.bordereau_id
    JOIN assureurs a ON a.id = b.assureur_id WHERE substr(g.date, 1, 10) BETWEEN ? AND ? GROUP BY a.nom ORDER BY montant DESC`).all(P.du, P.au);
  const modes = db.prepare(`SELECT p.mode, SUM(p.montant) AS montant, COUNT(*) AS nombre FROM paiements p JOIN recus r ON r.id = p.recu_id
    WHERE r.annule = 0 AND substr(r.cree_le, 1, 10) BETWEEN ? AND ? GROUP BY p.mode ORDER BY montant DESC`).all(P.du, P.au);
  const specialites = db.prepare('SELECT specialite, COUNT(*) AS nombre FROM consultations WHERE substr(cree_le, 1, 10) BETWEEN ? AND ? GROUP BY specialite ORDER BY nombre DESC').all(P.du, P.au);
  const sessions = db.prepare('SELECT fermee_le, ecart FROM caisse_sessions WHERE fermee_le IS NOT NULL AND substr(fermee_le, 1, 10) BETWEEN ? AND ?').all(P.du, P.au);
  const types = {}, jours = [0, 0, 0, 0, 0, 0, 0], heures = Array(24).fill(0);
  for (const p of A.passages) {
    types[p.type] = (types[p.type] || 0) + 1;
    const d = new Date(p.cree_le);
    jours[(d.getUTCDay() + 6) % 7]++;
    heures[d.getUTCHours()]++;
  }
  const debut30 = new Date(Date.parse(auj) - 29 * 864e5).toISOString().slice(0, 10);
  const r30 = new Map(Array.from({ length: 30 }, (_, i) => [new Date(Date.parse(debut30) + i * 864e5).toISOString().slice(0, 10), 0]));
  for (const r of db.prepare('SELECT net, cree_le FROM recus WHERE annule = 0 AND substr(cree_le, 1, 10) >= ?').all(debut30)) {
    const k = r.cree_le.slice(0, 10); if (r30.has(k)) r30.set(k, r30.get(k) + r.net);
  }
  const recettes = somme(A.recus, r => r.net), partAssureurs = somme(A.recus, r => r.part_assureur);
  const tri = (m, f) => [...m.values()].sort((a, b) => b[f] - a[f]).slice(0, 10);
  return {
    periode: { code: P.code, du: P.du, au: P.au, lib: P.lib, prec: P.prec ? P.prec.lib : null, cases: P.cases, par_jour: !!P.parJour },
    totaux: {
      recettes, part_assureurs: partAssureurs, ca: recettes + partAssureurs, remises: somme(A.recus, r => r.remise), recus: A.recus.length,
      passages: A.passages.length, nouveaux: A.nouveaux.length, passages_factures: passagesFactures.size,
      panier: passagesFactures.size ? Math.round((recettes + partAssureurs) / passagesFactures.size) : 0,
      valeur_stock: db.prepare('SELECT COALESCE(SUM(quantite * COALESCE(prix_achat, 0)), 0) AS v FROM lots WHERE quantite > 0 AND peremption >= ?').get(auj).v
    },
    precedent: B ? { recettes: somme(B.recus, r => r.net), ca: somme(B.recus, r => r.net + r.part_assureur), passages: B.passages.length, nouveaux: B.nouveaux.length } : null,
    series: {
      recettes: serie(A.recus, r => r.net), part_assureurs: serie(A.recus, r => r.part_assureur), passages: serie(A.passages, () => 1),
      nouveaux: serie(A.nouveaux, () => 1), ecarts: serie(sessions, s => s.ecart || 0, 'fermee_le')
    },
    services: [...services].map(([libelle, montant]) => ({ libelle, montant })).sort((a, b) => b.montant - a.montant),
    modes, specialites, types: Object.entries(types).map(([type, nombre]) => ({ type, nombre })).sort((a, b) => b.nombre - a.nombre),
    actes: tri(actes, 'montant'), produits: tri(produits, 'quantite'),
    assureurs: {
      facture: [...assureurs].map(([id, montant]) => ({ assureur: nomAssureur(id), montant })).sort((a, b) => b.montant - a.montant),
      regle: regles, creances: TP.balanceAgee(db)
    },
    frequentation: { jours, heures },
    caisse: { sessions: sessions.length, avec_ecart: sessions.filter(s => s.ecart).length, total_ecart: somme(sessions, s => s.ecart || 0) },
    jour: { date: auj, recettes: r30.get(auj) || 0, passages: db.prepare(`SELECT COUNT(*) AS n FROM passages p WHERE substr(p.cree_le, 1, 10) = ? AND ${ACTIF}`).get(auj).n },
    recettes_30j: [...r30.values()]
  };
}

module.exports = { tableau, periode, PERIODES };
