'use strict';
/* Utilitaires partagés du serveur MSI. */

const pad = (n, w) => String(n).padStart(w, '0');
const jourLocal = (d = new Date()) => d.getFullYear() + '-' + pad(d.getMonth() + 1, 2) + '-' + pad(d.getDate(), 2);
const maintenant = () => new Date().toISOString();
const jourDe = iso => jourLocal(new Date(iso));
function bornesJour(jour) {
  const [y, m, d] = jour.split('-').map(Number);
  return [new Date(y, m - 1, d).toISOString(), new Date(y, m - 1, d + 1).toISOString()];
}
function bornesPeriode(du, au) { return [bornesJour(du)[0], bornesJour(au)[1]]; }
const utc = j => { const [y, m, d] = j.split('-').map(Number); return Date.UTC(y, m - 1, d); };
const joursEntre = (a, b) => Math.round((utc(b) - utc(a)) / 864e5);
const ajouterJours = (jour, n) => { const [y, m, d] = jour.split('-').map(Number); return jourLocal(new Date(y, m - 1, d + n)); };
const aammjj = (d = new Date()) => String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1, 2) + pad(d.getDate(), 2);
const fmt = n => Math.round(Number(n) || 0).toLocaleString('fr-FR') + ' FCFA';
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[’`]/g, "'").replace(/\s+/g, ' ').trim();
const chiffres = s => String(s || '').replace(/\D/g, '');

class ErreurMetier extends Error {
  constructor(status, message, extra) { super(message); this.status = status; this.extra = extra || null; }
}
const err = (status, message, extra) => new ErreurMetier(status, message, extra);

/* Validation des entrées */
function texte(v, { label, max = 200, requis = false } = {}) {
  const s = v == null ? '' : String(v).trim();
  if (requis && !s) throw err(400, `${label} : champ obligatoire.`);
  if (s.length > max) throw err(400, `${label} : ${max} caractères au maximum.`);
  return s;
}
function entier(v, { label, min = -Infinity, max = Infinity, requis = true } = {}) {
  if ((v === '' || v == null) && !requis) return null;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw err(400, `${label} : nombre entier attendu${min > -Infinity ? ' entre ' + min + ' et ' + max : ''}.`);
  return n;
}
function date(v, { label, requis = true } = {}) {
  const s = v == null ? '' : String(v).trim();
  if (!s && !requis) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || isNaN(Date.parse(s))) throw err(400, `${label} : date invalide (AAAA-MM-JJ).`);
  return s;
}
function ids(v, label = 'Sélection') {
  if (!Array.isArray(v) || !v.length || v.length > 200) throw err(400, `${label} : liste vide ou invalide.`);
  const out = [...new Set(v.map(x => Number(x)))];
  if (out.some(x => !Number.isInteger(x) || x <= 0)) throw err(400, `${label} : identifiant invalide.`);
  return out;
}

/* CSV compatible Excel français : séparateur « ; », BOM UTF-8, fins de ligne CRLF */
function versCsv(colonnes, lignes) {
  const cel = v => {
    if (v == null) return '';
    const s = String(v);
    return /[;"\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return '\ufeff' + [colonnes.map(c => cel(c.titre)).join(';'), ...lignes.map(l => colonnes.map(c => cel(typeof c.v === 'function' ? c.v(l) : l[c.v])).join(';'))].join('\r\n') + '\r\n';
}
function lireCsv(texteCsv) {
  const t = String(texteCsv || '').replace(/^\ufeff/, '');
  const premiere = t.split(/\r?\n/)[0] || '';
  const sep = [';', '\t', ','].map(s => [s, premiere.split(s).length]).sort((a, b) => b[1] - a[1])[0][0];
  const lignes = [];
  let ligne = [], cel = '', guillemets = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (guillemets) {
      if (c === '"' && t[i + 1] === '"') { cel += '"'; i++; } else if (c === '"') guillemets = false; else cel += c;
    } else if (c === '"') guillemets = true;
    else if (c === sep) { ligne.push(cel); cel = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && t[i + 1] === '\n') i++;
      ligne.push(cel); cel = '';
      if (ligne.some(x => x.trim() !== '')) lignes.push(ligne);
      ligne = [];
    } else cel += c;
  }
  ligne.push(cel);
  if (ligne.some(x => x.trim() !== '')) lignes.push(ligne);
  if (!lignes.length) return [];
  const entetes = lignes[0].map(h => norm(h).replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, ''));
  return lignes.slice(1).map((l, i) => { const o = { _ligne: i + 2 }; entetes.forEach((h, j) => { o[h] = (l[j] || '').trim(); }); return o; });
}

module.exports = {
  pad, jourLocal, maintenant, jourDe, bornesJour, bornesPeriode, joursEntre, ajouterJours, aammjj, fmt, norm, chiffres,
  ErreurMetier, err, texte, entier, date, ids, versCsv, lireCsv
};
