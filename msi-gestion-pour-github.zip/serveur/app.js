'use strict';
/* Application web : API JSON protégée par profil, fichiers de l'interface servis en local (fonctionne sans internet). */
const path = require('path');
const express = require('express');
const QRCode = require('qrcode');
const A = require('./auth');
const R = require('./regles');
const C = require('./caisse');
const P = require('./pharmacie');
const D = require('./direction');
const ADM = require('./admin');
const CL = require('./clinique');
const REP = require('./reprise-ophtasuite');
const F = require('./facturation');
const LAB = require('./laboratoire');
const TP = require('./tiers-payant');
const PIL = require('./pilotage');
const N = require('./notifications');
const ACT = require('./activite');
const CPT = require('./compta');
const SUP = require('./suppressions');
const RH = require('./rh');
const H = require('./hospitalisation');
const { maintenant, jourLocal, joursEntre, ErreurMetier, err, date } = require('./outils');

function creerApp(db, opts = {}) {
  const app = express();
  let version = 1;
  app.disable('x-powered-by');
  /* v2.0, mode en ligne : le serveur est derrière un relais HTTPS (Caddy). Il le reconnaît (adresse réelle du visiteur,
     cookie « Secure »), impose HTTPS au navigateur et refuse toute requête qui ne lui parvient pas chiffrée. */
  const enLigne = !!opts.enLigne;
  if (enLigne) app.set('trust proxy', 1);
  app.get('/api/sante', (req, res) => {
    let base = 'ok';
    try { db.prepare('SELECT 1').get(); } catch (e) { base = 'erreur'; }
    res.setHeader('Cache-Control', 'no-store');
    res.status(base === 'ok' ? 200 : 503).json({ ok: base === 'ok', logiciel: require('../package.json').version, base });
  });
  if (enLigne) app.use((req, res, next) => {
    if (!req.secure) return res.status(403).type('text/plain; charset=utf-8').send('Connexion non chiffrée refusée : utilisez l’adresse https:// de la clinique.');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });
  /* Limitation des tentatives de connexion par adresse Internet (en plus du blocage par compte).
     Seuil large : sur Internet, tout le personnel de la clinique partage la même adresse. */
  const echecs = new Map(), FENETRE = 15 * 60 * 1000, SEUIL = 30;
  app.use('/api/connexion', (req, res, next) => {
    if (req.method !== 'POST') return next();
    const ip = req.ip || 'inconnue', t = Date.now(), liste = (echecs.get(ip) || []).filter(x => t - x < FENETRE);
    if (liste.length >= SEUIL) {
      const attente = Math.ceil((FENETRE - (t - liste[0])) / 60000);
      return res.status(429).json({ erreur: `Trop de tentatives de connexion depuis cette adresse. Réessayez dans ${attente} minute${attente > 1 ? 's' : ''}.` });
    }
    res.on('finish', () => {
      if (res.statusCode === 200) echecs.delete(ip);
      else if (res.statusCode === 401 || res.statusCode === 423) { liste.push(Date.now()); echecs.set(ip, liste); }
    });
    next();
  });
  app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'DENY');
    next();
  });
  app.use('/polices', express.static(path.join(path.dirname(require.resolve('@fontsource/poppins/package.json')), 'files'), { maxAge: '30d' }));
  app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', maxAge: 0 }));
  /* Tailles dédiées : une sauvegarde OphtaSuite avec photos, une photo ou un PDF du dossier. */
  app.use('/api/reprise', express.json({ limit: '80mb' }));
  app.use('/api/pieces', express.json({ limit: '6mb' }));
  app.use('/api', express.json({ limit: '3mb' }));
  app.use('/api', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'GET' && req.get('X-MSI') !== '1') return res.status(403).json({ erreur: 'Requête refusée.' });
    if (req.method !== 'GET') res.on('finish', () => { if (res.statusCode < 400) version++; });
    next();
  });
  app.use(A.authentifier(db, () => R.params(db).inactivite_min));

  const envoyerErreur = (res, e) => {
    if (e instanceof ErreurMetier) return res.status(e.status).json({ erreur: e.message, ...(e.extra || {}) });
    if (e && String(e.code || '').startsWith('SQLITE_CONSTRAINT')) return res.status(409).json({ erreur: e.message.replace(/^.*?: /, '') });
    console.error(new Date().toISOString(), e);
    return res.status(500).json({ erreur: 'Erreur interne du serveur. L’incident est consigné.' });
  };
  const h = fn => async (req, res) => {
    try {
      const out = await fn(req, res);
      if (!res.headersSent) res.json(out === undefined ? { ok: true } : out);
    } catch (e) { envoyerErreur(res, e); }
  };
  const get = (url, droit, fn) => app.get(url, A.exiger(droit), h(fn));
  const post = (url, droit, fn) => app.post(url, A.exiger(droit), h(fn));
  const put = (url, droit, fn) => app.put(url, A.exiger(droit), h(fn));
  const id = req => { const n = Number(req.params.id); if (!Number.isInteger(n) || n <= 0) throw err(400, 'Identifiant invalide.'); return n; };
  const poste = u => (u.roles.includes('caisse') ? 'Caisse' : u.roles.includes('direction') ? 'Direction' : 'Accueil');

  /* Connexion : 5 échecs bloquent le compte 15 minutes. */
  app.post('/api/connexion', h((req, res) => {
    const login = String((req.body || {}).login || '').trim().toLowerCase(), mdp = String((req.body || {}).mdp || '');
    const u = db.prepare('SELECT * FROM utilisateurs WHERE login = ?').get(login);
    if (u && u.bloque_jusqua && u.bloque_jusqua > maintenant()) {
      throw err(429, `Compte bloqué après plusieurs échecs. Réessayez après ${new Date(u.bloque_jusqua).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}.`);
    }
    const ok = u ? A.verifierMdp(mdp, u.hash) : (A.verifierMdp(mdp, A.hacher('leurre')), false);
    if (!ok || !u.actif) {
      if (u) {
        const echecs = u.echecs + 1;
        db.prepare('UPDATE utilisateurs SET echecs = ?, bloque_jusqua = ? WHERE id = ?').run(echecs >= 5 ? 0 : echecs, echecs >= 5 ? new Date(Date.now() + 15 * 60000).toISOString() : null, u.id);
        R.journal(db, null, 'Sécurité', 'Connexion refusée', `${login}${echecs >= 5 ? ', compte bloqué 15 minutes' : ''}`, { niveau: 'alerte' });
      }
      throw err(401, 'Identifiant ou mot de passe incorrect.');
    }
    db.prepare('UPDATE utilisateurs SET echecs = 0, bloque_jusqua = NULL, derniere_connexion = ? WHERE id = ?').run(maintenant(), u.id);
    A.ouvrirSession(db, u, req, res);
    R.journal(db, u, 'Sécurité', 'Connexion', `${u.login} depuis ${req.ip}`);
    return { ok: true };
  }));
  app.post('/api/deconnexion', h((req, res) => {
    if (req.user) R.journal(db, req.user, 'Sécurité', 'Déconnexion', req.user.login);
    A.fermerSession(db, req, res);
  }));
  app.get('/api/moi', h(req => {
    if (!req.user) throw err(401, 'Non connecté.');
    const pm = R.params(db);
    return {
      utilisateur: { id: req.user.id, login: req.user.login, nom: req.user.nom, roles: req.user.roles, specialites: CL.specialitesDe(req.user), ordre: req.user.ordre },
      droits: Object.keys(A.DROITS).filter(d => A.peut(req.user, d)), changer_mdp: req.user.changerMdp, roles_libelles: A.ROLES,
      formation: !!pm.formation, etablissement: pm.raison,
      ref: { modes: R.MODES, coupures: R.COUPURES, types_passage: R.TYPES_PASSAGE, categories_depenses: R.CATEGORIES_DEPENSES, types_ajustement: P.TYPES_AJUSTEMENT }
    };
  }));
  app.post('/api/moi/mdp', h(req => {
    if (!req.user) throw err(401, 'Non connecté.');
    const { ancien, nouveau } = req.body || {};
    const u = db.prepare('SELECT * FROM utilisateurs WHERE id = ?').get(req.user.id);
    if (!A.verifierMdp(ancien, u.hash)) throw err(400, 'Mot de passe actuel incorrect.');
    A.controlerMdp(nouveau);
    if (nouveau === ancien) throw err(400, 'Choisissez un mot de passe différent de l’actuel.');
    db.prepare('UPDATE utilisateurs SET hash = ?, changer_mdp = 0 WHERE id = ?').run(A.hacher(nouveau), u.id);
    R.journal(db, req.user, 'Sécurité', 'Changement de mot de passe', u.login);
  }));
  app.get('/api/version', A.exiger(null), (req, res) => res.json({ v: version }));
  get('/api/etat', null, req => D.etat(db, req.user));

  /* Accueil */
  get('/api/patients', 'patient_lire', req => R.rechercherPatients(db, String(req.query.q || '').slice(0, 80)));
  get('/api/patients/:id', 'patient_lire', req => R.fichePatient(db, id(req)));
  post('/api/patients', 'patient_ecrire', req => R.creerPatient(db, req.user, req.body || {}));
  put('/api/patients/:id', 'patient_ecrire', req => R.modifierPatient(db, req.user, id(req), req.body || {}));
  post('/api/patients/:id/fusion', 'patient_fusionner', req => R.fusionnerPatients(db, req.user, id(req), Number((req.body || {}).vers_id)));
  post('/api/passages', 'passage_ouvrir', req => R.ouvrirPassage(db, req.user, req.body || {}));
  post('/api/passages/:id/accord', 'accord', req => R.ajouterAccord(db, req.user, id(req), (req.body || {}).accord, poste(req.user)));
  post('/api/passages/:id/annulation', 'passage_annuler', req => R.annulerPassage(db, req.user, id(req), (req.body || {}).motif, poste(req.user), A.peut(req.user, 'valider') || A.peut(req.user, 'supprimer')));
  post('/api/passages/:id/actes', 'actes_ajouter', req => R.ajouterActes(db, req.user, id(req), (req.body || {}).actes, poste(req.user)));

  /* Caisse */
  post('/api/caisse/ouverture', 'caisse', req => C.ouvrirCaisse(db, req.user, req.body || {}));
  post('/api/caisse/encaissement', 'caisse', req => C.encaisser(db, req.user, req.body || {}));
  post('/api/caisse/remise', 'caisse', req => C.demanderRemise(db, req.user, req.body || {}));
  post('/api/caisse/sortie', 'caisse', req => C.ajouterDepense(db, req.user, req.body || {}));
  post('/api/caisse/cloture', 'caisse', req => C.cloturer(db, req.user, req.body || {}));
  post('/api/recus/:id/annulation', 'caisse', req => C.demanderAnnulation(db, req.user, id(req), (req.body || {}).motif));
  post('/api/recus/:id/remboursement', 'caisse', req => C.rembourser(db, req.user, id(req)));
  get('/api/recus/:id', null, async req => {
    if (!A.peut(req.user, 'caisse') && !A.peut(req.user, 'pilotage')) throw err(403, 'Action non autorisée pour votre profil.');
    const r = C.detailRecu(db, id(req));
    r.qr_svg = await QRCode.toString(r.qr, { type: 'svg', margin: 0, errorCorrectionLevel: 'M', color: { dark: '#0B171A', light: '#FFFDF8' } });
    return r;
  });
  get('/api/verification-recu', null, req => {
    if (!A.peut(req.user, 'caisse') && !A.peut(req.user, 'pilotage')) throw err(403, 'Action non autorisée pour votre profil.');
    return D.verifierRecu(db, req.query.numero);
  });

  /* Pharmacie */
  post('/api/ordonnances', 'pharmacie', req => P.creerOrdonnance(db, req.user, req.body || {}));
  post('/api/ordonnances/:id/delivrance', 'pharmacie', req => P.delivrer(db, req.user, id(req)));
  post('/api/stock/reception', 'pharmacie', req => P.receptionner(db, req.user, req.body || {}));
  post('/api/stock/ajustement', 'stock_ajuster', req => P.ajuster(db, req.user, req.body || {}, req.user.roles.includes('direction')));

  /* Consultations spécialisées, documents médicaux et rendez-vous */
  get('/api/consultations/:id', 'consulter', req => { const c = CL.lireConsultation(db, id(req)); return { ...c, donnees: JSON.parse(c.donnees), versions: CL.versionsConsultation(db, c.id) }; });
  post('/api/consultations/:id/modification', 'consulter', req => CL.modifierConsultation(db, req.user, id(req), (req.body || {}).donnees, (req.body || {}).motif));
  post('/api/notifications/lues', null, req => N.marquerLues(db, req.user, (req.body || {}).ids));
  get('/api/hospitalisations/:id', 'hosp_lire', req => H.dossier(db, id(req)));
  post('/api/hospitalisations', 'hosp_admettre', req => H.admettre(db, req.user, req.body || {}));
  post('/api/hospitalisations/:id/infirmiers', 'hosp_gerer', req => H.assigner(db, req.user, id(req), (req.body || {}).infirmiers));
  post('/api/hospitalisations/:id/transfert', 'hosp_gerer', req => H.transferer(db, req.user, id(req), (req.body || {}).chambre_id));
  post('/api/hospitalisations/:id/soins', 'hosp_soins', req => H.ajouterSoin(db, req.user, id(req), req.body || {}));
  post('/api/hospitalisations/:id/sortie', 'hosp_sortie', req => H.sortir(db, req.user, id(req), req.body || {}));
  post('/api/hospitalisations/:id/quitus', 'hosp_quitus', req => H.quitus(db, req.user, id(req), req.body || {}));
  get('/api/rh', 'rh_lire', req => RH.etat(db, req.user, req.query || {}));
  get('/api/rh/mon-planning', null, req => RH.monPlanning(db, req.user));
  post('/api/rh/employes', 'rh_gerer', req => RH.sauverEmploye(db, req.user, null, req.body || {}));
  put('/api/rh/employes/:id', 'rh_gerer', req => RH.sauverEmploye(db, req.user, id(req), req.body || {}));
  post('/api/rh/employes/:id/archivage', 'rh_gerer', req => RH.archiverEmploye(db, req.user, id(req), req.body || {}));
  post('/api/rh/reprise-comptes', 'rh_gerer', req => RH.reprendreComptes(db, req.user));
  post('/api/rh/planning', 'rh_gerer', req => RH.ajouterCreneau(db, req.user, req.body || {}));
  post('/api/rh/planning/recopie', 'rh_gerer', req => RH.recopierSemaine(db, req.user, req.body || {}));
  post('/api/rh/planning/:id/annulation', 'supprimer', req => RH.annulerCreneau(db, req.user, id(req)));
  post('/api/rh/paies/preparation', 'paie_preparer', req => RH.preparerPaie(db, req.user, req.body || {}));
  put('/api/rh/paies/:id/lignes', 'paie_preparer', req => RH.lignesManuelles(db, req.user, id(req), req.body || {}));
  post('/api/rh/paies/validation', 'paie_valider', req => RH.validerPaie(db, req.user, req.body || {}));
  post('/api/rh/paies/:id/paiement', 'paie_payer', req => RH.payerPaie(db, req.user, id(req), req.body || {}));
  post('/api/rh/paies/:id/annulation', 'supprimer', req => RH.annulerPaie(db, req.user, id(req), req.body || {}));
  post('/api/rh/avances', 'paie_preparer', req => RH.accorderAvance(db, req.user, req.body || {}));
  put('/api/rh/parametres', 'paie_valider', req => RH.sauverParametresPaie(db, req.user, req.body || {}));
  post('/api/constantes', 'constantes', req => CL.enregistrerConstantes(db, req.user, req.body || {}));
  post('/api/consultations', 'consulter', req => CL.ouvrirConsultation(db, req.user, req.body || {}));
  put('/api/consultations/:id', 'consulter', req => { CL.enregistrerConsultation(db, req.user, id(req), (req.body || {}).donnees); });
  post('/api/consultations/:id/validation', 'consulter', req => CL.validerConsultation(db, req.user, id(req), (req.body || {}).donnees));
  get('/api/dossiers/:id', 'consulter', req => CL.dossierMedical(db, req.user, id(req)));
  post('/api/documents', 'consulter', req => CL.creerDocument(db, req.user, req.body || {}));
  get('/api/documents/:id', 'consulter', req => CL.lireDocument(db, id(req)));
  get('/api/rdv', 'rdv_lire', req => {
    const du = date(req.query.du || jourLocal(), { label: 'Début' }), au = date(req.query.au || du, { label: 'Fin' });
    if (au < du || joursEntre(du, au) > 366) throw err(400, 'Période invalide.');
    return CL.listerRdv(db, du, au);
  });
  post('/api/rdv', 'rdv_ecrire', req => CL.creerRdv(db, req.user, req.body || {}));
  put('/api/rdv/:id', 'rdv_ecrire', req => CL.statutRdv(db, req.user, id(req), String((req.body || {}).statut || '')));
  get('/api/prescriptions', 'prescriptions', req => CL.prescriptionsPassage(db, Number(req.query.passage_id)));
  post('/api/pieces', 'consulter', req => CL.ajouterPiece(db, req.user, req.body || {}));
  app.get('/api/pieces/:id', A.exiger('consulter'), (req, res) => {
    try {
      const x = CL.lirePiece(db, id(req));
      res.setHeader('Content-Type', x.mime);
      res.setHeader('Cache-Control', 'private, max-age=3600');
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(x.nom)}"`);
      res.send(x.contenu);
    } catch (e) { envoyerErreur(res, e); }
  });
  const habiliteOphta = u => { const l = CL.specialitesDe(u); if (l.length && !l.includes('Ophtalmologie')) throw err(403, 'La reprise d’OphtaSuite est réservée aux médecins habilités en ophtalmologie.'); };
  post('/api/reprise/ophtasuite/analyse', 'consulter', req => { habiliteOphta(req.user); return REP.analyser(db, req.body); });
  post('/api/reprise/ophtasuite/import', 'consulter', req => { habiliteOphta(req.user); return REP.importer(db, req.user, req.body); });

  /* Avances des patients et factures récapitulatives */
  post('/api/avances', 'caisse', req => F.deposer(db, req.user, req.body || {}));
  get('/api/avances', null, req => {
    if (!A.peut(req.user, 'caisse') && !A.peut(req.user, 'pilotage')) throw err(403, 'Action non autorisée pour votre profil.');
    return F.mouvements(db, Number(req.query.patient_id));
  });
  post('/api/avances/remboursement', 'caisse', req => F.demanderRemboursement(db, req.user, req.body || {}));
  post('/api/avances/:id/versement', 'caisse', req => F.verser(db, req.user, id(req)));
  post('/api/factures', 'factures', req => F.creerFacture(db, req.user, req.body || {}));
  get('/api/factures/:id', 'factures', req => F.lireFacture(db, id(req)));

  /* Laboratoire */
  get('/api/laboratoire/file', 'laboratoire', () => LAB.file(db));
  get('/api/laboratoire/examens/:id', 'laboratoire', req => LAB.lire(db, id(req)));
  post('/api/laboratoire/examens/:id', 'laboratoire', req => LAB.enregistrer(db, req.user, id(req), req.body || {}));
  post('/api/laboratoire/resultats/:id/validation', 'laboratoire', req => LAB.valider(db, req.user, id(req)));
  post('/api/laboratoire/resultats/:id/rectification', 'laboratoire', req => LAB.rectifier(db, req.user, id(req), (req.body || {}).motif));

  /* Tiers payant */
  get('/api/tiers-payant/a-facturer', 'tiers_payant', () => TP.aFacturer(db));
  get('/api/tiers-payant/balance-agee', 'tiers_payant', () => TP.balanceAgee(db));
  get('/api/tiers-payant/cloture', 'tiers_payant', req => TP.rapportMois(db, (req.query || {}).periode));
  post('/api/tiers-payant/cloture', 'tiers_payant', req => TP.cloturerMois(db, req.user, req.body || {}));
  get('/api/medecin/tableau', 'consulter', req => ACT.tableauMedecin(db, req.user));
  get('/api/compta/journal', 'compta_lire', req => CPT.journal(db, req.query || {}));
  get('/api/compta/balance', 'compta_lire', req => CPT.balance(db, req.query || {}));
  get('/api/compta/plan', 'compta_lire', () => CPT.plan(db));
  put('/api/compta/plan', 'compta_parametrer', req => CPT.sauverPlan(db, req.user, req.body || {}));
  get('/api/bordereaux', 'tiers_payant', () => TP.listeBordereaux(db));
  post('/api/bordereaux', 'tiers_payant', req => TP.creerBordereau(db, req.user, req.body || {}));
  get('/api/bordereaux/:id', 'tiers_payant', req => TP.lireBordereau(db, id(req)));
  app.get('/api/bordereaux/:id/csv', A.exiger('tiers_payant'), (req, res) => {
    try {
      const x = TP.csvBordereau(db, id(req));
      R.journal(db, req.user, 'Tiers payant', 'Export de bordereau', x.nom);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${x.nom}"`);
      res.send(x.csv);
    } catch (e) { envoyerErreur(res, e); }
  });
  post('/api/bordereaux/:id/reglements', 'tiers_payant', req => TP.enregistrerReglement(db, req.user, id(req), req.body || {}));
  post('/api/bordereaux/:id/rejets', 'tiers_payant', req => TP.rejeter(db, req.user, id(req), req.body || {}));
  post('/api/bordereaux/:id/annulation', 'supprimer', req => TP.annulerBordereau(db, req.user, id(req), (req.body || {}).motif));

  /* Direction */
  post('/api/demandes/:id/decision', null, req => D.decider(db, req.user, id(req), !!(req.body || {}).accepte, (req.body || {}).reponse));
  post('/api/suppressions', 'suppression_demander', req => SUP.demander(db, req.user, req.body || {}));
  put('/api/parametres', 'parametres', req => ({ modifies: ADM.modifierParametres(db, req.user, req.body || {}) }));
  /* Export des écritures comptables pour le logiciel du comptable (v2.1). */
  app.get('/api/compta/export', A.exiger('compta_lire'), (req, res) => {
    try {
      const x = CPT.csv(db, req.query || {});
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${x.nom}"`);
      res.send(x.contenu);
    } catch (e) { res.status(e.status || 500).json({ erreur: e.status ? e.message : 'Erreur interne.' }); }
  });
  app.get('/api/exports/:type', A.exiger('exports'), (req, res) => {
    try {
      const du = date(req.query.du, { label: 'Début de période' }), au = date(req.query.au, { label: 'Fin de période' });
      if (au < du || joursEntre(du, au) > 366) throw err(400, 'Période invalide (un an au maximum).');
      const csv = D.exporter(db, req.params.type, du, au);
      R.journal(db, req.user, 'Direction', 'Export', `${req.params.type} du ${du} au ${au}`);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="msi-${req.params.type}-${du}-${au}.csv"`);
      res.send(csv);
    } catch (e) { envoyerErreur(res, e); }
  });
  get('/api/audit/verification', 'audit', () => R.verifierJournal(db));
  get('/api/pilotage', 'pilotage', req => PIL.tableau(db, String((req.query || {}).periode || '12m')));

  /* Administration et référentiels */
  get('/api/utilisateurs', 'utilisateurs', () => db.prepare('SELECT id, login, nom, roles, actif, changer_mdp, derniere_connexion, bloque_jusqua, specialites, ordre, telephone FROM utilisateurs ORDER BY nom').all());
  post('/api/utilisateurs', 'utilisateurs', req => ADM.creerUtilisateur(db, req.user, req.body || {}));
  put('/api/utilisateurs/:id', 'utilisateurs', req => ADM.modifierUtilisateur(db, req.user, id(req), req.body || {}));
  post('/api/utilisateurs/:id/reinitialisation', 'utilisateurs', req => ADM.reinitialiserMdp(db, req.user, id(req)));
  post('/api/referentiels/:table', 'referentiels', req => ({ id: ADM.sauverReferentiel(db, req.user, req.params.table, null, req.body || {}) }));
  put('/api/referentiels/:table/:id', 'referentiels', req => ({ id: ADM.sauverReferentiel(db, req.user, req.params.table, id(req), req.body || {}) }));
  post('/api/catalogue/produits', 'catalogue', req => ADM.sauverProduitPharmacie(db, req.user, null, req.body || {}));
  put('/api/catalogue/produits/:id', 'catalogue', req => ADM.sauverProduitPharmacie(db, req.user, id(req), req.body || {}));
  post('/api/imports/:type', 'referentiels', req => ADM.importer(db, req.user, req.params.type, (req.body || {}).csv));
  get('/api/sauvegardes', 'sauvegardes', () => ({ ...(opts.sauvegardeur ? opts.sauvegardeur.etat : { erreur: 'Sauvegarde automatique inactive' }) }));
  post('/api/sauvegardes', 'sauvegardes', async req => {
    if (!opts.sauvegardeur) throw err(409, 'Sauvegarde automatique inactive sur ce serveur.');
    const e = await opts.sauvegardeur.sauvegarder();
    R.journal(db, req.user, 'Administration', 'Sauvegarde manuelle', e.derniere ? e.derniere.fichier : e.erreur);
    return e;
  });

  app.use('/api', (req, res) => res.status(404).json({ erreur: 'Adresse inconnue.' }));
  app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
  return app;
}

module.exports = { creerApp };
