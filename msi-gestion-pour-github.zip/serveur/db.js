'use strict';
/* Base de données SQLite (fichier unique, mode WAL).
   Les déclencheurs rendent impossibles, même par erreur de programmation :
   la suppression des reçus, bons, passages, patients, paiements, sorties et mouvements de stock,
   la modification d'un reçu, d'un paiement ou d'une caisse clôturée, et toute retouche du journal d'audit. */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS meta (cle TEXT PRIMARY KEY, valeur TEXT);
CREATE TABLE IF NOT EXISTS parametres (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS compteurs (nom TEXT PRIMARY KEY, valeur INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS utilisateurs (
  id INTEGER PRIMARY KEY, login TEXT NOT NULL UNIQUE COLLATE NOCASE, nom TEXT NOT NULL, roles TEXT NOT NULL,
  hash TEXT NOT NULL, actif INTEGER NOT NULL DEFAULT 1, changer_mdp INTEGER NOT NULL DEFAULT 1,
  echecs INTEGER NOT NULL DEFAULT 0, bloque_jusqua TEXT, cree_le TEXT NOT NULL, derniere_connexion TEXT);
CREATE TABLE IF NOT EXISTS sessions (
  jeton TEXT PRIMARY KEY, utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id),
  cree_le TEXT NOT NULL, vu_le TEXT NOT NULL, ip TEXT);

CREATE TABLE IF NOT EXISTS assureurs (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, nom TEXT NOT NULL,
  niveau TEXT NOT NULL CHECK (niveau IN ('maj','aut')), actif INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS actes (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, libelle TEXT NOT NULL, famille TEXT NOT NULL,
  specialite TEXT, prix_non INTEGER NOT NULL CHECK (prix_non >= 0), prix_maj INTEGER NOT NULL CHECK (prix_maj >= 0),
  prix_aut INTEGER NOT NULL CHECK (prix_aut >= 0), a_valider INTEGER NOT NULL DEFAULT 0, actif INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS produits (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, nom TEXT NOT NULL, dci TEXT, forme TEXT, famille TEXT,
  seuil INTEGER NOT NULL DEFAULT 0, prix_non INTEGER NOT NULL CHECK (prix_non >= 0), prix_maj INTEGER NOT NULL CHECK (prix_maj >= 0),
  prix_aut INTEGER NOT NULL CHECK (prix_aut >= 0), psychotrope INTEGER NOT NULL DEFAULT 0,
  a_valider INTEGER NOT NULL DEFAULT 0, actif INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS lots (
  id INTEGER PRIMARY KEY, produit_id INTEGER NOT NULL REFERENCES produits(id), numero TEXT NOT NULL,
  peremption TEXT NOT NULL, quantite INTEGER NOT NULL CHECK (quantite >= 0), prix_achat INTEGER, fournisseur TEXT, cree_le TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mouvements (
  id INTEGER PRIMARY KEY, lot_id INTEGER NOT NULL REFERENCES lots(id), produit_id INTEGER NOT NULL, type TEXT NOT NULL,
  quantite INTEGER NOT NULL, motif TEXT, service TEXT, bon_id INTEGER, utilisateur_id INTEGER, cree_le TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY, ipp TEXT NOT NULL UNIQUE, nom TEXT NOT NULL, prenoms TEXT NOT NULL, recherche TEXT NOT NULL,
  sexe TEXT, naissance TEXT, telephone TEXT, tel_chiffres TEXT, commune TEXT, contact TEXT,
  assureur_id INTEGER REFERENCES assureurs(id), num_assure TEXT, taux INTEGER, validite TEXT,
  provisoire INTEGER NOT NULL DEFAULT 0, fusionne_dans INTEGER REFERENCES patients(id), cree_le TEXT NOT NULL, cree_par INTEGER);
CREATE TABLE IF NOT EXISTS passages (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, patient_id INTEGER REFERENCES patients(id), type TEXT NOT NULL,
  specialite TEXT, accord TEXT, accord_le TEXT, urgent INTEGER NOT NULL DEFAULT 0, cree_le TEXT NOT NULL, cree_par INTEGER);
CREATE TABLE IF NOT EXISTS bons (
  id INTEGER PRIMARY KEY, passage_id INTEGER NOT NULL REFERENCES passages(id), patient_id INTEGER REFERENCES patients(id),
  nature TEXT NOT NULL CHECK (nature IN ('acte','produit','reprise')), code TEXT NOT NULL, libelle TEXT NOT NULL,
  quantite INTEGER NOT NULL CHECK (quantite > 0), prix INTEGER NOT NULL CHECK (prix >= 0), taux INTEGER NOT NULL DEFAULT 0,
  assureur_id INTEGER, remise_pct INTEGER NOT NULL DEFAULT 0, demande_id INTEGER, paye INTEGER NOT NULL DEFAULT 0, recu_id INTEGER,
  delivre INTEGER NOT NULL DEFAULT 0, delivre_le TEXT, delivre_par INTEGER, urgent INTEGER NOT NULL DEFAULT 0,
  annule INTEGER NOT NULL DEFAULT 0, gratuit INTEGER NOT NULL DEFAULT 0, origine TEXT, acte_id INTEGER, produit_id INTEGER,
  specialite TEXT, ordonnance_id INTEGER, cree_le TEXT NOT NULL, cree_par INTEGER);

CREATE TABLE IF NOT EXISTS caisse_sessions (
  id INTEGER PRIMARY KEY, caissier_id INTEGER NOT NULL REFERENCES utilisateurs(id), vacation TEXT NOT NULL, ouverte_le TEXT NOT NULL,
  fonds INTEGER NOT NULL CHECK (fonds >= 0), fermee_le TEXT, theorique INTEGER, compte INTEGER, ecart INTEGER, justification TEXT,
  billetage TEXT, ecart_valide_par INTEGER, ecart_valide_le TEXT);
CREATE TABLE IF NOT EXISTS recus (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, patient_id INTEGER REFERENCES patients(id),
  session_id INTEGER NOT NULL REFERENCES caisse_sessions(id), caissier_id INTEGER NOT NULL REFERENCES utilisateurs(id),
  total INTEGER NOT NULL, part_assureur INTEGER NOT NULL, remise INTEGER NOT NULL, net INTEGER NOT NULL CHECK (net >= 0),
  code_controle TEXT NOT NULL, cree_le TEXT NOT NULL, annule INTEGER NOT NULL DEFAULT 0, avoir TEXT UNIQUE, annule_le TEXT,
  motif_annulation TEXT, rembourse_session_id INTEGER, rembourse_le TEXT);
CREATE TABLE IF NOT EXISTS paiements (
  id INTEGER PRIMARY KEY, recu_id INTEGER NOT NULL REFERENCES recus(id), mode TEXT NOT NULL,
  montant INTEGER NOT NULL CHECK (montant > 0), reference TEXT, remis INTEGER);
CREATE TABLE IF NOT EXISTS depenses (
  id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL REFERENCES caisse_sessions(id), categorie TEXT NOT NULL, libelle TEXT NOT NULL,
  montant INTEGER NOT NULL CHECK (montant > 0), justificatif TEXT NOT NULL, cree_le TEXT NOT NULL, utilisateur_id INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS demandes (
  id INTEGER PRIMARY KEY, type TEXT NOT NULL, statut TEXT NOT NULL DEFAULT 'en_attente', donnees TEXT NOT NULL, motif TEXT,
  demandeur_id INTEGER NOT NULL, cree_le TEXT NOT NULL, decideur_id INTEGER, decide_le TEXT);
CREATE TABLE IF NOT EXISTS ordonnances (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, passage_id INTEGER NOT NULL REFERENCES passages(id), patient_id INTEGER,
  prescripteur TEXT, reference_ext TEXT, cree_le TEXT NOT NULL, cree_par INTEGER, delivre_le TEXT, delivre_par INTEGER, lots TEXT);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, t TEXT NOT NULL, utilisateur_id INTEGER, login TEXT, poste TEXT, action TEXT NOT NULL,
  detail TEXT, avant TEXT, apres TEXT, niveau TEXT, hash TEXT NOT NULL);

/* Module clinique : consultations par spécialité, documents médicaux, rendez-vous */
CREATE TABLE IF NOT EXISTS consultations (
  id INTEGER PRIMARY KEY, passage_id INTEGER NOT NULL REFERENCES passages(id), patient_id INTEGER NOT NULL REFERENCES patients(id),
  specialite TEXT NOT NULL, medecin_id INTEGER NOT NULL REFERENCES utilisateurs(id), cree_le TEXT NOT NULL, maj_le TEXT NOT NULL,
  valide_le TEXT, donnees TEXT NOT NULL, diagnostic TEXT);
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, type TEXT NOT NULL, patient_id INTEGER NOT NULL REFERENCES patients(id),
  passage_id INTEGER, consultation_id INTEGER, specialite TEXT, medecin_id INTEGER NOT NULL REFERENCES utilisateurs(id),
  cree_le TEXT NOT NULL, donnees TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rdv (
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id), specialite TEXT, medecin_id INTEGER, date TEXT NOT NULL,
  heure TEXT, motif TEXT, statut TEXT NOT NULL DEFAULT 'prevu', cree_par INTEGER, cree_le TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pieces (
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id), consultation_id INTEGER, specialite TEXT, nom TEXT NOT NULL,
  mime TEXT NOT NULL, taille INTEGER NOT NULL, contenu BLOB NOT NULL, legende TEXT, medecin_id INTEGER NOT NULL REFERENCES utilisateurs(id), cree_le TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reprise_sources (source TEXT NOT NULL, cle TEXT NOT NULL, type TEXT NOT NULL, cible INTEGER NOT NULL, cree_le TEXT NOT NULL, PRIMARY KEY (source, cle));
CREATE INDEX IF NOT EXISTS i_pieces_patient ON pieces(patient_id);
CREATE TRIGGER IF NOT EXISTS pieces_figees BEFORE UPDATE OF contenu, nom, mime, taille, medecin_id, cree_le, consultation_id ON pieces
  BEGIN SELECT RAISE(ABORT, 'Pièce du dossier non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS pieces_non_supprimables BEFORE DELETE ON pieces BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
/* Tiers payant : bordereaux par assureur, règlements, rejets */
CREATE TABLE IF NOT EXISTS bordereaux (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, assureur_id INTEGER NOT NULL REFERENCES assureurs(id), du TEXT NOT NULL, au TEXT NOT NULL,
  total INTEGER NOT NULL, cree_le TEXT NOT NULL, cree_par INTEGER NOT NULL, annule INTEGER NOT NULL DEFAULT 0, motif_annulation TEXT);
CREATE TABLE IF NOT EXISTS bordereau_lignes (
  id INTEGER PRIMARY KEY, bordereau_id INTEGER NOT NULL REFERENCES bordereaux(id), bon_id INTEGER NOT NULL REFERENCES bons(id), montant INTEGER NOT NULL,
  rejete INTEGER NOT NULL DEFAULT 0, motif_rejet TEXT, annule INTEGER NOT NULL DEFAULT 0);
CREATE UNIQUE INDEX IF NOT EXISTS u_ligne_bon_active ON bordereau_lignes(bon_id) WHERE annule = 0;
CREATE TABLE IF NOT EXISTS reglements_assureurs (
  id INTEGER PRIMARY KEY, bordereau_id INTEGER NOT NULL REFERENCES bordereaux(id), date TEXT NOT NULL, mode TEXT NOT NULL, reference TEXT NOT NULL,
  montant INTEGER NOT NULL CHECK (montant > 0), cree_le TEXT NOT NULL, cree_par INTEGER NOT NULL);
CREATE TRIGGER IF NOT EXISTS bordereaux_figes BEFORE UPDATE OF numero, assureur_id, du, au, total, cree_le, cree_par ON bordereaux BEGIN SELECT RAISE(ABORT, 'Bordereau non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS bordereaux_non_supprimables BEFORE DELETE ON bordereaux BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS lignes_bordereau_figees BEFORE UPDATE OF bordereau_id, bon_id, montant ON bordereau_lignes BEGIN SELECT RAISE(ABORT, 'Ligne de bordereau non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS lignes_bordereau_non_supprimables BEFORE DELETE ON bordereau_lignes BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS reglements_figes BEFORE UPDATE ON reglements_assureurs BEGIN SELECT RAISE(ABORT, 'Règlement non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS reglements_non_supprimables BEFORE DELETE ON reglements_assureurs BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;

/* Laboratoire : un résultat par examen payé ; validé, il est figé (correction par rectification) */
CREATE TABLE IF NOT EXISTS resultats (
  id INTEGER PRIMARY KEY, bon_id INTEGER NOT NULL REFERENCES bons(id), patient_id INTEGER, passage_id INTEGER, code TEXT NOT NULL, libelle TEXT NOT NULL,
  donnees TEXT NOT NULL, conclusion TEXT, statut TEXT NOT NULL DEFAULT 'brouillon', saisi_par INTEGER NOT NULL, cree_le TEXT NOT NULL, maj_le TEXT NOT NULL,
  valide_par INTEGER, valide_le TEXT, rectifie_id INTEGER, motif_rectification TEXT);
CREATE UNIQUE INDEX IF NOT EXISTS u_resultat_bon ON resultats(bon_id) WHERE statut <> 'rectifie';
CREATE TRIGGER IF NOT EXISTS resultats_valides_figes BEFORE UPDATE OF donnees, conclusion, valide_par, valide_le, bon_id ON resultats WHEN OLD.valide_le IS NOT NULL
  BEGIN SELECT RAISE(ABORT, 'Résultat validé non modifiable : faites une rectification'); END;
CREATE TRIGGER IF NOT EXISTS resultats_non_supprimables BEFORE DELETE ON resultats BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;

/* Avances et dépôts des patients, factures récapitulatives */
CREATE TABLE IF NOT EXISTS avances (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, patient_id INTEGER NOT NULL REFERENCES patients(id),
  type TEXT NOT NULL CHECK (type IN ('depot', 'utilisation', 'remboursement')), montant INTEGER NOT NULL CHECK (montant > 0), mode TEXT, reference TEXT,
  session_id INTEGER, recu_id INTEGER, demande_id INTEGER, motif TEXT, cree_le TEXT NOT NULL, cree_par INTEGER NOT NULL, verse_le TEXT);
CREATE TRIGGER IF NOT EXISTS avances_figees BEFORE UPDATE OF numero, type, montant, mode, reference, recu_id, cree_le, cree_par ON avances
  BEGIN SELECT RAISE(ABORT, 'Mouvement d''avance non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS avances_non_supprimables BEFORE DELETE ON avances BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TABLE IF NOT EXISTS factures (
  id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, patient_id INTEGER, passage_id INTEGER, destinataire TEXT, donnees TEXT NOT NULL,
  total INTEGER NOT NULL, cree_le TEXT NOT NULL, cree_par INTEGER NOT NULL);
CREATE TRIGGER IF NOT EXISTS factures_figees BEFORE UPDATE OF numero, passage_id, destinataire, donnees, total, cree_le, cree_par ON factures BEGIN SELECT RAISE(ABORT, 'Facture non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS factures_non_supprimables BEFORE DELETE ON factures BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE INDEX IF NOT EXISTS i_avances_patient ON avances(patient_id);
CREATE INDEX IF NOT EXISTS i_resultats_patient ON resultats(patient_id);

CREATE INDEX IF NOT EXISTS i_consultations_patient ON consultations(patient_id);
CREATE INDEX IF NOT EXISTS i_consultations_passage ON consultations(passage_id);
CREATE INDEX IF NOT EXISTS i_documents_patient ON documents(patient_id);
CREATE INDEX IF NOT EXISTS i_documents_passage ON documents(passage_id);
CREATE INDEX IF NOT EXISTS i_rdv_date ON rdv(date);
CREATE TRIGGER IF NOT EXISTS consultations_validees_figees BEFORE UPDATE OF donnees, diagnostic, specialite, medecin_id, passage_id, cree_le, valide_le ON consultations
  WHEN OLD.valide_le IS NOT NULL BEGIN SELECT RAISE(ABORT, 'Consultation validée non modifiable : ajoutez une note complémentaire'); END;
CREATE TRIGGER IF NOT EXISTS consultations_non_supprimables BEFORE DELETE ON consultations BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS documents_figes BEFORE UPDATE OF numero, type, donnees, medecin_id, cree_le, consultation_id, passage_id, specialite ON documents
  BEGIN SELECT RAISE(ABORT, 'Document médical non modifiable : émettez un nouveau document'); END;
CREATE TRIGGER IF NOT EXISTS documents_non_supprimables BEFORE DELETE ON documents BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;

CREATE INDEX IF NOT EXISTS i_patients_recherche ON patients(recherche);
CREATE INDEX IF NOT EXISTS i_patients_tel ON patients(tel_chiffres);
CREATE INDEX IF NOT EXISTS i_passages_date ON passages(cree_le);
CREATE INDEX IF NOT EXISTS i_passages_patient ON passages(patient_id);
CREATE INDEX IF NOT EXISTS i_bons_passage ON bons(passage_id);
CREATE INDEX IF NOT EXISTS i_bons_etat ON bons(paye, annule);
CREATE INDEX IF NOT EXISTS i_bons_patient ON bons(patient_id);
CREATE INDEX IF NOT EXISTS i_bons_ordonnance ON bons(ordonnance_id);
CREATE INDEX IF NOT EXISTS i_bons_recu ON bons(recu_id);
CREATE INDEX IF NOT EXISTS i_recus_date ON recus(cree_le);
CREATE INDEX IF NOT EXISTS i_recus_session ON recus(session_id);
CREATE INDEX IF NOT EXISTS i_paiements_recu ON paiements(recu_id);
CREATE INDEX IF NOT EXISTS i_lots_produit ON lots(produit_id, peremption);
CREATE INDEX IF NOT EXISTS i_ord_date ON ordonnances(cree_le);
CREATE INDEX IF NOT EXISTS i_audit_t ON audit(t);

CREATE TRIGGER IF NOT EXISTS audit_non_modifiable BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT, 'Journal d''audit non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS audit_non_supprimable BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT, 'Journal d''audit non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS recus_non_supprimables BEFORE DELETE ON recus BEGIN SELECT RAISE(ABORT, 'Suppression de reçu interdite : utilisez un avoir'); END;
CREATE TRIGGER IF NOT EXISTS recus_figes BEFORE UPDATE OF numero, patient_id, session_id, caissier_id, total, part_assureur, remise, net, code_controle, cree_le ON recus
  BEGIN SELECT RAISE(ABORT, 'Reçu non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS paiements_figes BEFORE UPDATE ON paiements BEGIN SELECT RAISE(ABORT, 'Paiement non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS paiements_non_supprimables BEFORE DELETE ON paiements BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS bons_non_supprimables BEFORE DELETE ON bons BEGIN SELECT RAISE(ABORT, 'Suppression de bon interdite : annulez-le'); END;
CREATE TRIGGER IF NOT EXISTS bons_payes_figes BEFORE UPDATE OF prix, quantite, taux, remise_pct, passage_id ON bons WHEN OLD.paye = 1
  BEGIN SELECT RAISE(ABORT, 'Bon payé non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS passages_non_supprimables BEFORE DELETE ON passages BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS patients_non_supprimables BEFORE DELETE ON patients BEGIN SELECT RAISE(ABORT, 'Suppression interdite : fusionnez le doublon'); END;
CREATE TRIGGER IF NOT EXISTS caisse_close_figee BEFORE UPDATE OF caissier_id, vacation, ouverte_le, fonds, fermee_le, theorique, compte, ecart, justification, billetage ON caisse_sessions
  WHEN OLD.fermee_le IS NOT NULL BEGIN SELECT RAISE(ABORT, 'Caisse clôturée non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS depenses_figees BEFORE UPDATE ON depenses BEGIN SELECT RAISE(ABORT, 'Sortie de caisse non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS depenses_non_supprimables BEFORE DELETE ON depenses BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
CREATE TRIGGER IF NOT EXISTS mouvements_figes BEFORE UPDATE ON mouvements BEGIN SELECT RAISE(ABORT, 'Mouvement de stock non modifiable'); END;
CREATE TRIGGER IF NOT EXISTS mouvements_non_supprimables BEFORE DELETE ON mouvements BEGIN SELECT RAISE(ABORT, 'Suppression interdite'); END;
`;

/* Mise à jour d'une base existante (déjà initialisée) : tarifs de journée d'hospitalisation, à valider par la direction.
   Une base neuve les reçoit à l'initialisation ; la migration ne s'applique donc que si des actes existent déjà. */
function tarifsHospitalisation(db) {
  if (db.prepare('SELECT COUNT(*) n FROM actes').get().n === 0) return;
  const tarif = db.prepare('INSERT OR IGNORE INTO actes(code, libelle, famille, specialite, prix_non, prix_maj, prix_aut, a_valider, actif) VALUES (?, ?, ?, NULL, ?, ?, ?, 1, 1)');
  tarif.run('HOSP-STD', 'Journée d’hospitalisation, chambre standard', 'Hospitalisation', 15000, 15000, 15000);
  tarif.run('HOSP-VIP', 'Journée d’hospitalisation, chambre VIP', 'Hospitalisation', 35000, 35000, 35000);
}

function ouvrir(fichier) {
  if (fichier !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(fichier)), { recursive: true });
  const db = new Database(fichier);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  db.exec(SCHEMA);
  /* Migrations : colonnes ajoutées après la version 1.0 */
  const cols = db.prepare('PRAGMA table_info(utilisateurs)').all().map(c => c.name);
  if (!cols.includes('specialites')) db.exec('ALTER TABLE utilisateurs ADD COLUMN specialites TEXT');
  if (!cols.includes('ordre')) db.exec('ALTER TABLE utilisateurs ADD COLUMN ordre TEXT');
  if (!cols.includes('telephone')) db.exec('ALTER TABLE utilisateurs ADD COLUMN telephone TEXT');
  /* v1.5 : constantes prises à l'infirmerie, une fiche par passage, avec le médecin vers qui le patient est orienté. */
  db.exec(`CREATE TABLE IF NOT EXISTS constantes (
      id INTEGER PRIMARY KEY, passage_id INTEGER NOT NULL UNIQUE REFERENCES passages(id), patient_id INTEGER NOT NULL REFERENCES patients(id),
      valeurs TEXT NOT NULL, observation TEXT, medecin_id INTEGER NOT NULL REFERENCES utilisateurs(id), saisi_par INTEGER NOT NULL REFERENCES utilisateurs(id),
      saisi_le TEXT NOT NULL, maj_le TEXT NOT NULL);
    CREATE TRIGGER IF NOT EXISTS constantes_non_supprimables BEFORE DELETE ON constantes BEGIN SELECT RAISE(ABORT, 'Suppression interdite : constantes tracées.'); END;`);
  /* v1.6 : médecin et motif choisis à l'accueil, alertes des constantes, notifications (une par événement et par destinataire). */
  const colsP = db.prepare('PRAGMA table_info(passages)').all().map(c => c.name);
  if (!colsP.includes('medecin_id')) db.exec('ALTER TABLE passages ADD COLUMN medecin_id INTEGER REFERENCES utilisateurs(id)');
  if (!colsP.includes('motif')) db.exec('ALTER TABLE passages ADD COLUMN motif TEXT');
  const colsC = db.prepare('PRAGMA table_info(constantes)').all().map(c => c.name);
  if (!colsC.includes('alertes')) db.exec('ALTER TABLE constantes ADD COLUMN alertes TEXT');
  if (!colsC.includes('prioritaire')) db.exec('ALTER TABLE constantes ADD COLUMN prioritaire INTEGER NOT NULL DEFAULT 0');
  db.exec(`CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY, utilisateur_id INTEGER NOT NULL REFERENCES utilisateurs(id), type TEXT NOT NULL, titre TEXT NOT NULL, message TEXT,
      onglet TEXT, prioritaire INTEGER NOT NULL DEFAULT 0, cle TEXT NOT NULL, cree_le TEXT NOT NULL, lu_le TEXT);
    CREATE UNIQUE INDEX IF NOT EXISTS u_notification_cle ON notifications(utilisateur_id, cle);`);
  /* v1.7 : hospitalisation. Séjours, passages en chambre, infirmiers assignés et soins sont tracés et jamais supprimés ; un soin enregistré ne se modifie pas. */
  db.exec(`CREATE TABLE IF NOT EXISTS chambres (
      id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, nom TEXT NOT NULL, categorie TEXT NOT NULL CHECK (categorie IN ('standard', 'vip')),
      lits INTEGER NOT NULL DEFAULT 1 CHECK (lits BETWEEN 1 AND 12), actif INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS hospitalisations (
      id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, patient_id INTEGER NOT NULL REFERENCES patients(id), passage_id INTEGER NOT NULL REFERENCES passages(id),
      motif TEXT NOT NULL, medecin_id INTEGER NOT NULL REFERENCES utilisateurs(id), admis_le TEXT NOT NULL, admis_par INTEGER NOT NULL REFERENCES utilisateurs(id),
      statut TEXT NOT NULL DEFAULT 'en_cours' CHECK (statut IN ('en_cours', 'sortie')), sortie_le TEXT, sortie_par INTEGER REFERENCES utilisateurs(id), mode_sortie TEXT, compte_rendu TEXT);
    CREATE UNIQUE INDEX IF NOT EXISTS u_hospitalisation_en_cours ON hospitalisations(patient_id) WHERE statut = 'en_cours';
    CREATE TABLE IF NOT EXISTS hospitalisation_chambres (
      id INTEGER PRIMARY KEY, hospitalisation_id INTEGER NOT NULL REFERENCES hospitalisations(id), chambre_id INTEGER NOT NULL REFERENCES chambres(id),
      debut TEXT NOT NULL, fin TEXT, par INTEGER NOT NULL REFERENCES utilisateurs(id));
    CREATE TABLE IF NOT EXISTS hospitalisation_infirmiers (
      id INTEGER PRIMARY KEY, hospitalisation_id INTEGER NOT NULL REFERENCES hospitalisations(id), infirmier_id INTEGER NOT NULL REFERENCES utilisateurs(id),
      assigne_le TEXT NOT NULL, assigne_par INTEGER NOT NULL REFERENCES utilisateurs(id), retire_le TEXT);
    CREATE TABLE IF NOT EXISTS soins_hospitalisation (
      id INTEGER PRIMARY KEY, hospitalisation_id INTEGER NOT NULL REFERENCES hospitalisations(id), type TEXT NOT NULL CHECK (type IN ('constantes', 'soin', 'observation')),
      description TEXT, valeurs TEXT, alertes TEXT, acte_id INTEGER REFERENCES actes(id), quantite INTEGER, bon_id INTEGER REFERENCES bons(id),
      realise_par INTEGER NOT NULL REFERENCES utilisateurs(id), realise_le TEXT NOT NULL);
    CREATE TRIGGER IF NOT EXISTS hospitalisations_non_supprimables BEFORE DELETE ON hospitalisations BEGIN SELECT RAISE(ABORT, 'Suppression interdite : hospitalisation tracée.'); END;
    CREATE TRIGGER IF NOT EXISTS sejours_chambre_non_supprimables BEFORE DELETE ON hospitalisation_chambres BEGIN SELECT RAISE(ABORT, 'Suppression interdite : séjour en chambre tracé.'); END;
    CREATE TRIGGER IF NOT EXISTS soins_hospitalisation_non_supprimables BEFORE DELETE ON soins_hospitalisation BEGIN SELECT RAISE(ABORT, 'Suppression interdite : soin tracé.'); END;
    CREATE TRIGGER IF NOT EXISTS soins_hospitalisation_non_modifiables BEFORE UPDATE ON soins_hospitalisation BEGIN SELECT RAISE(ABORT, 'Soin enregistré : il ne se modifie pas, ajoutez une nouvelle entrée.'); END;`);
  /* v1.7 : quitus de sortie, délivré par la caisse quand la part patient est soldée ; la direction peut passer outre, avec un motif tracé. */
  const colsH = db.prepare('PRAGMA table_info(hospitalisations)').all().map(c => c.name);
  if (!colsH.includes('quitus_le')) db.exec('ALTER TABLE hospitalisations ADD COLUMN quitus_le TEXT');
  if (!colsH.includes('quitus_par')) db.exec('ALTER TABLE hospitalisations ADD COLUMN quitus_par INTEGER REFERENCES utilisateurs(id)');
  if (!colsH.includes('quitus_motif')) db.exec('ALTER TABLE hospitalisations ADD COLUMN quitus_motif TEXT');
  tarifsHospitalisation(db);
  /* v1.9 : clôtures mensuelles du tiers payant (historique, non supprimable). */
  db.exec(`CREATE TABLE IF NOT EXISTS clotures_mensuelles (
      id INTEGER PRIMARY KEY, periode TEXT NOT NULL, du TEXT NOT NULL, au TEXT NOT NULL, bordereaux TEXT NOT NULL, total INTEGER NOT NULL,
      cree_par INTEGER NOT NULL REFERENCES utilisateurs(id), cree_le TEXT NOT NULL);
    CREATE TRIGGER IF NOT EXISTS clotures_non_supprimables BEFORE DELETE ON clotures_mensuelles BEGIN SELECT RAISE(ABORT, 'Suppression interdite : clôture tracée.'); END;`);
  /* v2.2 : versions des consultations modifiées après validation (historique inaltérable) ; réponse de l'administrateur aux demandes. */
  db.exec(`CREATE TABLE IF NOT EXISTS consultation_versions (
      id INTEGER PRIMARY KEY, consultation_id INTEGER NOT NULL REFERENCES consultations(id), donnees TEXT NOT NULL, diagnostic TEXT,
      motif TEXT NOT NULL, modifie_par INTEGER NOT NULL REFERENCES utilisateurs(id), modifie_le TEXT NOT NULL);
    CREATE TRIGGER IF NOT EXISTS versions_non_supprimables BEFORE DELETE ON consultation_versions BEGIN SELECT RAISE(ABORT, 'Suppression interdite : version de consultation tracée.'); END;
    CREATE TRIGGER IF NOT EXISTS versions_non_modifiables BEFORE UPDATE ON consultation_versions BEGIN SELECT RAISE(ABORT, 'Version de consultation non modifiable.'); END;`);
  /* Le verrou des consultations validées reste en place ; il laisse seulement passer une modification du contenu médical
     (données, diagnostic) accompagnée de sa version précédente enregistrée au même instant. Tout le reste demeure figé. */
  const verrou = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = 'consultations_validees_figees'").get();
  if (!verrou || !/consultation_versions/.test(verrou.sql)) db.exec(`DROP TRIGGER IF EXISTS consultations_validees_figees;
    CREATE TRIGGER consultations_validees_figees BEFORE UPDATE OF donnees, diagnostic, specialite, medecin_id, passage_id, cree_le, valide_le ON consultations
      WHEN OLD.valide_le IS NOT NULL AND NOT (NEW.specialite IS OLD.specialite AND NEW.medecin_id IS OLD.medecin_id AND NEW.passage_id IS OLD.passage_id
        AND NEW.cree_le IS OLD.cree_le AND NEW.valide_le IS OLD.valide_le
        AND EXISTS (SELECT 1 FROM consultation_versions v WHERE v.consultation_id = OLD.id AND v.modifie_le = NEW.maj_le))
      BEGIN SELECT RAISE(ABORT, 'Consultation validée non modifiable : ajoutez une note complémentaire'); END;`);
  const colsD = db.prepare('PRAGMA table_info(demandes)').all().map(c => c.name);
  if (!colsD.includes('reponse')) db.exec('ALTER TABLE demandes ADD COLUMN reponse TEXT');
  /* v1.8 : ressources humaines. Rien ne se supprime (archivage, annulation) ; un bulletin validé est figé par la base elle-même. */
  db.exec(`CREATE TABLE IF NOT EXISTS employes (
      id INTEGER PRIMARY KEY, matricule TEXT NOT NULL UNIQUE, nom TEXT NOT NULL, prenoms TEXT, sexe TEXT, telephone TEXT, fonction TEXT NOT NULL, service TEXT,
      contrat TEXT NOT NULL CHECK (contrat IN ('CDI', 'CDD', 'Vacataire', 'Stage')), embauche_le TEXT NOT NULL, fin_contrat TEXT,
      salaire_base INTEGER NOT NULL DEFAULT 0 CHECK (salaire_base >= 0), taux_garde INTEGER NOT NULL DEFAULT 0 CHECK (taux_garde >= 0), taux_vacation INTEGER NOT NULL DEFAULT 0 CHECK (taux_vacation >= 0),
      numero_cnps TEXT, mode_paiement TEXT, utilisateur_id INTEGER REFERENCES utilisateurs(id), actif INTEGER NOT NULL DEFAULT 1, sortie_le TEXT, motif_sortie TEXT, cree_le TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS planning (
      id INTEGER PRIMARY KEY, employe_id INTEGER NOT NULL REFERENCES employes(id), jour TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('garde', 'consultation', 'permanence', 'astreinte', 'conge', 'absence')), debut TEXT NOT NULL, fin TEXT NOT NULL, observation TEXT,
      cree_par INTEGER NOT NULL REFERENCES utilisateurs(id), cree_le TEXT NOT NULL, annule_le TEXT, annule_par INTEGER REFERENCES utilisateurs(id));
    CREATE INDEX IF NOT EXISTS i_planning_jour ON planning(jour);
    CREATE TABLE IF NOT EXISTS paies (
      id INTEGER PRIMARY KEY, numero TEXT NOT NULL UNIQUE, employe_id INTEGER NOT NULL REFERENCES employes(id), periode TEXT NOT NULL, lignes TEXT NOT NULL,
      brut INTEGER NOT NULL, retenues INTEGER NOT NULL, net INTEGER NOT NULL, statut TEXT NOT NULL DEFAULT 'prepare' CHECK (statut IN ('prepare', 'valide', 'paye', 'annule')),
      prepare_par INTEGER NOT NULL REFERENCES utilisateurs(id), prepare_le TEXT NOT NULL, valide_par INTEGER REFERENCES utilisateurs(id), valide_le TEXT,
      paye_par INTEGER REFERENCES utilisateurs(id), paye_le TEXT, mode_paiement TEXT, reference TEXT, annule_le TEXT, motif_annulation TEXT);
    CREATE UNIQUE INDEX IF NOT EXISTS u_paie_periode ON paies(employe_id, periode) WHERE statut <> 'annule';
    CREATE TABLE IF NOT EXISTS avances_salaire (
      id INTEGER PRIMARY KEY, employe_id INTEGER NOT NULL REFERENCES employes(id), montant INTEGER NOT NULL CHECK (montant > 0), motif TEXT,
      accorde_le TEXT NOT NULL, accorde_par INTEGER NOT NULL REFERENCES utilisateurs(id), paie_id INTEGER REFERENCES paies(id));
    CREATE TRIGGER IF NOT EXISTS employes_non_supprimables BEFORE DELETE ON employes BEGIN SELECT RAISE(ABORT, 'Suppression interdite : archivez l’employé.'); END;
    CREATE TRIGGER IF NOT EXISTS planning_non_supprimable BEFORE DELETE ON planning BEGIN SELECT RAISE(ABORT, 'Suppression interdite : annulez le créneau.'); END;
    CREATE TRIGGER IF NOT EXISTS paies_non_supprimables BEFORE DELETE ON paies BEGIN SELECT RAISE(ABORT, 'Suppression interdite : annulez le bulletin.'); END;
    CREATE TRIGGER IF NOT EXISTS avances_salaire_non_supprimables BEFORE DELETE ON avances_salaire BEGIN SELECT RAISE(ABORT, 'Suppression interdite : avance sur salaire tracée.'); END;
    CREATE TRIGGER IF NOT EXISTS paies_figees BEFORE UPDATE OF lignes, brut, retenues, net, employe_id, periode ON paies WHEN OLD.statut <> 'prepare'
      BEGIN SELECT RAISE(ABORT, 'Bulletin validé : il ne se modifie plus (annulez-le, puis préparez-en un nouveau).'); END;`);
  db.prepare("INSERT INTO meta(cle, valeur) VALUES ('schema', '2') ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur").run();
  return db;
}

module.exports = { ouvrir, tarifsHospitalisation };
