'use strict';
/* Hospitalisation (v1.7) : admission, chambres standard et VIP, infirmiers assignés, suivi des soins, transfert et sortie.
   Le séjour est porté par un passage de type « hospitalisation » : journées et soins y deviennent des bons, encaissés à la caisse,
   pris en charge par l'assureur (accord), repris sur la facture récapitulative et les bordereaux comme tout autre acte. */
const S = require('../public/js/specialites');
const R = require('./regles');
const { pad, jourLocal, maintenant, jourDe, bornesJour, ajouterJours, err, texte, entier } = require('./outils');

const CATEGORIES = { standard: 'Standard', vip: 'VIP' };
const ACTE_JOURNEE = { standard: 'HOSP-STD', vip: 'HOSP-VIP' };
const MODES_SORTIE = ['Guérison ou amélioration', 'Transfert vers un autre établissement', 'Sortie contre avis médical', 'Décès'];

const chambre = (db, id) => db.prepare('SELECT * FROM chambres WHERE id = ?').get(Number(id));
const occupants = (db, chambreId) => db.prepare(`SELECT hc.hospitalisation_id FROM hospitalisation_chambres hc JOIN hospitalisations h ON h.id = hc.hospitalisation_id
  WHERE hc.chambre_id = ? AND hc.fin IS NULL AND h.statut = 'en_cours'`).all(chambreId);
const chambreActuelle = (db, hid) => db.prepare(`SELECT hc.id, hc.chambre_id, c.code, c.categorie FROM hospitalisation_chambres hc JOIN chambres c ON c.id = hc.chambre_id
  WHERE hc.hospitalisation_id = ? ORDER BY hc.id DESC LIMIT 1`).get(hid);
const nomUtilisateur = (db, id) => (db.prepare('SELECT nom FROM utilisateurs WHERE id = ?').get(id) || {}).nom || '';
const ageDe = p => { const n = p && p.naissance ? new Date(p.naissance) : null; return n && !isNaN(n) ? Math.floor((Date.now() - n.getTime()) / (365.25 * 864e5)) : null; };

function chambreLibre(db, id) {
  const c = chambre(db, id);
  if (!c || !c.actif) throw err(400, 'Choisissez une chambre ouverte.');
  if (occupants(db, c.id).length >= c.lits) throw err(409, `Chambre ${c.code} complète : choisissez une autre chambre.`);
  return c;
}
function hospitalisation(db, id) {
  const h = db.prepare('SELECT * FROM hospitalisations WHERE id = ?').get(Number(id));
  if (!h) throw err(404, 'Hospitalisation introuvable.');
  return h;
}
function enCours(db, id) {
  const h = hospitalisation(db, id);
  if (h.statut !== 'en_cours') throw err(409, 'Ce patient est déjà sorti.');
  return h;
}
function utilisateursDeRole(db, ids, role, message) {
  return [...new Set([].concat(ids || []).map(Number).filter(Boolean))].map(id => {
    const x = db.prepare('SELECT id, nom, roles, actif FROM utilisateurs WHERE id = ?').get(id);
    if (!x || !x.actif || !String(x.roles).split(',').includes(role)) throw err(400, message);
    return x;
  });
}
/* Constantes : mêmes règles qu'à l'infirmerie (tension 120/80, valeurs numériques, IMC calculé). */
function lireConstantes(brutes) {
  const valeurs = {};
  for (const [k, brut] of Object.entries(brutes || {})) {
    if (!S.CONSTANTES[k] || k === 'imc') continue;
    const t = String(brut == null ? '' : brut).trim().slice(0, 20);
    if (!t) continue;
    if (k === 'ta') {
      if (!/^\d{2,3}\s*\/\s*\d{2,3}$/.test(t)) throw err(400, 'Tension artérielle : écrivez par exemple 120/80.');
      valeurs.ta = t.replace(/\s+/g, '');
      continue;
    }
    const n = Number(t.replace(',', '.'));
    if (!isFinite(n) || n < 0) throw err(400, `${S.CONSTANTES[k].l} : valeur numérique attendue.`);
    valeurs[k] = t;
  }
  if (valeurs.poids && valeurs.taille) {
    const kg = Number(String(valeurs.poids).replace(',', '.')), m = Number(String(valeurs.taille).replace(',', '.')) / 100;
    if (kg > 0 && m > 0.3) valeurs.imc = String(Math.round(kg / (m * m) * 10) / 10).replace('.', ',');
  }
  if (!Object.keys(valeurs).length) throw err(400, 'Saisissez au moins une constante.');
  return valeurs;
}

function admettre(db, u, d) {
  const p = R.patient(db, Number(d.patient_id));
  if (!p) throw err(404, 'Patient introuvable.');
  if (p.fusionne_dans) throw err(409, 'Dossier fusionné : utilisez le dossier principal.');
  const motif = texte(d.motif, { label: 'Motif d’hospitalisation', max: 300, requis: true });
  const [m] = utilisateursDeRole(db, [d.medecin_id], 'medecin', 'Choisissez le médecin référent.');
  if (!m) throw err(400, 'Choisissez le médecin référent.');
  const infs = utilisateursDeRole(db, d.infirmiers, 'infirmier', 'Infirmier introuvable.');
  return db.transaction(() => {
    if (db.prepare("SELECT 1 FROM hospitalisations WHERE patient_id = ? AND statut = 'en_cours'").get(p.id)) throw err(409, 'Ce patient est déjà hospitalisé.');
    const c = chambreLibre(db, d.chambre_id);
    const v = R.ouvrirPassage(db, u, { patient_id: p.id, type: 'hospitalisation', accord: d.accord, medecin_id: m.id, motif: motif.slice(0, 160) }, 'hospitalisation');
    const annee = jourLocal().slice(0, 4), numero = `HOS-${annee}-${pad(R.suivant(db, 'hospitalisation:' + annee), 4)}`, t = maintenant();
    const id = db.prepare('INSERT INTO hospitalisations(numero, patient_id, passage_id, motif, medecin_id, admis_le, admis_par) VALUES (?,?,?,?,?,?,?)')
      .run(numero, p.id, v.id, motif, m.id, t, u.id).lastInsertRowid;
    db.prepare('INSERT INTO hospitalisation_chambres(hospitalisation_id, chambre_id, debut, par) VALUES (?,?,?,?)').run(id, c.id, t, u.id);
    for (const x of infs) db.prepare('INSERT INTO hospitalisation_infirmiers(hospitalisation_id, infirmier_id, assigne_le, assigne_par) VALUES (?,?,?,?)').run(id, x.id, t, u.id);
    R.journal(db, u, 'Hospitalisation', 'Admission', `${numero} ${R.nomPatient(p)} : chambre ${c.code} (${CATEGORIES[c.categorie]}), référent ${m.nom}${infs.length ? ', infirmiers : ' + infs.map(x => x.nom).join(', ') : ''}`);
    return { id, numero, chambre: c.code };
  })();
}

function assigner(db, u, id, ids) {
  const h = enCours(db, id), infs = utilisateursDeRole(db, ids, 'infirmier', 'Infirmier introuvable.'), t = maintenant();
  return db.transaction(() => {
    const actifs = db.prepare('SELECT * FROM hospitalisation_infirmiers WHERE hospitalisation_id = ? AND retire_le IS NULL').all(h.id), voulus = new Set(infs.map(x => x.id));
    for (const a of actifs) if (!voulus.has(a.infirmier_id)) db.prepare('UPDATE hospitalisation_infirmiers SET retire_le = ? WHERE id = ?').run(t, a.id);
    for (const x of infs) if (!actifs.some(a => a.infirmier_id === x.id)) db.prepare('INSERT INTO hospitalisation_infirmiers(hospitalisation_id, infirmier_id, assigne_le, assigne_par) VALUES (?,?,?,?)').run(h.id, x.id, t, u.id);
    R.journal(db, u, 'Hospitalisation', 'Infirmiers assignés', `${h.numero} : ${infs.map(x => x.nom).join(', ') || 'aucun'}`);
    return { infirmiers: infs.map(x => x.nom) };
  })();
}

function transferer(db, u, id, chambreId) {
  const h = enCours(db, id);
  return db.transaction(() => {
    const avant = chambreActuelle(db, h.id);
    if (avant && avant.chambre_id === Number(chambreId)) throw err(400, 'Le patient est déjà dans cette chambre.');
    const c = chambreLibre(db, chambreId), t = maintenant();
    if (avant) db.prepare('UPDATE hospitalisation_chambres SET fin = ? WHERE id = ? AND fin IS NULL').run(t, avant.id);
    db.prepare('INSERT INTO hospitalisation_chambres(hospitalisation_id, chambre_id, debut, par) VALUES (?,?,?,?)').run(h.id, c.id, t, u.id);
    R.journal(db, u, 'Hospitalisation', 'Transfert de chambre', `${h.numero} : chambre ${avant ? avant.code : '?'} vers ${c.code} (${CATEGORIES[c.categorie]})`);
    return { chambre: c.code };
  })();
}

function ajouterSoin(db, u, id, d) {
  const h = enCours(db, id), type = d.type;
  if (!['constantes', 'soin', 'observation'].includes(type)) throw err(400, 'Type de soin inconnu.');
  const description = texte(d.description, { label: type === 'observation' ? 'Observation' : 'Description du soin', max: 1000 }) || null;
  let valeurs = null, alertes = null, acte = null, quantite = 1;
  if (type === 'constantes') {
    valeurs = lireConstantes(d.valeurs);
    const p = R.patient(db, h.patient_id), a = ageDe(p);
    alertes = Object.entries(valeurs).map(([k, x]) => { const al = S.alerte(k, x, { age: a, sexe: p.sexe }); return al ? { k, valeur: x, niveau: al.niveau, texte: al.texte } : null; }).filter(Boolean);
  } else if (type === 'soin') {
    if (d.acte_id) {
      acte = db.prepare('SELECT * FROM actes WHERE id = ? AND actif = 1').get(Number(d.acte_id));
      if (!acte) throw err(400, 'Acte inconnu ou désactivé.');
      quantite = entier(d.quantite || 1, { label: 'Quantité', min: 1, max: 20 });
    } else if (!description) throw err(400, 'Décrivez le soin réalisé ou choisissez l’acte facturé.');
  } else if (!description) throw err(400, 'Saisissez l’observation.');
  return db.transaction(() => {
    const bonId = acte ? R.creerBon(db, u, R.passage(db, h.passage_id), { nature: 'acte', ref: acte }, quantite, 'hospitalisation') : null;
    const sid = db.prepare('INSERT INTO soins_hospitalisation(hospitalisation_id, type, description, valeurs, alertes, acte_id, quantite, bon_id, realise_par, realise_le) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(h.id, type, description, valeurs && JSON.stringify(valeurs), alertes && JSON.stringify(alertes), acte ? acte.id : null, acte ? quantite : null, bonId, u.id, maintenant()).lastInsertRowid;
    const resume = type === 'constantes' ? Object.entries(valeurs).map(([k, x]) => `${S.CONSTANTES[k].l.toLowerCase()} ${x}`).join(', ')
      : `${acte ? `${acte.libelle}${quantite > 1 ? ' × ' + quantite : ''}${description ? ', ' : ''}` : ''}${description || ''}`;
    R.journal(db, u, 'Hospitalisation', { constantes: 'Constantes', soin: 'Soin réalisé', observation: 'Observation' }[type], `${h.numero} : ${resume}${alertes && alertes.length ? ' (anormal)' : ''}`);
    return { id: sid, alertes: alertes || [], bon_id: bonId };
  })();
}

/* Chaque nuit passée est facturée au tarif de la chambre occupée à minuit ; un séjour de moins d'une nuit compte une journée. */
function journees(db, h, fin) {
  const segs = db.prepare(`SELECT hc.debut, COALESCE(hc.fin, ?) AS fin, c.categorie FROM hospitalisation_chambres hc JOIN chambres c ON c.id = hc.chambre_id
    WHERE hc.hospitalisation_id = ? ORDER BY hc.id`).all(fin, h.id);
  const n = { standard: 0, vip: 0 };
  for (let j = jourDe(h.admis_le); j < jourDe(fin); j = ajouterJours(j, 1)) {
    const minuit = bornesJour(ajouterJours(j, 1))[0];
    const s = segs.filter(x => x.debut <= minuit && x.fin > minuit).pop() || segs[segs.length - 1];
    n[s.categorie]++;
  }
  if (!n.standard && !n.vip && segs.length) n[segs[segs.length - 1].categorie] = 1;
  return n;
}

function sortir(db, u, id, d) {
  const h = enCours(db, id);
  if (!MODES_SORTIE.includes(d.mode)) throw err(400, 'Choisissez le mode de sortie.');
  const compteRendu = texte(d.compte_rendu, { label: 'Compte rendu de sortie', max: 4000, requis: true });
  return db.transaction(() => {
    const t = maintenant(), n = journees(db, h, t), v = R.passage(db, h.passage_id);
    for (const [cat, q] of Object.entries(n)) if (q) {
      const acte = db.prepare('SELECT * FROM actes WHERE code = ?').get(ACTE_JOURNEE[cat]);
      if (!acte || !acte.actif) throw err(409, `Tarif « journée ${CATEGORIES[cat]} » absent ou désactivé : la direction le rétablit dans Paramétrage, Tarifs des actes.`);
      R.creerBon(db, u, v, { nature: 'acte', ref: acte }, q, 'hospitalisation');
    }
    db.prepare('UPDATE hospitalisation_chambres SET fin = ? WHERE hospitalisation_id = ? AND fin IS NULL').run(t, h.id);
    db.prepare('UPDATE hospitalisation_infirmiers SET retire_le = ? WHERE hospitalisation_id = ? AND retire_le IS NULL').run(t, h.id);
    db.prepare("UPDATE hospitalisations SET statut = 'sortie', sortie_le = ?, sortie_par = ?, mode_sortie = ?, compte_rendu = ? WHERE id = ?").run(t, u.id, d.mode, compteRendu, h.id);
    const facture = Object.entries(n).filter(([, q]) => q).map(([k, q]) => `${q} journée${q > 1 ? 's' : ''} ${CATEGORIES[k]}`).join(' et ');
    R.journal(db, u, 'Hospitalisation', 'Sortie', `${h.numero} ${R.nomPatient(R.patient(db, h.patient_id))} : ${d.mode} ; ${facture} facturée${n.standard + n.vip > 1 ? 's' : ''}`);
    return { journees: n, facture };
  })();
}

function resume(db, h) {
  const p = R.patient(db, h.patient_id), c = chambreActuelle(db, h.id);
  const dernier = db.prepare("SELECT valeurs, alertes, realise_le FROM soins_hospitalisation WHERE hospitalisation_id = ? AND type = 'constantes' ORDER BY id DESC LIMIT 1").get(h.id);
  return {
    id: h.id, numero: h.numero, statut: h.statut, motif: h.motif, admis_le: h.admis_le, sortie_le: h.sortie_le, mode_sortie: h.mode_sortie, passage_id: h.passage_id,
    quitus_le: h.quitus_le || null, quitus_par: h.quitus_par ? nomUtilisateur(db, h.quitus_par) : null, quitus_motif: h.quitus_motif || null, reste: h.statut === 'sortie' ? resteAPayer(db, h) : null,
    patient: { id: p.id, ipp: p.ipp, nom: p.nom, prenoms: p.prenoms, sexe: p.sexe, naissance: p.naissance },
    medecin: { id: h.medecin_id, nom: nomUtilisateur(db, h.medecin_id) }, chambre: c ? { id: c.chambre_id, code: c.code, categorie: c.categorie } : null,
    infirmiers: db.prepare('SELECT u.id, u.nom FROM hospitalisation_infirmiers hi JOIN utilisateurs u ON u.id = hi.infirmier_id WHERE hi.hospitalisation_id = ? AND hi.retire_le IS NULL ORDER BY u.nom').all(h.id),
    nb_soins: db.prepare('SELECT COUNT(*) n FROM soins_hospitalisation WHERE hospitalisation_id = ?').get(h.id).n,
    constantes: dernier ? { valeurs: JSON.parse(dernier.valeurs), alertes: JSON.parse(dernier.alertes || '[]'), le: dernier.realise_le } : null
  };
}

function etat(db) {
  const hs = db.prepare("SELECT * FROM hospitalisations WHERE statut = 'en_cours' OR sortie_le >= ? OR (statut = 'sortie' AND quitus_le IS NULL) ORDER BY admis_le").all(bornesJour(ajouterJours(jourLocal(), -7))[0]).map(h => resume(db, h));
  const prix = code => { const a = db.prepare('SELECT prix_non, a_valider FROM actes WHERE code = ?').get(code); return a ? { prix: a.prix_non, a_valider: !!a.a_valider } : null; };
  return {
    chambres: db.prepare('SELECT * FROM chambres ORDER BY code').all().map(c => ({ ...c, occupants: hs.filter(x => x.statut === 'en_cours' && x.chambre && x.chambre.id === c.id).map(x => x.id) })),
    hospitalisations: hs,
    infirmiers: db.prepare('SELECT id, nom, roles FROM utilisateurs WHERE actif = 1 ORDER BY nom').all().filter(x => String(x.roles).split(',').includes('infirmier')).map(x => ({ id: x.id, nom: x.nom })),
    actes_soins: db.prepare("SELECT id, code, libelle FROM actes WHERE actif = 1 AND famille IN ('Soins', 'Acte technique') ORDER BY libelle").all(),
    medecins: db.prepare('SELECT id, nom, roles FROM utilisateurs WHERE actif = 1 ORDER BY nom').all().filter(x => String(x.roles).split(',').includes('medecin')).map(x => ({ id: x.id, nom: x.nom })),
    modes_sortie: MODES_SORTIE, tarifs: { standard: prix(ACTE_JOURNEE.standard), vip: prix(ACTE_JOURNEE.vip) }
  };
}

function dossier(db, id) {
  const h = hospitalisation(db, id);
  return {
    ...resume(db, h), compte_rendu: h.compte_rendu, admis_par: nomUtilisateur(db, h.admis_par),
    soins: db.prepare('SELECT s.*, u.nom AS par, a.libelle AS acte FROM soins_hospitalisation s LEFT JOIN utilisateurs u ON u.id = s.realise_par LEFT JOIN actes a ON a.id = s.acte_id WHERE s.hospitalisation_id = ? ORDER BY s.id DESC')
      .all(h.id).map(s => ({ ...s, valeurs: s.valeurs ? JSON.parse(s.valeurs) : null, alertes: s.alertes ? JSON.parse(s.alertes) : [] })),
    sejours: db.prepare('SELECT hc.debut, hc.fin, c.code, c.categorie FROM hospitalisation_chambres hc JOIN chambres c ON c.id = hc.chambre_id WHERE hc.hospitalisation_id = ? ORDER BY hc.id').all(h.id),
    journees: h.statut === 'en_cours' ? journees(db, h, maintenant()) : null
  };
}

/* Reste à payer par le patient sur le séjour : bons non réglés, part patient après remise. */
function resteAPayer(db, h) {
  return db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0 AND gratuit = 0').all(h.passage_id).reduce((s, b) => s + R.montants(b).net, 0);
}
const fcfa = n => `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} FCFA`;

/* Quitus de sortie (anti-fuite) : délivré par la caisse quand la part patient est soldée ;
   la direction peut passer outre, avec un motif tracé en alerte au journal. */
function quitus(db, u, id, d) {
  const h = hospitalisation(db, id);
  if (h.statut !== 'sortie') throw err(409, 'Le médecin n’a pas encore prononcé la sortie.');
  if (h.quitus_le) throw err(409, 'Quitus déjà délivré.');
  const reste = resteAPayer(db, h), direction = String(u.roles).split(',').includes('direction');
  let motif = null;
  if (reste > 0) {
    if (!direction) throw err(409, `Reste à payer : ${fcfa(reste)}. Encaissez d’abord le solde à la caisse.`);
    motif = texte(d.motif, { label: 'Motif', max: 300 }) || '';
    if (motif.length < 10) throw err(400, `Reste à payer : ${fcfa(reste)}. Pour délivrer le quitus malgré tout, indiquez le motif (10 caractères au moins).`);
  }
  db.prepare('UPDATE hospitalisations SET quitus_le = ?, quitus_par = ?, quitus_motif = ? WHERE id = ?').run(maintenant(), u.id, motif, h.id);
  R.journal(db, u, 'Hospitalisation', 'Quitus de sortie', `${h.numero} ${R.nomPatient(R.patient(db, h.patient_id))}${reste ? ` : délivré par la direction malgré ${fcfa(reste)} restant, motif : ${motif}` : ' : séjour soldé'}`,
    reste ? { niveau: 'alerte' } : undefined);
  return { reste };
}

module.exports = { quitus, resteAPayer, CATEGORIES, MODES_SORTIE, admettre, assigner, transferer, ajouterSoin, sortir, journees, etat, dossier };
