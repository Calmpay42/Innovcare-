'use strict';
/* Reprise des données d'OphtaSuite (fichier « ophtasuite-sauvegarde-AAAA-MM-JJ.json »).
   - Tout ou rien : une erreur annule l'ensemble.
   - Sans doublon : chaque fiche d'origine n'est reprise qu'une fois (table reprise_sources) ; relancer l'import ne crée rien de plus.
   - Sans caisse : aucun bon n'est créé, ces actes ont été réglés dans l'ancien système.
   - Historique figé : les consultations reprises sont validées à leur date d'origine.
   Les tarifs, le stock et la liste des médecins d'OphtaSuite ne sont pas repris : MSI Gestion les gère déjà. */
const crypto = require('crypto');
const { pad, jourLocal, maintenant, norm, chiffres, err } = require('./outils');
const R = require('./regles');
const A = require('./auth');
const S = require('../public/js/specialites');
const CL = require('./clinique');

const SOURCE = 'ophtasuite';
const SPE = 'Ophtalmologie';
const COLLECTIONS = ['patients', 'consultations', 'ordonnancesMed', 'ordonnancesLunettes', 'certificats', 'certificatsMedicaux', 'interpretations',
  'comptesRendusOp', 'explorations', 'bilansBiologiques', 'bulletinsRadio', 'bulletinsOphtalmo', 'photosDossier', 'fondOeilSchemas', 'rdv'];
const t = v => (v == null ? '' : String(v)).trim();
const jour = v => (/^\d{4}-\d{2}-\d{2}/.test(t(v)) ? t(v).slice(0, 10) : null);
const horodatage = j => new Date(`${j}T09:00:00`).toISOString();
const paire = (od, og) => (t(od) || t(og) ? { OD: t(od), OG: t(og) } : undefined);
const liste = (...v) => v.map(t).filter(Boolean).join('\n');

function lireSauvegarde(b) {
  if (!b || typeof b !== 'object' || !Array.isArray(b.patients)) throw err(400, 'Fichier non reconnu : choisissez une sauvegarde OphtaSuite (fichier .json exporté depuis OphtaSuite).');
  const o = {};
  for (const c of COLLECTIONS) o[c] = (Array.isArray(b[c]) ? b[c] : []).filter(x => x && typeof x === 'object' && x.id);
  return o;
}
const dejaRepris = (db, cle) => db.prepare('SELECT cible FROM reprise_sources WHERE source = ? AND cle = ?').get(SOURCE, String(cle)) || null;
const noter = (db, cle, type, cible) => db.prepare('INSERT INTO reprise_sources(source, cle, type, cible, cree_le) VALUES (?,?,?,?,?)').run(SOURCE, String(cle), type, cible, maintenant());

/* Rapprochement : mêmes nom et prénoms, et même date de naissance ou même téléphone. */
function rapprocher(db, p) {
  const nom = t(p.nom).toUpperCase(), prenoms = t(p.prenom || p.prenoms), dn = jour(p.dateNaissance), tel = chiffres(p.telephone);
  if (!nom && !prenoms) return null;
  const candidats = db.prepare(`SELECT id, naissance, tel_chiffres FROM patients WHERE fusionne_dans IS NULL AND recherche LIKE ?`).all(norm(`${nom} ${prenoms}`) + ' |%');
  return candidats.find(c => (dn && c.naissance === dn) || (tel.length >= 8 && c.tel_chiffres === tel)) || null;
}

function analyser(db, sauvegarde) {
  const b = lireSauvegarde(sauvegarde);
  const r = { collections: {}, patients: { rapproches: 0, nouveaux: 0, deja_repris: 0 }, deja_repris: 0 };
  for (const c of COLLECTIONS) {
    const items = b[c], repris = items.filter(x => dejaRepris(db, `${c}:${x.id}`)).length;
    r.collections[c] = { total: items.length, a_reprendre: items.length - repris };
    r.deja_repris += repris;
  }
  for (const p of b.patients) {
    if (dejaRepris(db, `patients:${p.id}`)) r.patients.deja_repris++;
    else if (rapprocher(db, p)) r.patients.rapproches++;
    else r.patients.nouveaux++;
  }
  r.rdv_passes = b.rdv.filter(x => !(jour(x.date) >= jourLocal())).length;
  return r;
}

/* Compte technique, inactif, auquel l'historique repris est attribué (le nom du médecin d'origine est conservé). */
function compteReprise(db) {
  const c = db.prepare("SELECT id FROM utilisateurs WHERE login = 'reprise.ophtasuite'").get();
  if (c) return c.id;
  return db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, actif, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,1,?,?)')
    .run('reprise.ophtasuite', 'Reprise OphtaSuite', 'medecin', A.hacher(crypto.randomBytes(24).toString('hex')), maintenant(), SPE).lastInsertRowid;
}

function importer(db, u, sauvegarde) {
  const b = lireSauvegarde(sauvegarde);
  const sp = S.SPECIALITES[SPE];
  const bilan = { patients_crees: 0, patients_rapproches: 0, consultations: 0, documents: 0, photos: 0, rdv: 0, ignores: [] };
  db.transaction(() => {
    const medecin = compteReprise(db);
    const patients = new Map(), consultations = new Map();
    const ignorer = (c, x, raison) => bilan.ignores.push(`${c} ${x.id} : ${raison}`);

    /* Patients */
    for (const p of b.patients) {
      const deja = dejaRepris(db, `patients:${p.id}`);
      if (deja) { patients.set(p.id, deja.cible); continue; }
      let id = (rapprocher(db, p) || {}).id;
      if (id) bilan.patients_rapproches++;
      else {
        const nom = t(p.nom).toUpperCase() || 'INCONNU', prenoms = t(p.prenom || p.prenoms) || '-';
        const sexe = /^f/i.test(t(p.sexe)) ? 'F' : /^(m|h)/i.test(t(p.sexe)) ? 'M' : null, dn = jour(p.dateNaissance);
        id = db.prepare(`INSERT INTO patients (ipp, nom, prenoms, recherche, sexe, naissance, telephone, tel_chiffres, commune, provisoire, cree_le, cree_par)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run('P-' + pad(R.suivant(db, 'ipp'), 6), nom, prenoms, `${norm(`${nom} ${prenoms}`)} | ${norm(`${prenoms} ${nom}`)}`, sexe, dn,
          t(p.telephone) || null, chiffres(p.telephone), t(p.adresse) || null, dn && sexe && t(p.telephone) ? 0 : 1, maintenant(), u.id).lastInsertRowid;
        bilan.patients_crees++;
      }
      noter(db, `patients:${p.id}`, 'patient', id);
      patients.set(p.id, id);
      const infos = liste(p.antecedents && `Antécédents : ${t(p.antecedents)}`, p.profession && `Profession : ${t(p.profession)}`, p.suiviGlaucome && 'Suivi glaucome : oui', p.numeroSuivi && `N° de suivi OphtaSuite : ${t(p.numeroSuivi)}`);
      if (infos) document('note', { patientId: p.id, date: jour(p.dateCreation) || jourLocal() }, { texte: `Dossier OphtaSuite\n${infos}` }, `patients-infos:${p.id}`);
    }

    function passage(pid, j) {
      const numero = 'OPH-REP-' + pad(R.suivant(db, 'reprise:ophtasuite:passage'), 5);
      return db.prepare("INSERT INTO passages(numero, patient_id, type, specialite, cree_le, cree_par) VALUES (?,?,'reprise',?,?,?)").run(numero, pid, SPE, horodatage(j), u.id).lastInsertRowid;
    }
    function document(type, x, donnees, cle) {
      if (dejaRepris(db, cle)) return;
      const pid = patients.get(x.patientId);
      if (!pid) return ignorer(cle.split(':')[0], x, 'patient absent de la sauvegarde');
      const j = jour(x.date) || jourLocal(), lien = consultations.get(`${pid}|${j}`) || {};
      const numero = `REP-${CL.TYPES_DOC[type][0]}-${pad(R.suivant(db, 'reprise:ophtasuite:document'), 5)}`;
      const id = db.prepare('INSERT INTO documents(numero, type, patient_id, passage_id, consultation_id, specialite, medecin_id, cree_le, donnees) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(numero, type, pid, lien.passage || null, lien.id || null, SPE, medecin, horodatage(j), JSON.stringify({ ...donnees, reprise: 'OphtaSuite', prescripteur_origine: t(x.prescripteur || x.medecin) || undefined })).lastInsertRowid;
      noter(db, cle, type, id);
      bilan.documents++;
    }

    /* Consultations : validées à leur date d'origine */
    for (const c of b.consultations) {
      const cle = `consultations:${c.id}`, deja = dejaRepris(db, cle), pid = patients.get(c.patientId);
      if (!pid) { if (!deja) ignorer('consultations', c, 'patient absent de la sauvegarde'); continue; }
      const j = jour(c.date) || jourLocal();
      if (deja) { const x = db.prepare('SELECT id, passage_id FROM consultations WHERE id = ?').get(deja.cible); if (x) consultations.set(`${pid}|${j}`, { id: x.id, passage: x.passage_id }); continue; }
      const d = {
        motif: t(c.motif), atcd_familiaux: t(c.atcdFamiliaux), atcd_medicaux: liste(c.atcdPathologiques, c.atcdMedicaux), atcd_chirurgicaux: t(c.atcdChirurgicaux),
        atcd_traumatismes: t(c.atcdTraumatisme), porte_verres: c.porteVerres === true || /^o/i.test(t(c.porteVerres)) ? 'Oui' : c.porteVerres === false || /^n/i.test(t(c.porteVerres)) ? 'Non' : '',
        porte_verres_details: t(c.porteVerresDetails), taille: t(c.taille), poids: t(c.poids), temperature: t(c.temperature), ta: t(c.tensionArterielle), fr: t(c.freqResp),
        pouls: t(c.pouls), glycemie: t(c.glycemie),
        av_loin_sc: paire(c.avODsc, c.avOGsc), av_loin_ac: paire(c.avODac, c.avOGac), av_ts: paire(c.avODts, c.avOGts), av_pres_sc: paire(c.avpODsc, c.avpOGsc),
        av_pres_ac: paire(c.avpODac, c.avpOGac), to: paire(c.toOD, c.toOG), pachy: paire(c.pachyOD, c.pachyOG), segment: paire(c.segmentOD, c.segmentOG), fond: paire(c.fondOD, c.fondOG),
        diagnostic: t(c.diagnostic), conduite: liste(c.conduite, c.examensAFaire && 'Examens complémentaires à faire.'), prochain_controle: jour(c.nextGlaucomeRdv) || '',
        medecin_origine: t(c.medecin), reprise: 'OphtaSuite'
      };
      const passageId = passage(pid, j), cree = horodatage(j);
      const id = db.prepare('INSERT INTO consultations(passage_id, patient_id, specialite, medecin_id, cree_le, maj_le, valide_le, donnees, diagnostic) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(passageId, pid, SPE, medecin, cree, cree, cree, JSON.stringify(d), d.diagnostic.slice(0, 300) || null).lastInsertRowid;
      noter(db, cle, 'consultation', id);
      consultations.set(`${pid}|${j}`, { id, passage: passageId });
      bilan.consultations++;
    }

    /* Documents */
    for (const x of b.ordonnancesMed) {
      const lignes = (Array.isArray(x.medicaments) ? x.medicaments : []).filter(m => t(m && m.nom)).map(m => ({ medicament: t(m.nom), posologie: t(m.posologie), duree: liste(t(m.duree), t(m.quantite) && `Quantité : ${t(m.quantite)}`).replace('\n', ', ') }));
      document('ordonnance', x, { lignes, conseils: t(x.codeAffection) && `Code affection : ${t(x.codeAffection)}` }, `ordonnancesMed:${x.id}`);
    }
    for (const x of b.ordonnancesLunettes) {
      const oeil = o => ({ sphere: t(x[`${o}_loin_sph`]), cylindre: t(x[`${o}_loin_cyl`]), axe: t(x[`${o}_loin_axe`]), addition: '' });
      const pres = ['od', 'og'].map(o => [x[`${o}_pres_sph`], x[`${o}_pres_cyl`], x[`${o}_pres_axe`]].some(t) ? `${o.toUpperCase()} sphère ${t(x[`${o}_pres_sph`])}, cylindre ${t(x[`${o}_pres_cyl`])}, axe ${t(x[`${o}_pres_axe`])}` : '').filter(Boolean);
      document('lunettes', x, { od: oeil('od'), og: oeil('og'), vision: pres.length ? 'De loin et de près' : 'De loin', verres: t(x.typeVerre), options: Array.isArray(x.options) ? x.options.map(t) : [],
        ecart: '', remarques: pres.length ? `Vision de près : ${pres.join(' ; ')}` : '' }, `ordonnancesLunettes:${x.id}`);
    }
    for (const x of b.certificats) {
      document('certificat', x, { sous_type: 'arret', jours: Number(x.jours) || null, debut: jour(x.dateDebut) || jour(x.date), reprise: jour(x.dateReprise) || null,
        motif_interne: liste(x.motif, x.prolongation && `Prolongation jusqu’au ${t(x.dateProlongation)}`) }, `certificats:${x.id}`);
    }
    for (const x of b.certificatsMedicaux) document('certificat', x, { sous_type: 'medical', objet: t(x.objet), constat: t(x.constat), conclusion: liste(x.conclusion, x.validite && `Validité : ${t(x.validite)}`) }, `certificatsMedicaux:${x.id}`);
    const META = new Set(['id', 'patientId', 'date', 'examType', 'type', 'prescripteur', 'medecin']);
    for (const x of b.interpretations) {
      const cr = sp.comptes_rendus.find(c => c.cle === x.examType);
      const champs = Object.fromEntries(Object.entries(x).filter(([k, v]) => !META.has(k) && t(v)).map(([k, v]) => [k, t(v)]));
      const connus = cr && Object.keys(champs).every(k => cr.champs.some(c => c.k === k));
      document('compte_rendu', x, connus ? { cle: cr.cle, titre: cr.l, champs }
        : { cle: 'autre', titre: 'Autre examen (compte rendu libre)', champs: { titre: cr ? cr.l : t(x.examType) || 'Interprétation', texte: Object.entries(champs).map(([k, v]) => `${k} : ${v}`).join('\n') } }, `interpretations:${x.id}`);
    }
    for (const x of b.comptesRendusOp) {
      document('compte_rendu', x, { cle: 'cro', titre: 'Compte rendu opératoire', champs: { intervention: t(x.type), indication: t(x.indication),
        technique: liste(x.oeil && `Œil : ${t(x.oeil)}`, x.anesthesie && `Anesthésie : ${t(x.anesthesie)}`, x.implant && `Implant : ${t(x.implant)}`, x.chirurgien && `Chirurgien : ${t(x.chirurgien)}`, x.technique),
        deroulement: t(x.deroulement), suites: t(x.suites), prescription: t(x.prescription), consignes: t(x.consignes) } }, `comptesRendusOp:${x.id}`);
    }
    const examens = (x, cle, autres) => document('examens', x, { items: (Array.isArray(x.examens) ? x.examens : []).map(e => ({ l: t(e && (e.l || e.nom || e)) })).filter(e => e.l),
      autres: t(autres), renseignement: t(x.renseignement), urgent: false, realise: !!x.realise }, cle);
    for (const x of b.explorations) examens(x, `explorations:${x.id}`, '');
    for (const x of b.bilansBiologiques) examens(x, `bilansBiologiques:${x.id}`, x.autresExamens);
    for (const x of b.bulletinsRadio) examens(x, `bulletinsRadio:${x.id}`, liste(x.radiographie && `Radiographie : ${t(x.radiographie)}`, x.echographie && `Échographie : ${t(x.echographie)}`));
    for (const x of b.bulletinsOphtalmo) document('orientation', x, { destinataire: t(x.specialite) === 'Autre' || !t(x.specialite) ? t(x.specialiteAutre) || 'Confrère' : t(x.specialite), motif: t(x.renseignement) || 'Avis spécialisé', urgent: false }, `bulletinsOphtalmo:${x.id}`);
    for (const x of b.fondOeilSchemas) {
      document('compte_rendu', x, { cle: 'autre', titre: 'Autre examen (compte rendu libre)', champs: { titre: 'Schéma du fond d’œil (OphtaSuite)',
        texte: liste(x.motif && `Motif : ${t(x.motif)}`, x.commentaireOD && `Œil droit : ${t(x.commentaireOD)}`, x.commentaireOG && `Œil gauche : ${t(x.commentaireOG)}`, 'Le tracé du schéma n’est pas repris ; sa photo, si elle existe, est jointe au dossier.') } }, `fondOeilSchemas:${x.id}`);
    }

    /* Photos du dossier (et photos jointes aux schémas) */
    for (const x of [...b.photosDossier, ...b.fondOeilSchemas]) {
      const cle = `photos:${x.id}`, url = t(x.dataUrl || x.photo);
      if (!url || dejaRepris(db, cle)) continue;
      const pid = patients.get(x.patientId);
      const m = url.match(/^data:([\w/+.-]+);base64,(.+)$/);
      if (!pid || !m) { ignorer('photos', x, pid ? 'image illisible' : 'patient absent de la sauvegarde'); continue; }
      let buf;
      try { buf = CL.controlerPiece(m[1] === 'image/jpg' ? 'image/jpeg' : m[1], m[2]); } catch (e) { ignorer('photos', x, e.message); continue; }
      const j = jour(x.date) || jourLocal();
      const id = CL.inserePiece(db, { patient_id: pid, consultation_id: (consultations.get(`${pid}|${j}`) || {}).id, specialite: SPE, nom: `ophtasuite-${x.id}`,
        mime: m[1] === 'image/jpg' ? 'image/jpeg' : m[1], buf, legende: liste(x.motif, x.oeil && `Œil : ${t(x.oeil)}`, x.renseignement).replace(/\n/g, ' ; '), medecin_id: medecin, cree_le: horodatage(j) });
      noter(db, cle, 'piece', id);
      bilan.photos++;
    }

    /* Rendez-vous à venir seulement */
    for (const x of b.rdv) {
      const cle = `rdv:${x.id}`, j = jour(x.date), pid = patients.get(x.patientId);
      if (dejaRepris(db, cle) || !pid || !(j >= jourLocal())) continue;
      const heure = /^([01]\d|2[0-3]):[0-5]\d$/.test(t(x.heure)) ? t(x.heure) : null;
      const id = db.prepare("INSERT INTO rdv(patient_id, specialite, medecin_id, date, heure, motif, statut, cree_par, cree_le) VALUES (?,?,NULL,?,?,?,'prevu',?,?)")
        .run(pid, SPE, j, heure, t(x.motif) || null, u.id, maintenant()).lastInsertRowid;
      noter(db, cle, 'rdv', id);
      bilan.rdv++;
    }
    R.journal(db, u, 'Consultation', 'Reprise OphtaSuite', `${bilan.patients_crees} patient(s) créé(s), ${bilan.patients_rapproches} rapproché(s), ${bilan.consultations} consultation(s), ${bilan.documents} document(s), ${bilan.photos} photo(s), ${bilan.rdv} rendez-vous`, { niveau: 'alerte' });
  })();
  return bilan;
}

module.exports = { analyser, importer, COLLECTIONS };
