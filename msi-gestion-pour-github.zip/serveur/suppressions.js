'use strict';
/* Demandes de suppression (v2.2). Seul l'administrateur supprime ; tout autre utilisateur lui adresse une demande motivée.
   Rien n'est effacé physiquement : à l'acceptation, l'élément est annulé (il cesse d'être compté : caisse, statistiques,
   comptabilité, paie) et reste dans l'historique, avec la demande, son motif et la décision. */
const R = require('./regles');
const RH = require('./rh');
const TP = require('./tiers-payant');
const { err, texte, maintenant, fmt } = require('./outils');

const nomEmp = e => `${e.nom} ${e.prenoms || ''}`.trim();
const OBJETS = {
  passage: {
    libelle: 'Annulation de passage',
    decrire(db, x) {
      const v = R.passage(db, x.id);
      if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
      const actifs = db.prepare('SELECT paye FROM bons WHERE passage_id = ? AND annule = 0').all(v.id);
      if (!actifs.length) throw err(409, 'Ce passage est déjà annulé.');
      if (actifs.some(b => b.paye)) throw err(409, 'Un acte de ce passage est déjà payé : demandez plutôt l’annulation du reçu à la caisse.');
      return `${v.numero}, ${R.nomPatient(R.patient(db, v.patient_id))} (${v.type})`;
    },
    executer: (db, u, x, motif) => R.annulerPassage(db, u, x.id, motif, 'Administration', true)
  },
  doublon: {
    libelle: 'Fusion d’un dossier patient en double',
    decrire(db, x) {
      const a = R.patient(db, x.id), b = R.patient(db, x.vers_id);
      if (!a || !b || a.id === b.id) throw err(400, 'Choisissez le dossier en double et le dossier à conserver.');
      if (a.fusionne_dans || b.fusionne_dans) throw err(409, 'Un des dossiers est déjà fusionné.');
      return `${a.ipp} ${R.nomPatient(a)}, fusionné dans ${b.ipp} ${R.nomPatient(b)}`;
    },
    executer: (db, u, x) => R.fusionnerPatients(db, u, x.id, x.vers_id)
  },
  creneau: {
    libelle: 'Annulation d’un créneau de planning',
    decrire(db, x) {
      const c = db.prepare('SELECT p.*, e.matricule, e.nom, e.prenoms FROM planning p JOIN employes e ON e.id = p.employe_id WHERE p.id = ?').get(x.id);
      if (!c) throw err(404, 'Créneau introuvable.');
      if (c.annule_le) throw err(409, 'Créneau déjà annulé.');
      return `${c.matricule} ${nomEmp(c)}, ${c.type} du ${c.jour.split('-').reverse().join('/')} de ${c.debut} à ${c.fin}`;
    },
    executer: (db, u, x) => RH.annulerCreneau(db, u, x.id)
  },
  bulletin: {
    libelle: 'Annulation d’un bulletin de paie',
    decrire(db, x) {
      const p = db.prepare('SELECT p.*, e.matricule, e.nom, e.prenoms FROM paies p JOIN employes e ON e.id = p.employe_id WHERE p.id = ?').get(x.id);
      if (!p) throw err(404, 'Bulletin introuvable.');
      if (!['prepare', 'valide'].includes(p.statut)) throw err(409, 'Un bulletin payé ou déjà annulé ne s’annule plus.');
      return `${p.numero}, ${p.matricule} ${nomEmp(p)}, ${p.periode}, net ${fmt(p.net)}`;
    },
    executer: (db, u, x, motif) => RH.annulerPaie(db, u, x.id, { motif })
  },
  bordereau: {
    libelle: 'Annulation d’un bordereau',
    decrire(db, x) {
      const b = db.prepare('SELECT b.*, a.nom AS assureur FROM bordereaux b JOIN assureurs a ON a.id = b.assureur_id WHERE b.id = ?').get(x.id);
      if (!b) throw err(404, 'Bordereau introuvable.');
      if (b.annule) throw err(409, 'Bordereau déjà annulé.');
      if (db.prepare('SELECT 1 FROM reglements_assureurs WHERE bordereau_id = ?').get(b.id)) throw err(409, 'Bordereau déjà réglé en partie : annulation impossible.');
      return `${b.numero}, ${b.assureur}, ${fmt(b.total)}`;
    },
    executer: (db, u, x, motif) => TP.annulerBordereau(db, u, x.id, motif)
  }
};

function demander(db, u, d) {
  const o = OBJETS[d.objet];
  if (!o) throw err(400, 'Élément à supprimer inconnu.');
  const x = { objet: d.objet, id: Number(d.id) };
  if (d.objet === 'doublon') x.vers_id = Number(d.vers_id);
  const motif = texte(d.motif, { label: 'Motif', max: 300 }) || '';
  if (motif.length < 10) throw err(400, 'Indiquez le motif de la demande (10 caractères au moins) : l’administrateur en a besoin pour décider.');
  x.description = o.decrire(db, x);
  const enAttente = db.prepare("SELECT donnees FROM demandes WHERE type = 'suppression' AND statut = 'en_attente'").all().map(r => JSON.parse(r.donnees));
  if (enAttente.some(y => y.objet === x.objet && y.id === x.id)) throw err(409, 'Une demande est déjà en attente pour cet élément : l’administrateur va la traiter.');
  const id = db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)').run('suppression', JSON.stringify(x), motif, u.id, maintenant()).lastInsertRowid;
  R.journal(db, u, 'Suppressions', 'Demande de suppression', `${o.libelle} : ${x.description}. Motif : ${motif}`);
  return { id, description: x.description };
}
/* Appelé par la décision de l'administrateur : à l'acceptation, l'opération est exécutée avec ses règles habituelles. */
function executer(db, u, d, accepte) {
  const x = JSON.parse(d.donnees), o = OBJETS[x.objet];
  if (accepte) o.executer(db, u, x, `${d.motif} (demande n° ${d.id})`);
  return `${o.libelle} : ${x.description}`;
}
function lister(db) {
  const limite = new Date(Date.now() - 30 * 864e5).toISOString();
  return db.prepare(`SELECT d.*, a.nom AS demandeur, b.nom AS decideur FROM demandes d LEFT JOIN utilisateurs a ON a.id = d.demandeur_id LEFT JOIN utilisateurs b ON b.id = d.decideur_id
    WHERE d.type IN ('suppression', 'annulation') AND (d.statut = 'en_attente' OR d.decide_le >= ?) ORDER BY (d.statut = 'en_attente') DESC, d.cree_le DESC`).all(limite)
    .map(d => {
      const x = JSON.parse(d.donnees);
      let libelle = 'Annulation de reçu', description = x.description || '';
      if (d.type === 'suppression') libelle = OBJETS[x.objet] ? OBJETS[x.objet].libelle : 'Suppression';
      else {
        const r = db.prepare('SELECT numero, net, patient_id FROM recus WHERE id = ?').get(x.recu_id);
        description = r ? `${r.numero}, ${fmt(r.net)}, ${R.nomPatient(R.patient(db, r.patient_id))}` : 'Reçu introuvable';
      }
      return { id: d.id, type: d.type, objet: x.objet || 'recu', libelle, description, motif: d.motif, statut: d.statut, demandeur: d.demandeur, cree_le: d.cree_le, decideur: d.decideur, decide_le: d.decide_le, reponse: d.reponse };
    });
}
module.exports = { OBJETS, demander, executer, lister };
