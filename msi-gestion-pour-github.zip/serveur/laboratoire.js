'use strict';
/* Laboratoire : seuls les examens payés (ou d'urgence) se réalisent ; un résultat validé est figé et rejoint le dossier du médecin.
   Les normes proposées sont indicatives : le biologiste les valide à la mise en service et peut les ajuster ligne par ligne. */
const { maintenant, jourLocal, bornesJour, ajouterJours, err, texte } = require('./outils');
const R = require('./regles');

const MODELES = {
  'B-NFS': [['Globules blancs', 'G/L', 4, 10], ['Globules rouges', 'T/L', 4, 5.8], ['Hémoglobine', 'g/dL', 12, 17], ['Hématocrite', '%', 36, 50], ['VGM', 'fL', 80, 100], ['Plaquettes', 'G/L', 150, 400]],
  'B-GE': [['Recherche de Plasmodium', '', null, null], ['Densité parasitaire', '/µL', null, null]],
  'B-GLY': [['Glycémie', 'g/L', 0.7, 1.1]],
  'B-CREA': [['Créatininémie', 'mg/L', 6, 12]],
  'B-CRP': [['CRP', 'mg/L', null, 6]],
  'B-TRA': [['ASAT', 'UI/L', null, 40], ['ALAT', 'UI/L', null, 40]],
  'B-ECBU': [['Leucocytes', '/mL', null, 10000], ['Hématies', '/mL', null, 10000], ['Culture', '', null, null], ['Germe identifié', '', null, null], ['Antibiogramme', '', null, null]]
};
const modele = code => (MODELES[code] || [['Résultat', '', null, null]]).map(([p, unite, min, max]) => ({ p, unite, min, max, valeur: '' }));
const nb = v => { const n = parseFloat(String(v == null ? '' : v).replace(',', '.').replace(/\s/g, '')); return isFinite(n) ? n : null; };
const drapeau = l => { const n = nb(l.valeur); if (n === null) return ''; if (l.min != null && n < l.min) return 'B'; if (l.max != null && n > l.max) return 'H'; return ''; };

const EXAMEN = `SELECT b.*, p.nom, p.prenoms, p.ipp, p.sexe, p.naissance, v.numero AS passage, r.id AS resultat_id, r.statut AS resultat_statut
  FROM bons b JOIN actes a ON a.id = b.acte_id JOIN passages v ON v.id = b.passage_id LEFT JOIN patients p ON p.id = b.patient_id
  LEFT JOIN resultats r ON r.bon_id = b.id AND r.statut <> 'rectifie' WHERE a.famille = 'Laboratoire' AND b.annule = 0`;
const statut = x => (x.resultat_statut === 'valide' ? 'valide' : x.resultat_statut === 'brouillon' ? 'en_cours' : x.paye || x.urgent ? 'a_realiser' : 'a_payer');

function file(db) {
  const [semaine] = bornesJour(ajouterJours(jourLocal(), -7)), [mois] = bornesJour(ajouterJours(jourLocal(), -30));
  return db.prepare(`${EXAMEN} AND b.cree_le >= @mois AND (b.cree_le >= @semaine OR r.id IS NULL OR r.statut = 'brouillon') ORDER BY b.cree_le`).all({ semaine, mois })
    .map(x => ({ bon_id: x.id, code: x.code, libelle: x.libelle, cree_le: x.cree_le, urgent: !!x.urgent, passage: x.passage, resultat_id: x.resultat_id,
      patient: { id: x.patient_id, nom: x.nom, prenoms: x.prenoms, ipp: x.ipp, sexe: x.sexe, naissance: x.naissance }, statut: statut(x) }));
}
function examen(db, bonId) {
  const x = db.prepare(`${EXAMEN} AND b.id = ?`).get(bonId);
  if (!x) throw err(404, 'Examen de laboratoire introuvable.');
  const r = x.resultat_id ? db.prepare('SELECT * FROM resultats WHERE id = ?').get(x.resultat_id) : null;
  const historique = db.prepare("SELECT id, valide_le, motif_rectification FROM resultats WHERE bon_id = ? AND statut = 'rectifie' ORDER BY id").all(bonId);
  return { x, r: r ? { ...r, donnees: JSON.parse(r.donnees) } : null, historique, statut: statut(x) };
}
function lire(db, bonId) {
  const { x, r, historique, statut: st } = examen(db, bonId);
  return { bon_id: x.id, code: x.code, libelle: x.libelle, cree_le: x.cree_le, urgent: !!x.urgent, passage: x.passage, statut: st, historique,
    patient: { nom: x.nom, prenoms: x.prenoms, ipp: x.ipp, sexe: x.sexe, naissance: x.naissance }, resultat: r, modele: modele(x.code) };
}
function enregistrer(db, u, bonId, d) {
  const { x, r, statut: st } = examen(db, bonId);
  if (st === 'a_payer') {
    R.journal(db, u, 'Laboratoire', 'Examen bloqué', `${x.libelle} (${x.passage}) : bon non réglé`, { niveau: 'blocage' });
    throw err(409, 'Examen non réglé : envoyez le patient à la caisse avant le prélèvement.', { bloque: true });
  }
  if (r && r.statut === 'valide') throw err(409, 'Résultat validé : faites une rectification.');
  const lignes = (Array.isArray(d.lignes) ? d.lignes : []).slice(0, 40).map(l => {
    const o = { p: texte(l.p, { label: 'Paramètre', max: 80, requis: true }), valeur: texte(l.valeur, { label: 'Valeur', max: 200 }), unite: texte(l.unite, { label: 'Unité', max: 20 }), min: nb(l.min), max: nb(l.max) };
    return { ...o, drapeau: drapeau(o) };
  });
  if (!lignes.length) throw err(400, 'Ajoutez au moins un paramètre.');
  const conclusion = texte(d.conclusion, { label: 'Conclusion', max: 2000 });
  return db.transaction(() => {
    if (r) db.prepare('UPDATE resultats SET donnees = ?, conclusion = ?, maj_le = ? WHERE id = ?').run(JSON.stringify(lignes), conclusion || null, maintenant(), r.id);
    const id = r ? r.id : db.prepare('INSERT INTO resultats(bon_id, patient_id, passage_id, code, libelle, donnees, conclusion, saisi_par, cree_le, maj_le) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(x.id, x.patient_id, x.passage_id, x.code, x.libelle, JSON.stringify(lignes), conclusion || null, u.id, maintenant(), maintenant()).lastInsertRowid;
    return { id, anormaux: lignes.filter(l => l.drapeau).length };
  })();
}
function valider(db, u, id) {
  const r = db.prepare('SELECT * FROM resultats WHERE id = ?').get(id);
  if (!r || r.statut !== 'brouillon') throw err(409, 'Aucun résultat en cours à valider.');
  const lignes = JSON.parse(r.donnees);
  if (!lignes.some(l => l.valeur)) throw err(400, 'Renseignez au moins une valeur avant de valider.');
  db.transaction(() => {
    db.prepare("UPDATE resultats SET statut = 'valide', valide_par = ?, valide_le = ? WHERE id = ?").run(u.id, maintenant(), id);
    R.journal(db, u, 'Laboratoire', 'Résultat validé', `${r.libelle} pour ${R.nomPatient(R.patient(db, r.patient_id))}${lignes.some(l => l.drapeau) ? ', valeurs anormales' : ''}`);
  })();
}
function rectifier(db, u, id, motifSaisi) {
  const r = db.prepare('SELECT * FROM resultats WHERE id = ?').get(id);
  if (!r || r.statut !== 'valide') throw err(409, 'Seul un résultat validé se rectifie.');
  const motif = texte(motifSaisi, { label: 'Motif de la rectification', max: 300, requis: true });
  return db.transaction(() => {
    db.prepare("UPDATE resultats SET statut = 'rectifie' WHERE id = ?").run(id);
    const nid = db.prepare('INSERT INTO resultats(bon_id, patient_id, passage_id, code, libelle, donnees, conclusion, saisi_par, cree_le, maj_le, rectifie_id, motif_rectification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(r.bon_id, r.patient_id, r.passage_id, r.code, r.libelle, r.donnees, r.conclusion, u.id, maintenant(), maintenant(), r.id, motif).lastInsertRowid;
    R.journal(db, u, 'Laboratoire', 'Rectification de résultat', `${r.libelle} pour ${R.nomPatient(R.patient(db, r.patient_id))}, motif : ${motif}`, { niveau: 'alerte' });
    return { id: nid };
  })();
}
/* Contrôle anti-fuite : examens payés depuis plus de 48 heures sans résultat validé. */
function nonRealises(db) {
  const limite = new Date(Date.now() - 48 * 3600e3).toISOString();
  return db.prepare(`${EXAMEN} AND b.paye = 1 AND b.cree_le < ? AND (r.id IS NULL OR r.statut <> 'valide')`).all(limite).length;
}

module.exports = { MODELES, file, lire, enregistrer, valider, rectifier, nonRealises };
